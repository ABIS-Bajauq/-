/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u5e03\u5c40
 *  top.bienvenido.date_24323.\u653b\u575a
 *  top.bienvenido.date_24323.\u6587\u6848
 *  top.bienvenido.date_24323.\u7b14\u82af
 *  top.bienvenido.date_24323.\u94f8\u9020
 *  top.bienvenido.date_24323.\u94fe\u8def
 *  top.bienvenido.mundo.manifest.MundoSplashLauncher
 */
package net_62v.external;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u653b\u575a;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.mundo.manifest.MundoSplashLauncher;

public final class MetaActivityManager {
    public static void acquirePreloadNextProcess() {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af();
    }

    public static int broadcastIntentAsUser(Intent intent, int n) {
        return MetaActivityManager.broadcastIntentAsUser(intent, String.valueOf((int)n));
    }

    public static int broadcastIntentAsUser(Intent intent, String string2) {
        return ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(intent, string2);
    }

    public static void finishApplicationActivity(String string2, String string3) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(string2, string3);
    }

    public static String[] getRunningAppInfoByPid(int n) {
        return ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(n);
    }

    public static List<ActivityManager.RunningAppProcessInfo> getRunningProcessInfo(String string2) {
        return ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u6f0f\u6597(0);
    }

    public static void initialize(Context context) {
        \u653b\u575a.\u8d4b\u80fd = context;
    }

    public static boolean isAppRunning(String string2) {
        return MetaActivityManager.isAppRunning(string2, "0");
    }

    public static boolean isAppRunning(String string2, int n) {
        return MetaActivityManager.isAppRunning(string2, String.valueOf((int)n));
    }

    public static boolean isAppRunning(String string2, String string3) {
        return ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u6f0f\u6597(string2, string3);
    }

    public static void killAllApps() {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(null, null);
    }

    public static void killAppByPkg(int n, String string2) {
        MetaActivityManager.killAppByPkg(String.valueOf((int)n), string2);
    }

    public static void killAppByPkg(String string2) {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(string2, null);
    }

    public static void killAppByPkg(String string2, String string3) {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(string3, string2);
    }

    public static void launchActivityExistingAppProcess(String string2) {
        MetaActivityManager.launchActivityExistingAppProcess(string2, "0");
    }

    public static void launchActivityExistingAppProcess(String string2, String string3) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u6c89\u6dc0(string2, string3);
    }

    public static void launchApp(int n, String string2) {
        MetaActivityManager.launchApp(String.valueOf((int)n), string2);
    }

    public static void launchApp(String string2) {
        MetaActivityManager.launchApp("0", string2);
    }

    public static void launchApp(String string2, String string3) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u6c89\u6dc0(string3, string2);
    }

    public static void launchAppWithSplash(Context context, String string2) {
        MetaActivityManager.launchAppWithSplash(context, string2, "0");
    }

    public static void launchAppWithSplash(Context context, String string2, String string3) {
        Intent intent = MetaActivityManager.obtainSplashLaunchIntent(string3, string2, context);
        if (intent != null) {
            intent.addFlags(268435456);
            context.startActivity(intent);
        }
    }

    public static void launchExistingApp(String string2, String string3) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u6c89\u6dc0(string2, string3);
    }

    public static void launchIntent(Intent intent) {
        MetaActivityManager.launchIntent(intent, "0");
    }

    public static void launchIntent(Intent intent, int n) {
        MetaActivityManager.launchIntent(intent, String.valueOf((int)n));
    }

    public static void launchIntent(Intent intent, String string2) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(intent, string2);
    }

    public static Intent obtainSplashLaunchIntent(int n, String string2, Context context) {
        return MetaActivityManager.obtainSplashLaunchIntent(String.valueOf((int)n), string2, context);
    }

    public static Intent obtainSplashLaunchIntent(String string2, Context context) {
        return MetaActivityManager.obtainSplashLaunchIntent("0", string2, context);
    }

    public static Intent obtainSplashLaunchIntent(String string2, String string3, Context context) {
        if (!((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(string3)) {
            MetaActivityManager.launchApp(string2, string3);
            return null;
        }
        if (((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(string3, string2)) {
            return null;
        }
        Intent intent = new Intent(context, MundoSplashLauncher.class);
        intent.putExtra("mundo_base_string", string3);
        intent.putExtra("mundo_base_bundle", string2);
        return intent;
    }

    public static void setAppProxyUri(String string2) {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u5e73\u53f0(string2);
    }

    public static void setAppProxyUri(String string2, String string3, String string4) {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2, string3, string4);
    }

    public static void startService(Intent intent, int n) {
        MetaActivityManager.startService(intent, String.valueOf((int)n));
    }

    public static void startService(Intent intent, String string2) {
        ((\u7b14\u82af)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(intent, string2);
    }
}

