/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package net_62v.external;

public interface IMundoProcessCallback {
    default public void onCreate(String string2, String string3) {
    }

    default public void onCreate(String string2, String string3, String string4) {
        this.onCreate(string2, string3);
    }

    default public void onInitialized() {
    }

    default public boolean shouldInterpretFacebookBrowser() {
        return false;
    }
}

