/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.ResolveInfo
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u94f8\u9020
 */
package net_62v.external;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class MetaPackageManager {
    public static void acquireObtainAppSplash() {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(0);
    }

    public static void acquireReleaseAppSplash() {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(1);
    }

    public static void cleanPackageDataAsUser(String string2, int n) {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2, String.valueOf((int)n));
    }

    public static void cleanPackageDataAsUser(String string2, String string3) {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2, string3);
    }

    public static void createEmptyUser(String string2, int n) {
        try {
            if (Arrays.binarySearch((int[])MetaPackageManager.getInstalledUserId(string2), (int)n) < 0) {
                MetaPackageManager.createEmptyUser(string2, String.valueOf((int)n));
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void createEmptyUser(String string2, String string3) {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u7ed9\u5230(string2, string3);
    }

    public static void createEmptyUserById(String string2) {
        int[] arrn = MetaPackageManager.getInstalledUserId(string2);
        int n = 0;
        do {
            if (Arrays.binarySearch((int[])arrn, (int)n) < 0) break;
            ++n;
        } while (true);
        try {
            MetaPackageManager.createEmptyUser(string2, String.valueOf((int)n));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    @Deprecated
    public static void deleteAllAppCache() {
    }

    @Deprecated
    public static void deleteAppCache(String string2) {
    }

    public static boolean fixInternalAppAndReinstall(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(string2);
    }

    public static ApplicationInfo getApplicationInfo(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(string2, 0);
    }

    public static PackageInfo getInnerAppPackageInfo(String string2, int n) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2, n);
    }

    public static List<ApplicationInfo> getInstalledApplicationInfos() {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(0);
    }

    public static List<String> getInstalledInnerApps() {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b();
    }

    public static List<PackageInfo> getInstalledPackageInfos() {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(0);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int[] getInstalledUserId(String var0) {
        try {
            var1_1 = new ArrayList();
            var3_2 = MetaPackageManager.getInstalledUserName(var0);
            if (var3_2 == null) ** GOTO lbl-1000
            var4_3 = var3_2.length;
            var5_4 = 0;
            do {
                block11 : {
                    if (var5_4 < var4_3) {
                        var6_5 = var3_2[var5_4];
                        var7_6 = var6_5.length();
                    } else lbl-1000: // 2 sources:
                    {
                        Collections.sort((List)var1_1);
                        var11_9 = var1_1.size();
                        var12_10 = new int[var11_9];
                        break;
                    }
                    while (--var7_6 >= 0) {
                        var8_7 = var6_5.charAt(var7_6);
                        if (var8_7 >= '0' && var8_7 <= '9') continue;
                        var9_8 = false;
                        break block11;
                    }
                    var9_8 = true;
                }
                if (var9_8) {
                    var1_1.add((Object)Integer.valueOf((String)var6_5));
                }
                ++var5_4;
            } while (true);
            for (var13_11 = 0; var13_11 < var1_1.size(); ++var13_11) {
                var12_10[var13_11] = (Integer)var1_1.get(var13_11);
            }
            if (var11_9 != 0) {
                return var12_10;
            }
            return new int[]{0};
        }
        catch (Exception var2_13) {
            return new int[0];
        }
    }

    public static String[] getInstalledUserName(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6c89\u6dc0(string2);
    }

    public static Intent getLaunchIntent(String string2) {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.INFO");
        intent.setPackage(string2);
        \u4e0b\u6e38 \u4e0b\u6e382 = \u4e0b\u6e38.\u843d\u5730;
        ResolveInfo resolveInfo = ((\u94f8\u9020)\u4e0b\u6e382.\u8d4b\u80fd()).\u843d\u5730(intent, null, 131072);
        if (resolveInfo == null) {
            intent.removeCategory("android.intent.category.INFO");
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.setPackage(string2);
            resolveInfo = ((\u94f8\u9020)\u4e0b\u6e382.\u8d4b\u80fd()).\u843d\u5730(intent, null, 131072);
        }
        if (resolveInfo == null) {
            return null;
        }
        intent.setFlags(268435456);
        ActivityInfo activityInfo = resolveInfo.activityInfo;
        intent.setClassName(activityInfo.packageName, activityInfo.name);
        return intent;
    }

    public static Intent getLaunchIntentForPackage(Intent intent) {
        ActivityInfo activityInfo = MetaPackageManager.resolveIntentActivity(intent);
        if (activityInfo == null) {
            return null;
        }
        Intent intent2 = new Intent();
        intent2.setComponent(new ComponentName(activityInfo.packageName, activityInfo.name));
        intent2.setAction("android.intent.action.MAIN");
        return intent2;
    }

    public static PackageInfo getPackageInfo(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2, 0);
    }

    public static ActivityInfo getReceiverInfo(ComponentName componentName) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(componentName);
    }

    public static boolean isAppInstalledAsInternal(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u95ed\u73af(string2);
    }

    public static boolean isAppSplashExists(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(string2);
    }

    public static boolean isInnerAppInstalled(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u5bf9\u6807(string2);
    }

    public static List<ResolveInfo> queryIntentActivities(Intent intent, String string2, int n) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(intent, string2, n);
    }

    public static List<ResolveInfo> queryIntentProviders(Intent intent, String string2, int n) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6f0f\u6597(intent, string2, n);
    }

    public static List<ResolveInfo> queryIntentReceivers(Intent intent, String string2, int n) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(intent, string2, n);
    }

    public static List<ResolveInfo> queryIntentServices(Intent intent, String string2, int n) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(intent, string2, n);
    }

    public static void reloadAllApps() {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(null);
    }

    public static ActivityInfo resolveActivityInfo(ComponentName componentName) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6293\u624b(componentName);
    }

    public static ActivityInfo resolveActivityInfo(Intent intent) {
        ResolveInfo resolveInfo = ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(intent, null, 131072);
        if (resolveInfo != null) {
            return resolveInfo.activityInfo;
        }
        return null;
    }

    public static ActivityInfo resolveIntentActivity(Intent intent) {
        ResolveInfo resolveInfo = ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u843d\u5730(intent, null, 0);
        if (resolveInfo != null) {
            return resolveInfo.activityInfo;
        }
        return null;
    }

    public static void uninstallAppFully(String string2) {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2, null);
    }

    public static void waitForBackgroundScanner() {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u6c89\u6dc0();
    }
}

