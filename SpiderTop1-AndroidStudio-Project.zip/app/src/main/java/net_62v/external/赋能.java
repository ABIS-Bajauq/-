/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package net_62v.external;

import net_62v.external.IMundoProcessCallback;

public final class \u8d4b\u80fd {
    public final /* synthetic */ IMundoProcessCallback \u8d4b\u80fd;

    public \u8d4b\u80fd(IMundoProcessCallback iMundoProcessCallback) {
        this.\u8d4b\u80fd = iMundoProcessCallback;
    }
}

