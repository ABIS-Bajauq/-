/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 *  top.bienvenido.date_24323.\u89e6\u8fbe
 */
package net_62v.external;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class MetaCore$$ExternalSyntheticLambda1
implements InvocationHandler {
    public final /* synthetic */ \u89e6\u8fbe f$0;

    public /* synthetic */ MetaCore$$ExternalSyntheticLambda1(\u89e6\u8fbe \u89e6\u8fbe2) {
        this.f$0 = \u89e6\u8fbe2;
    }

    public final Object invoke(Object object, Method method, Object[] arrobject) {
        return this.f$0.\u8d4b\u80fd(object, method, arrobject);
    }
}

