/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.reflect.InvocationHandler
 *  java.util.Objects
 *  kotlin.Pair
 *  net_62v.external.\u6293\u624b
 *  top.bienvenido.date_24323.\u5168\u57df
 *  top.bienvenido.date_24323.\u51fa\u51fb
 *  top.bienvenido.date_24323.\u6241\u5e73\u5316
 *  top.bienvenido.date_24323.\u6253\u78e8
 *  top.bienvenido.date_24323.\u6d1e\u81ea\u8eab
 *  top.bienvenido.date_24323.\u7ec4\u5c40
 *  top.bienvenido.date_24323.\u89e6\u8fbe
 *  top.bienvenido.date_24323.\u98ce\u53e3
 */
package net_62v.external;

import android.content.Context;
import java.io.File;
import java.lang.reflect.InvocationHandler;
import java.util.Objects;
import kotlin.Pair;
import net_62v.external.IMundoProcessCallback;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaCore$$ExternalSyntheticLambda0;
import net_62v.external.MetaCore$$ExternalSyntheticLambda1;
import net_62v.external.MetaPackageManager;
import net_62v.external.\u6293\u624b;
import net_62v.external.\u8d4b\u80fd;
import top.bienvenido.date_24323.\u5168\u57df;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u7ec4\u5c40;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class MetaCore {
    public static InvocationHandler addServiceInterpreter(String string2, String string3, InvocationHandler invocationHandler) {
        Pair pair = (Pair)\u6d1e\u81ea\u8eab.\u8d4b\u80fd.\u8d4b\u80fd(string2.hashCode());
        \u51fa\u51fb \u51fa\u51fb2 = pair != null ? (\u51fa\u51fb)pair.getSecond() : null;
        if (\u51fa\u51fb2 == null) {
            return null;
        }
        \u89e6\u8fbe \u89e6\u8fbe2 = (\u89e6\u8fbe)\u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(string3.hashCode());
        if (\u89e6\u8fbe2 == null) {
            \u89e6\u8fbe2 = \u51fa\u51fb2.\u4e2d\u53f0;
        }
        \u6293\u624b \u6293\u624b2 = new \u6293\u624b(invocationHandler);
        int n = string3.hashCode();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(n, (Object)\u6293\u624b2);
        Objects.requireNonNull((Object)\u89e6\u8fbe2);
        return new MetaCore$$ExternalSyntheticLambda1(\u89e6\u8fbe2);
    }

    public static void attachMetaBase(Context context) {
        MetaActivityManager.initialize(context);
    }

    public static void clearAllCrashLogFiles() {
        File file = \u6253\u78e8.\u8d4b\u80fd((File)\u98ce\u53e3.\u8d4b\u80fd.getCacheDir(), (String[])new String[]{"mundo_crash"});
        file.mkdirs();
        File[] arrfile = file.listFiles();
        if (arrfile != null) {
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                arrfile[i].delete();
            }
        }
    }

    public static void enableCrashReport() {
        \u5168\u57df.\u8d4b\u80fd();
    }

    public static Context getHostContext() {
        return \u98ce\u53e3.\u8d4b\u80fd;
    }

    public static File[] obtainAllCrashLogs() {
        File file = \u6253\u78e8.\u8d4b\u80fd((File)\u98ce\u53e3.\u8d4b\u80fd.getCacheDir(), (String[])new String[]{"mundo_crash"});
        file.mkdirs();
        File[] arrfile = file.listFiles();
        if (arrfile == null) {
            arrfile = new File[]{};
        }
        return arrfile;
    }

    public static void registerCoreCallback(Runnable runnable) {
        new Thread((Runnable)new MetaCore$$ExternalSyntheticLambda0(runnable)).start();
    }

    public static void setProcessLifecycleCallback(IMundoProcessCallback iMundoProcessCallback) {
        \u8d4b\u80fd \u8d4b\u80fd2 = iMundoProcessCallback == null ? null : new \u8d4b\u80fd(iMundoProcessCallback);
        \u7ec4\u5c40.\u8d4b\u80fd = \u8d4b\u80fd2;
    }

    public static /* synthetic */ void \u8d4b\u80fd(Runnable runnable) {
        try {
            MetaPackageManager.waitForBackgroundScanner();
            runnable.run();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

