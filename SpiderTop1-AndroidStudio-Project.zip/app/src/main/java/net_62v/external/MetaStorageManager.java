/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u6253\u78e8
 *  top.bienvenido.date_24323.\u798f\u62a5
 *  top.bienvenido.date_24323.\u94f8\u9020
 */
package net_62v.external;

import java.io.File;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u798f\u62a5;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class MetaStorageManager {
    public static File obtainAppDataDir(String string2, int n) {
        return MetaStorageManager.obtainAppDataDir(string2, String.valueOf((int)n));
    }

    public static File obtainAppDataDir(String string2, String string3) {
        return \u6253\u78e8.\u8d4b\u80fd((File)\u798f\u62a5.\u8d4b\u80fd, (String[])new String[]{string2, string3});
    }

    public static String obtainAppExternalStorageDir(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8fed\u4ee3(string2);
    }

    @Deprecated
    public static void setExternalRootDirectory(String string2) {
        ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u540c\u6b65(string2);
    }
}

