/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u5e03\u5c40
 *  top.bienvenido.date_24323.\u6587\u6848
 */
package net_62v.external;

import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;

public final class MetaActivationManager {
    public static void activateSdk(String string2) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0(string2);
    }

    public static void changeRemoteServerUrl(String string2) {
        ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2);
    }

    public static String getActivationMessage() {
        return ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd();
    }

    public static boolean getActivationStatus() {
        return ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u4e2d\u53f0();
    }
}

