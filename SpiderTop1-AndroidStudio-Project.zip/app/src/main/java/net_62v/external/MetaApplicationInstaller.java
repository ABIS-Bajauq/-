/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u94f8\u9020
 */
package net_62v.external;

import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class MetaApplicationInstaller {
    public static int cloneApp(String string2) {
        return MetaApplicationInstaller.cloneApp(string2, "0");
    }

    public static int cloneApp(String string2, String string3) {
        \u4e0b\u6e38 \u4e0b\u6e382 = \u4e0b\u6e38.\u843d\u5730;
        int n = ((\u94f8\u9020)\u4e0b\u6e382.\u8d4b\u80fd()).\u8d4b\u80fd(string2, 2);
        ((\u94f8\u9020)\u4e0b\u6e382.\u8d4b\u80fd()).\u7ed9\u5230(string2, string3);
        return n;
    }

    public static String convertResultToString(int n) {
        return "Not Support.";
    }

    public static int installAppByPath(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2, 0);
    }

    public static int installAppByPathAndMove(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2, 3);
    }

    public static int installAppsByPath(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2, 1);
    }

    public static int installAppsByPathAndMove(String string2) {
        return ((\u94f8\u9020)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd(string2, 4);
    }
}

