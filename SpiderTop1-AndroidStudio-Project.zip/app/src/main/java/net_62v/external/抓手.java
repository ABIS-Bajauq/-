/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 */
package net_62v.external;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u6293\u624b
extends \u89e6\u8fbe {
    public final /* synthetic */ InvocationHandler \u8d4b\u80fd;

    public \u6293\u624b(InvocationHandler invocationHandler) {
        this.\u8d4b\u80fd = invocationHandler;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return this.\u8d4b\u80fd.invoke(object, method, arrobject);
    }
}

