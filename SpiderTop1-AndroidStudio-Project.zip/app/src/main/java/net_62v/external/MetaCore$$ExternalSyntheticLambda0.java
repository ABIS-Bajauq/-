/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package net_62v.external;

import net_62v.external.MetaCore;

public final class MetaCore$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ Runnable f$0;

    public /* synthetic */ MetaCore$$ExternalSyntheticLambda0(Runnable runnable) {
        this.f$0 = runnable;
    }

    public final void run() {
        MetaCore.\u8d4b\u80fd(this.f$0);
    }
}

