/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.view.View
 */
package io.github.rupinderjeet.kprogresshud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import io.github.rupinderjeet.kprogresshud.Determinate;
import io.github.rupinderjeet.kprogresshud.Helper;

class BarView
extends View
implements Determinate {
    private RectF mBound;
    private float mBoundGap;
    private RectF mInBound;
    private Paint mInnerPaint;
    private int mMax = 100;
    private Paint mOuterPaint;
    private int mProgress = 0;

    public BarView(Context context) {
        super(context);
        this.init();
    }

    public BarView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init();
    }

    public BarView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    private void init() {
        Paint paint;
        Paint paint2;
        this.mOuterPaint = paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.mOuterPaint.setStrokeWidth((float)Helper.dpToPixel(2.0f, this.getContext()));
        this.mOuterPaint.setColor(-1);
        this.mInnerPaint = paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.FILL);
        this.mInnerPaint.setColor(-1);
        float f = this.mBoundGap = (float)Helper.dpToPixel(5.0f, this.getContext());
        this.mInBound = new RectF(f, f, ((float)this.getWidth() - this.mBoundGap) * (float)this.mProgress / (float)this.mMax, (float)this.getHeight() - this.mBoundGap);
        this.mBound = new RectF();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF rectF = this.mBound;
        canvas.drawRoundRect(rectF, rectF.height() / 2.0f, this.mBound.height() / 2.0f, this.mOuterPaint);
        RectF rectF2 = this.mInBound;
        canvas.drawRoundRect(rectF2, rectF2.height() / 2.0f, this.mInBound.height() / 2.0f, this.mInnerPaint);
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        this.setMeasuredDimension(Helper.dpToPixel(100.0f, this.getContext()), Helper.dpToPixel(20.0f, this.getContext()));
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        int n5 = Helper.dpToPixel(2.0f, this.getContext());
        this.mBound.set((float)n5, (float)n5, (float)(n - n5), (float)(n2 - n5));
    }

    @Override
    public void setMax(int n) {
        this.mMax = n;
    }

    @Override
    public void setProgress(int n) {
        this.mProgress = n;
        RectF rectF = this.mInBound;
        float f = this.mBoundGap;
        rectF.set(f, f, ((float)this.getWidth() - this.mBoundGap) * (float)this.mProgress / (float)this.mMax, (float)this.getHeight() - this.mBoundGap);
        this.invalidate();
    }
}

