/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.rupinderjeet.kprogresshud;

public interface Indeterminate {
    public void setAnimationSpeed(float var1);
}

