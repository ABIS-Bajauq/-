/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.util.AttributeSet
 *  android.widget.LinearLayout
 */
package io.github.rupinderjeet.kprogresshud;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import io.github.rupinderjeet.kprogresshud.Helper;
import io.github.rupinderjeet.kprogresshud.R;

public class BackgroundLayout
extends LinearLayout {
    private int mBackgroundColor;
    private float mCornerRadius;

    public BackgroundLayout(Context context) {
        super(context);
        this.init();
    }

    public BackgroundLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init();
    }

    public BackgroundLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    private void init() {
        this.initBackground(this.getContext().getResources().getColor(R.color.kprogresshud_default_color), this.mCornerRadius);
    }

    private void initBackground(int n, float f) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setColor(n);
        gradientDrawable.setCornerRadius(f);
        this.setBackground((Drawable)gradientDrawable);
    }

    public void setBaseColor(int n) {
        this.mBackgroundColor = n;
        this.initBackground(n, this.mCornerRadius);
    }

    public void setCornerRadius(float f) {
        float f2;
        this.mCornerRadius = f2 = (float)Helper.dpToPixel(f, this.getContext());
        this.initBackground(this.mBackgroundColor, f2);
    }
}

