/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  java.lang.Object
 */
package io.github.rupinderjeet.kprogresshud;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

class Helper {
    private static float scale;

    Helper() {
    }

    public static int dpToPixel(float f, Context context) {
        if (scale == 0.0f) {
            scale = context.getResources().getDisplayMetrics().density;
        }
        return (int)(f * scale);
    }
}

