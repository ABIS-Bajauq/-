/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.util.AttributeSet
 *  android.widget.ImageView
 *  java.lang.Runnable
 */
package io.github.rupinderjeet.kprogresshud;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.ImageView;
import io.github.rupinderjeet.kprogresshud.Indeterminate;
import io.github.rupinderjeet.kprogresshud.R;
import io.github.rupinderjeet.kprogresshud.SpinView;

class SpinView
extends ImageView
implements Indeterminate {
    private int mFrameTime;
    private boolean mNeedToUpdateView;
    private float mRotateDegrees;
    private Runnable mUpdateViewRunnable;

    public SpinView(Context context) {
        super(context);
        this.init();
    }

    public SpinView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init();
    }

    static /* synthetic */ float access$000(SpinView spinView) {
        return spinView.mRotateDegrees;
    }

    static /* synthetic */ float access$002(SpinView spinView, float f) {
        spinView.mRotateDegrees = f;
        return f;
    }

    static /* synthetic */ float access$016(SpinView spinView, float f) {
        float f2;
        spinView.mRotateDegrees = f2 = f + spinView.mRotateDegrees;
        return f2;
    }

    static /* synthetic */ boolean access$100(SpinView spinView) {
        return spinView.mNeedToUpdateView;
    }

    static /* synthetic */ int access$200(SpinView spinView) {
        return spinView.mFrameTime;
    }

    private void init() {
        this.setImageResource(R.drawable.kprogresshud_spinner);
        this.mFrameTime = 83;
        this.mUpdateViewRunnable = new Runnable(this){
            final /* synthetic */ SpinView this$0;
            {
                this.this$0 = spinView;
            }

            public void run() {
                SpinView.access$016(this.this$0, 30.0f);
                SpinView spinView = this.this$0;
                float f = SpinView.access$000(spinView) < 360.0f ? SpinView.access$000(this.this$0) : SpinView.access$000(this.this$0) - 360.0f;
                SpinView.access$002(spinView, f);
                this.this$0.invalidate();
                if (SpinView.access$100(this.this$0)) {
                    SpinView spinView2 = this.this$0;
                    spinView2.postDelayed((Runnable)this, (long)SpinView.access$200(spinView2));
                }
            }
        };
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mNeedToUpdateView = true;
        this.post(this.mUpdateViewRunnable);
    }

    protected void onDetachedFromWindow() {
        this.mNeedToUpdateView = false;
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        canvas.rotate(this.mRotateDegrees, (float)this.getWidth() / 2.0f, (float)this.getHeight() / 2.0f);
        super.onDraw(canvas);
    }

    @Override
    public void setAnimationSpeed(float f) {
        this.mFrameTime = (int)(83.0f / f);
    }
}

