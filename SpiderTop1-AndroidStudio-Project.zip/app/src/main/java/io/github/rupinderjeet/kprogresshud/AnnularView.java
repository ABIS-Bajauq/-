/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.view.View
 */
package io.github.rupinderjeet.kprogresshud;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import io.github.rupinderjeet.kprogresshud.Determinate;
import io.github.rupinderjeet.kprogresshud.Helper;
import io.github.rupinderjeet.kprogresshud.R;

class AnnularView
extends View
implements Determinate {
    private RectF mBound;
    private Paint mGreyPaint;
    private int mMax = 100;
    private int mProgress = 0;
    private Paint mWhitePaint;

    public AnnularView(Context context) {
        super(context);
        this.init(context);
    }

    public AnnularView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(context);
    }

    public AnnularView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(context);
    }

    private void init(Context context) {
        Paint paint;
        Paint paint2;
        this.mWhitePaint = paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.mWhitePaint.setStrokeWidth((float)Helper.dpToPixel(3.0f, this.getContext()));
        this.mWhitePaint.setColor(-1);
        this.mGreyPaint = paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.STROKE);
        this.mGreyPaint.setStrokeWidth((float)Helper.dpToPixel(3.0f, this.getContext()));
        this.mGreyPaint.setColor(context.getResources().getColor(R.color.kprogresshud_grey_color));
        this.mBound = new RectF();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float f = 360.0f * (float)this.mProgress / (float)this.mMax;
        canvas.drawArc(this.mBound, 270.0f, f, false, this.mWhitePaint);
        canvas.drawArc(this.mBound, f + 270.0f, 360.0f - f, false, this.mGreyPaint);
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        int n3 = Helper.dpToPixel(40.0f, this.getContext());
        this.setMeasuredDimension(n3, n3);
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        int n5 = Helper.dpToPixel(4.0f, this.getContext());
        this.mBound.set((float)n5, (float)n5, (float)(n - n5), (float)(n2 - n5));
    }

    @Override
    public void setMax(int n) {
        this.mMax = n;
    }

    @Override
    public void setProgress(int n) {
        this.mProgress = n;
        this.invalidate();
    }
}

