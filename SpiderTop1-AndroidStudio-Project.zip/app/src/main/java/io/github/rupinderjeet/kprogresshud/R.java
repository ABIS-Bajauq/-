/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.rupinderjeet.kprogresshud;

public final class R {
    private R() {
    }

    public static final class color {
        public static final int kprogresshud_default_color = 2131034251;
        public static final int kprogresshud_grey_color = 2131034252;

        private color() {
        }
    }

    public static final class drawable {
        public static final int kprogresshud_spinner = 2131165470;

        private drawable() {
        }
    }

    public static final class id {
        public static final int background = 2131296504;
        public static final int container = 2131296568;
        public static final int details_label = 2131296597;
        public static final int label = 2131296770;

        private id() {
        }
    }

    public static final class layout {
        public static final int kprogresshud_hud = 2131492947;

        private layout() {
        }
    }

}

