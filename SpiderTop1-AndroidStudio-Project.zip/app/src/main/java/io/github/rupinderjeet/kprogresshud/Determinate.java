/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.rupinderjeet.kprogresshud;

public interface Determinate {
    public void setMax(int var1);

    public void setProgress(int var1);
}

