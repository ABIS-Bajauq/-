/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.res.Resources
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.TextView
 *  io.github.rupinderjeet.kprogresshud.AnnularView
 *  io.github.rupinderjeet.kprogresshud.BarView
 *  io.github.rupinderjeet.kprogresshud.PieView
 *  io.github.rupinderjeet.kprogresshud.SpinView
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package io.github.rupinderjeet.kprogresshud;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import io.github.rupinderjeet.kprogresshud.AnnularView;
import io.github.rupinderjeet.kprogresshud.BackgroundLayout;
import io.github.rupinderjeet.kprogresshud.BarView;
import io.github.rupinderjeet.kprogresshud.Determinate;
import io.github.rupinderjeet.kprogresshud.Helper;
import io.github.rupinderjeet.kprogresshud.Indeterminate;
import io.github.rupinderjeet.kprogresshud.PieView;
import io.github.rupinderjeet.kprogresshud.R;
import io.github.rupinderjeet.kprogresshud.SpinView;

public class KProgressHUD {
    private int mAnimateSpeed;
    private Context mContext;
    private float mCornerRadius;
    private float mDimAmount;
    private boolean mFinished;
    private int mGraceTimeMs;
    private Handler mGraceTimer;
    private boolean mIsAutoDismiss;
    private int mMaxProgress;
    private ProgressDialog mProgressDialog;
    private int mWindowColor;

    public KProgressHUD(Context context) {
        this.mContext = context;
        this.mProgressDialog = new ProgressDialog(context);
        this.mDimAmount = 0.0f;
        this.mWindowColor = context.getResources().getColor(R.color.kprogresshud_default_color);
        this.mAnimateSpeed = 1;
        this.mCornerRadius = 10.0f;
        this.mIsAutoDismiss = true;
        this.mGraceTimeMs = 0;
        this.mFinished = false;
        this.setStyle(Style.SPIN_INDETERMINATE);
    }

    public static KProgressHUD create(Context context) {
        return new KProgressHUD(context);
    }

    public static KProgressHUD create(Context context, Style style2) {
        return new KProgressHUD(context).setStyle(style2);
    }

    public void dismiss() {
        ProgressDialog progressDialog;
        Handler handler;
        this.mFinished = true;
        if (this.mContext != null && (progressDialog = this.mProgressDialog) != null && progressDialog.isShowing()) {
            this.mProgressDialog.dismiss();
        }
        if ((handler = this.mGraceTimer) != null) {
            handler.removeCallbacksAndMessages(null);
            this.mGraceTimer = null;
        }
    }

    public boolean isShowing() {
        ProgressDialog progressDialog = this.mProgressDialog;
        return progressDialog != null && progressDialog.isShowing();
    }

    public KProgressHUD setAnimationSpeed(int n) {
        this.mAnimateSpeed = n;
        return this;
    }

    public KProgressHUD setAutoDismiss(boolean bl) {
        this.mIsAutoDismiss = bl;
        return this;
    }

    public KProgressHUD setBackgroundColor(int n) {
        this.mWindowColor = n;
        return this;
    }

    public KProgressHUD setCancellable(DialogInterface.OnCancelListener onCancelListener) {
        ProgressDialog progressDialog = this.mProgressDialog;
        boolean bl = onCancelListener != null;
        progressDialog.setCancelable(bl);
        this.mProgressDialog.setOnCancelListener(onCancelListener);
        return this;
    }

    public KProgressHUD setCancellable(boolean bl) {
        this.mProgressDialog.setCancelable(bl);
        this.mProgressDialog.setOnCancelListener(null);
        return this;
    }

    public KProgressHUD setCornerRadius(float f) {
        this.mCornerRadius = f;
        return this;
    }

    public KProgressHUD setCustomView(View view) {
        if (view != null) {
            this.mProgressDialog.setView(view);
            return this;
        }
        throw new RuntimeException("Custom view must not be null!");
    }

    public KProgressHUD setDetailsLabel(String string2) {
        this.mProgressDialog.setDetailsLabel(string2);
        return this;
    }

    public KProgressHUD setDetailsLabel(String string2, int n) {
        this.mProgressDialog.setDetailsLabel(string2, n);
        return this;
    }

    public KProgressHUD setDimAmount(float f) {
        if (f >= 0.0f && f <= 1.0f) {
            this.mDimAmount = f;
        }
        return this;
    }

    public KProgressHUD setGraceTime(int n) {
        this.mGraceTimeMs = n;
        return this;
    }

    public KProgressHUD setLabel(String string2) {
        this.mProgressDialog.setLabel(string2);
        return this;
    }

    public KProgressHUD setLabel(String string2, int n) {
        this.mProgressDialog.setLabel(string2, n);
        return this;
    }

    public KProgressHUD setMaxProgress(int n) {
        this.mMaxProgress = n;
        return this;
    }

    public void setProgress(int n) {
        this.mProgressDialog.setProgress(n);
    }

    public KProgressHUD setSize(int n, int n2) {
        this.mProgressDialog.setSize(n, n2);
        return this;
    }

    public KProgressHUD setStyle(Style style2) {
        BarView barView;
        switch (2.$SwitchMap$io$github$rupinderjeet$kprogresshud$KProgressHUD$Style[style2.ordinal()]) {
            default: {
                barView = null;
                break;
            }
            case 4: {
                barView = new BarView(this.mContext);
                break;
            }
            case 3: {
                barView = new AnnularView(this.mContext);
                break;
            }
            case 2: {
                barView = new PieView(this.mContext);
                break;
            }
            case 1: {
                barView = new SpinView(this.mContext);
            }
        }
        this.mProgressDialog.setView((View)barView);
        return this;
    }

    @Deprecated
    public KProgressHUD setWindowColor(int n) {
        this.mWindowColor = n;
        return this;
    }

    public KProgressHUD show() {
        if (!this.isShowing()) {
            Handler handler;
            this.mFinished = false;
            if (this.mGraceTimeMs == 0) {
                this.mProgressDialog.show();
                return this;
            }
            this.mGraceTimer = handler = new Handler();
            handler.postDelayed(new Runnable(){

                public void run() {
                    if (KProgressHUD.this.mProgressDialog != null && !KProgressHUD.this.mFinished) {
                        KProgressHUD.this.mProgressDialog.show();
                    }
                }
            }, (long)this.mGraceTimeMs);
        }
        return this;
    }

    private class ProgressDialog
    extends Dialog {
        private BackgroundLayout mBackgroundLayout;
        private FrameLayout mCustomViewContainer;
        private int mDetailColor;
        private String mDetailsLabel;
        private TextView mDetailsText;
        private Determinate mDeterminateView;
        private int mHeight;
        private Indeterminate mIndeterminateView;
        private String mLabel;
        private int mLabelColor;
        private TextView mLabelText;
        private View mView;
        private int mWidth;

        public ProgressDialog(Context context) {
            super(context);
            this.mLabelColor = -1;
            this.mDetailColor = -1;
        }

        private void addViewToFrame(View view) {
            if (view == null) {
                return;
            }
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -2);
            this.mCustomViewContainer.addView(view, layoutParams);
        }

        private void initViews() {
            Indeterminate indeterminate;
            BackgroundLayout backgroundLayout;
            this.mBackgroundLayout = backgroundLayout = (BackgroundLayout)this.findViewById(R.id.background);
            backgroundLayout.setBaseColor(KProgressHUD.this.mWindowColor);
            this.mBackgroundLayout.setCornerRadius(KProgressHUD.this.mCornerRadius);
            if (this.mWidth != 0) {
                this.updateBackgroundSize();
            }
            this.mCustomViewContainer = (FrameLayout)this.findViewById(R.id.container);
            this.addViewToFrame(this.mView);
            Determinate determinate = this.mDeterminateView;
            if (determinate != null) {
                determinate.setMax(KProgressHUD.this.mMaxProgress);
            }
            if ((indeterminate = this.mIndeterminateView) != null) {
                indeterminate.setAnimationSpeed(KProgressHUD.this.mAnimateSpeed);
            }
            this.mLabelText = (TextView)this.findViewById(R.id.label);
            this.setLabel(this.mLabel, this.mLabelColor);
            this.mDetailsText = (TextView)this.findViewById(R.id.details_label);
            this.setDetailsLabel(this.mDetailsLabel, this.mDetailColor);
        }

        private void updateBackgroundSize() {
            ViewGroup.LayoutParams layoutParams = this.mBackgroundLayout.getLayoutParams();
            layoutParams.width = Helper.dpToPixel(this.mWidth, this.getContext());
            layoutParams.height = Helper.dpToPixel(this.mHeight, this.getContext());
            this.mBackgroundLayout.setLayoutParams(layoutParams);
        }

        protected void onCreate(Bundle bundle) {
            super.onCreate(bundle);
            this.requestWindowFeature(1);
            this.setContentView(R.layout.kprogresshud_hud);
            Window window = this.getWindow();
            window.setBackgroundDrawable((Drawable)new ColorDrawable(0));
            window.addFlags(2);
            WindowManager.LayoutParams layoutParams = window.getAttributes();
            layoutParams.dimAmount = KProgressHUD.this.mDimAmount;
            layoutParams.gravity = 17;
            window.setAttributes(layoutParams);
            this.setCanceledOnTouchOutside(false);
            this.initViews();
        }

        public void setDetailsLabel(String string2) {
            this.mDetailsLabel = string2;
            TextView textView = this.mDetailsText;
            if (textView != null) {
                if (string2 != null) {
                    textView.setText((CharSequence)string2);
                    this.mDetailsText.setVisibility(0);
                    return;
                }
                textView.setVisibility(8);
            }
        }

        public void setDetailsLabel(String string2, int n) {
            this.mDetailsLabel = string2;
            this.mDetailColor = n;
            TextView textView = this.mDetailsText;
            if (textView != null) {
                if (string2 != null) {
                    textView.setText((CharSequence)string2);
                    this.mDetailsText.setTextColor(n);
                    this.mDetailsText.setVisibility(0);
                    return;
                }
                textView.setVisibility(8);
            }
        }

        public void setLabel(String string2) {
            this.mLabel = string2;
            TextView textView = this.mLabelText;
            if (textView != null) {
                if (string2 != null) {
                    textView.setText((CharSequence)string2);
                    this.mLabelText.setVisibility(0);
                    return;
                }
                textView.setVisibility(8);
            }
        }

        public void setLabel(String string2, int n) {
            this.mLabel = string2;
            this.mLabelColor = n;
            TextView textView = this.mLabelText;
            if (textView != null) {
                if (string2 != null) {
                    textView.setText((CharSequence)string2);
                    this.mLabelText.setTextColor(n);
                    this.mLabelText.setVisibility(0);
                    return;
                }
                textView.setVisibility(8);
            }
        }

        public void setProgress(int n) {
            Determinate determinate = this.mDeterminateView;
            if (determinate != null) {
                determinate.setProgress(n);
                if (KProgressHUD.this.mIsAutoDismiss && n >= KProgressHUD.this.mMaxProgress) {
                    this.dismiss();
                }
            }
        }

        public void setSize(int n, int n2) {
            this.mWidth = n;
            this.mHeight = n2;
            if (this.mBackgroundLayout != null) {
                this.updateBackgroundSize();
            }
        }

        public void setView(View view) {
            if (view != null) {
                if (view instanceof Determinate) {
                    this.mDeterminateView = (Determinate)view;
                }
                if (view instanceof Indeterminate) {
                    this.mIndeterminateView = (Indeterminate)view;
                }
                this.mView = view;
                if (this.isShowing()) {
                    this.mCustomViewContainer.removeAllViews();
                    this.addViewToFrame(view);
                }
            }
        }
    }

    public static final class Style
    extends Enum<Style> {
        private static final /* synthetic */ Style[] $VALUES;
        public static final /* enum */ Style ANNULAR_DETERMINATE;
        public static final /* enum */ Style BAR_DETERMINATE;
        public static final /* enum */ Style PIE_DETERMINATE;
        public static final /* enum */ Style SPIN_INDETERMINATE;

        static {
            Style style2;
            Style style3;
            Style style4;
            Style style5;
            SPIN_INDETERMINATE = style3 = new Style();
            PIE_DETERMINATE = style4 = new Style();
            ANNULAR_DETERMINATE = style5 = new Style();
            BAR_DETERMINATE = style2 = new Style();
            $VALUES = new Style[]{style3, style4, style5, style2};
        }

        public static Style valueOf(String string2) {
            return (Style)Enum.valueOf(Style.class, (String)string2);
        }

        public static Style[] values() {
            return (Style[])$VALUES.clone();
        }
    }

}

