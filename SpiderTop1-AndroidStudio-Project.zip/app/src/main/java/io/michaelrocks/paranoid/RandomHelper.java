/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.michaelrocks.paranoid;

public class RandomHelper {
    private RandomHelper() {
    }

    public static long next(long l) {
        short s = (short)(l & 65535L);
        short s2 = (short)(65535L & l >>> 16);
        short s3 = (short)(s + RandomHelper.rotl((short)(s + s2), 9));
        short s4 = (short)(s2 ^ s);
        short s5 = (short)((short)(s4 ^ RandomHelper.rotl(s, 13)) ^ s4 << 5);
        short s6 = RandomHelper.rotl(s4, 10);
        return ((long)s3 << 16 | (long)s6) << 16 | (long)s5;
    }

    private static short rotl(short s, int n) {
        return (short)(s << n | s >>> 32 - n);
    }

    public static long seed(long l) {
        long l2 = 7109453100751455733L * (l ^ l >>> 33);
        return -3808689974395783757L * (l2 ^ l2 >>> 28) >>> 32;
    }
}

