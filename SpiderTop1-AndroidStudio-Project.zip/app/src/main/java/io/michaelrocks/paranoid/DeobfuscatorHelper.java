/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.michaelrocks.paranoid;

import io.michaelrocks.paranoid.RandomHelper;

public class DeobfuscatorHelper {
    public static final int MAX_CHUNK_LENGTH = 8191;

    private DeobfuscatorHelper() {
    }

    private static long getCharAt(int n, String[] arrstring, long l) {
        return RandomHelper.next(l) ^ (long)arrstring[n / 8191].charAt(n % 8191) << 32;
    }

    public static String getString(long l, String[] arrstring) {
        long l2 = RandomHelper.next(RandomHelper.seed(l & 0xFFFFFFFFL));
        long l3 = 65535L & l2 >>> 32;
        long l4 = RandomHelper.next(l2);
        int n = (int)(-65536L & l4 >>> 16 ^ (l3 ^ l >>> 32));
        long l5 = DeobfuscatorHelper.getCharAt(n, arrstring, l4);
        int n2 = (int)(65535L & l5 >>> 32);
        char[] arrc = new char[n2];
        for (int i = 0; i < n2; ++i) {
            l5 = DeobfuscatorHelper.getCharAt(1 + (n + i), arrstring, l5);
            arrc[i] = (char)(65535L & l5 >>> 32);
        }
        return new String(arrc);
    }
}

