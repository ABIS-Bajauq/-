/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Triple
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.mundo.manifest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5185\u5377;
import top.bienvenido.date_24323.\u5916\u5305;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.mundo.manifest.MundoSplashLauncher$$ExternalSyntheticLambda0;

@Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"Ltop/bienvenido/mundo/manifest/MundoSplashLauncher;", "Landroid/app/Activity;", "<init>", "()V", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoSplashLauncher
extends Activity {
    public static final void \u8d4b\u80fd(String string2, String string3) {
        \u516c\u5173 \u516c\u51732 = \u516c\u5173.\u6293\u624b;
        if (string3 == null || string3.length() == 0) {
            string3 = "0";
        }
        \u516c\u51732.getClass();
        \u516c\u5173.\u8d4b\u80fd(null, (String)string2, (String)string3);
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.\u8d4b\u80fd(this.getIntent());
    }

    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            this.\u8d4b\u80fd(intent);
            return;
        }
        this.finish();
    }

    public final void onPause() {
        super.onPause();
        this.finish();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void \u8d4b\u80fd(Intent var1_1) {
        block13 : {
            try {
                var3_2 = var1_1.getStringExtra("mundo_base_string");
                if (var3_2 == null || (var4_3 = StringsKt.isBlank((CharSequence)var3_2))) ** GOTO lbl57
            }
            catch (Exception var2_19) {
                return;
            }
            try {
                var6_4 = (\u5185\u5377)\u5916\u5305.\u8d4b\u80fd.\u8d4b\u80fd(var3_2.hashCode());
            }
            catch (Exception var5_5) {
                var6_4 = null;
            }
            if (var6_4 == null) ** GOTO lbl54
            if (\u62bd\u8c61.\u6f0f\u6597) {
                this.getWindow().getAttributes().layoutInDisplayCutoutMode = 1;
            }
            if (var6_4.\u6293\u624b != null) break block13;
            this.getWindow().getDecorView().setBackground(var6_4.\u8d4b\u80fd);
            ** GOTO lbl54
        }
        var9_6 = (int)TypedValue.applyDimension((int)1, (float)20.0f, (DisplayMetrics)this.getResources().getDisplayMetrics());
        var10_7 = var6_4.\u6293\u624b;
        var11_8 = new FrameLayout((Context)this);
        var11_8.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        var12_9 = (Integer)var10_7.getSecond();
        var13_10 = (Integer)var10_7.getThird();
        var14_11 = new ImageView((Context)this);
        var15_12 = var9_6 * 14;
        var16_13 = new FrameLayout.LayoutParams(var15_12, var15_12);
        var16_13.gravity = 17;
        var14_11.setLayoutParams((ViewGroup.LayoutParams)var16_13);
        var17_14 = var6_4.\u8d4b\u80fd;
        var14_11.setImageDrawable(var17_14);
        if (var17_14 instanceof Animatable) {
            ((Animatable)var17_14).start();
        }
        if (var13_10 != null && !Intrinsics.areEqual((Object)var13_10, (Object)var12_9) && var13_10 != 0) {
            var14_11.setBackgroundColor(var13_10.intValue());
        }
        var11_8.addView((View)var14_11);
        var18_15 = (Drawable)var10_7.getFirst();
        if (var18_15 != null) {
            var19_16 = new View((Context)this);
            var20_17 = new FrameLayout.LayoutParams(var9_6 * 10, var9_6 * 4);
            var20_17.gravity = 81;
            var20_17.bottomMargin = var9_6 * 3;
            var19_16.setLayoutParams((ViewGroup.LayoutParams)var20_17);
            var19_16.setBackground(var18_15);
            if (\u62bd\u8c61.\u4e2d\u53f0) {
                var19_16.forceHasOverlappingRendering(false);
            }
            var11_8.addView(var19_16);
        }
        if (var12_9 != null) {
            var11_8.setBackgroundColor(var12_9.intValue());
        } else {
            var11_8.setBackground(this.getWindow().getDecorView().getBackground());
        }
        this.setContentView((View)var11_8);
lbl54: // 3 sources:
        var7_18 = var1_1.getStringExtra("mundo_base_bundle");
        this.getWindow().getDecorView().findViewById(16908290).post((Runnable)new MundoSplashLauncher$$ExternalSyntheticLambda0(var3_2, var7_18));
        return;
lbl57: // 1 sources:
        this.finish();
    }
}

