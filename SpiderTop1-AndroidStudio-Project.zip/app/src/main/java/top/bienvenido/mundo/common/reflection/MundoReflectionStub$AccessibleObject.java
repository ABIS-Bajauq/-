/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.common.reflection;

import kotlin.Metadata;

@Metadata(d1={"\u0000\u0012\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2={"top/bienvenido/mundo/common/reflection/MundoReflectionStub$AccessibleObject", "", "<init>", "()V", "", "override", "Z", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public class MundoReflectionStub$AccessibleObject {
    private final boolean override;
}

