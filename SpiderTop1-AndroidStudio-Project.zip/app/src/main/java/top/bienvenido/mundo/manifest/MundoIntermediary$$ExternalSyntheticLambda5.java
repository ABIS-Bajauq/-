/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.mundo.manifest;

import android.app.AlertDialog;
import top.bienvenido.mundo.manifest.MundoIntermediary;

public final class MundoIntermediary$$ExternalSyntheticLambda5
implements Runnable {
    public final /* synthetic */ AlertDialog.Builder f$0;

    public /* synthetic */ MundoIntermediary$$ExternalSyntheticLambda5(AlertDialog.Builder builder) {
        this.f$0 = builder;
    }

    public final void run() {
        MundoIntermediary.\u8d4b\u80fd(this.f$0);
    }
}

