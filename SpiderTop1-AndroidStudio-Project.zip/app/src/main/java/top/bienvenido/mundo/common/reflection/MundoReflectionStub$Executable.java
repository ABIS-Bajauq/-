/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 *  top.bienvenido.mundo.common.reflection.MundoReflectionStub
 */
package top.bienvenido.mundo.common.reflection;

import kotlin.Metadata;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$AccessibleObject;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$Class;

@Metadata(d1={"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0016\u0010\u0007\u001a\u0004\u0018\u00010\u00048\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0007\u0010\u0006R\u001c\u0010\n\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\b8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\r\u0010\u000eR\u0014\u0010\u0010\u001a\u00020\u000f8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0010\u0010\u0011\u00a8\u0006\u0012"}, d2={"top/bienvenido/mundo/common/reflection/MundoReflectionStub$Executable", "Ltop/bienvenido/mundo/common/reflection/MundoReflectionStub$AccessibleObject;", "<init>", "()V", "Ltop/bienvenido/mundo/common/reflection/MundoReflectionStub$Class;", "declaringClass", "Ltop/bienvenido/mundo/common/reflection/MundoReflectionStub$Class;", "declaringClassOfOverriddenMethod", "", "", "parameters", "[Ljava/lang/Object;", "", "artMethod", "J", "", "accessFlags", "I", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoReflectionStub$Executable
extends MundoReflectionStub$AccessibleObject {
    private final int accessFlags;
    private final long artMethod;
    private final MundoReflectionStub.Class declaringClass;
    private final MundoReflectionStub.Class declaringClassOfOverriddenMethod;
    private final Object[] parameters;
}

