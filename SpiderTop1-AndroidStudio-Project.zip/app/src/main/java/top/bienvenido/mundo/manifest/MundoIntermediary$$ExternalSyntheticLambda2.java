/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.concurrent.atomic.AtomicBoolean
 *  kotlin.Pair
 */
package top.bienvenido.mundo.manifest;

import android.content.DialogInterface;
import android.content.Intent;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import top.bienvenido.mundo.manifest.MundoIntermediary;

public final class MundoIntermediary$$ExternalSyntheticLambda2
implements DialogInterface.OnClickListener {
    public final /* synthetic */ ArrayList f$0;
    public final /* synthetic */ MundoIntermediary f$1;
    public final /* synthetic */ Intent f$2;
    public final /* synthetic */ Pair f$3;
    public final /* synthetic */ Intent f$4;
    public final /* synthetic */ AtomicBoolean f$5;

    public /* synthetic */ MundoIntermediary$$ExternalSyntheticLambda2(ArrayList arrayList, MundoIntermediary mundoIntermediary, Intent intent, Pair pair, Intent intent2, AtomicBoolean atomicBoolean) {
        this.f$0 = arrayList;
        this.f$1 = mundoIntermediary;
        this.f$2 = intent;
        this.f$3 = pair;
        this.f$4 = intent2;
        this.f$5 = atomicBoolean;
    }

    public final void onClick(DialogInterface dialogInterface, int n) {
        MundoIntermediary.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, this.f$5, dialogInterface, n);
    }
}

