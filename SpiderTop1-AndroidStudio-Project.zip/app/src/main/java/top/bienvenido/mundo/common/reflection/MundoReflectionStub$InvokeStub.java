/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package top.bienvenido.mundo.common.reflection;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1={"\u0000\u000e\n\u0000\n\u0002\u0010\u0000\n\u0002\u0010\u0011\n\u0002\b\u0005\u0018\u0000 \u00062\u00020\u0001:\u0001\u0006B!\b\u0002\u0012\u0016\u0010\u0003\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00010\u0002\"\u0004\u0018\u00010\u0001\u00a2\u0006\u0004\b\u0004\u0010\u0005\u00a8\u0006\u0007"}, d2={"top/bienvenido/mundo/common/reflection/MundoReflectionStub$InvokeStub", "", "", "args", "<init>", "([Ljava/lang/Object;)V", "Companion", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoReflectionStub$InvokeStub {
    public static final Companion Companion = new Companion(null);

    private /* varargs */ MundoReflectionStub$InvokeStub(Object ... arrobject) {
    }

    @JvmStatic
    private static final /* varargs */ Object invoke(Object ... arrobject) {
        return MundoReflectionStub$InvokeStub.Companion.invoke(arrobject);
    }

    @Metadata(d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003J(\u0010\u0004\u001a\u0004\u0018\u00010\u00012\u0016\u0010\u0005\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00010\u0006\"\u0004\u0018\u00010\u0001H\u0083\u0002\u00a2\u0006\u0002\u0010\u0007\u00a8\u0006\b"}, d2={"Ltop/bienvenido/mundo/common/reflection/MundoReflectionStub$InvokeStub$Companion;", "", "<init>", "()V", "invoke", "args", "", "([Ljava/lang/Object;)Ljava/lang/Object;", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        private final /* varargs */ Object invoke(Object ... arrobject) {
            return null;
        }
    }

}

