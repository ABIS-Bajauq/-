/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountAuthenticatorResponse$Stub
 *  android.os.Bundle
 *  java.lang.String
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.common.ext;

import android.accounts.IAccountAuthenticatorResponse;
import android.os.Bundle;
import kotlin.Metadata;

@Metadata(d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0016\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016J\b\u0010\b\u001a\u00020\u0005H\u0016J\u0018\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016\u00a8\u0006\u000e"}, d2={"Ltop/bienvenido/mundo/common/ext/MundoAccountSession;", "Landroid/accounts/IAccountAuthenticatorResponse$Stub;", "<init>", "()V", "onResult", "", "value", "Landroid/os/Bundle;", "onRequestContinued", "onError", "errorCode", "", "errorMessage", "", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public class MundoAccountSession
extends IAccountAuthenticatorResponse.Stub {
    public void onError(int n, String string2) {
    }

    public void onRequestContinued() {
    }

    public void onResult(Bundle bundle) {
    }
}

