/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.bluetooth.IBluetooth
 *  android.bluetooth.IBluetoothManagerCallback
 *  android.bluetooth.IBluetoothManagerCallback$Stub
 *  android.os.IBinder
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.common.ext;

import android.bluetooth.IBluetooth;
import android.bluetooth.IBluetoothManagerCallback;
import android.os.IBinder;
import kotlin.Metadata;

@Metadata(d1={"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0016\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\u0012\u0010\u0006\u001a\u00020\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0016J\u0012\u0010\u0006\u001a\u00020\u00052\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0005H\u0016J\b\u0010\f\u001a\u00020\u0005H\u0016J\b\u0010\r\u001a\u00020\u0005H\u0016\u00a8\u0006\u000e"}, d2={"Ltop/bienvenido/mundo/common/ext/MundoBleCallback;", "Landroid/bluetooth/IBluetoothManagerCallback$Stub;", "<init>", "()V", "onBluetoothServiceDown", "", "onBluetoothServiceUp", "iBluetooth", "Landroid/bluetooth/IBluetooth;", "bluetoothService", "Landroid/os/IBinder;", "onBluetoothOn", "onBluetoothOff", "onBrEdrDown", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public class MundoBleCallback
extends IBluetoothManagerCallback.Stub {
    public void onBluetoothOff() {
    }

    public void onBluetoothOn() {
    }

    public void onBluetoothServiceDown() {
    }

    public void onBluetoothServiceUp(IBluetooth iBluetooth) {
    }

    public void onBluetoothServiceUp(IBinder iBinder) {
    }

    public void onBrEdrDown() {
    }
}

