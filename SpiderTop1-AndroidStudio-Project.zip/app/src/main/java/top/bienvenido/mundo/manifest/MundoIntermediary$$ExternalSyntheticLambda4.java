/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnDismissListener
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package top.bienvenido.mundo.manifest;

import android.content.DialogInterface;
import java.util.concurrent.atomic.AtomicBoolean;
import top.bienvenido.mundo.manifest.MundoIntermediary;

public final class MundoIntermediary$$ExternalSyntheticLambda4
implements DialogInterface.OnDismissListener {
    public final /* synthetic */ MundoIntermediary f$0;
    public final /* synthetic */ AtomicBoolean f$1;

    public /* synthetic */ MundoIntermediary$$ExternalSyntheticLambda4(MundoIntermediary mundoIntermediary, AtomicBoolean atomicBoolean) {
        this.f$0 = mundoIntermediary;
        this.f$1 = atomicBoolean;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        MundoIntermediary.\u8d4b\u80fd(this.f$0, this.f$1, dialogInterface);
    }
}

