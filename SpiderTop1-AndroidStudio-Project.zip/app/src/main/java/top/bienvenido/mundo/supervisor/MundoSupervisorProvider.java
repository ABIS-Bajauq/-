/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u516c\u5173
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u6587\u6848
 *  top.bienvenido.date_24323.\u683c\u5c40
 *  top.bienvenido.date_24323.\u723d\u70b9
 *  top.bienvenido.date_24323.\u751f\u6001
 *  top.bienvenido.date_24323.\u75d2\u70b9
 *  top.bienvenido.date_24323.\u8fb9\u754c
 *  top.bienvenido.date_24323.\u94fe\u8def
 */
package top.bienvenido.mundo.supervisor;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import kotlin.Metadata;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u4f53\u7cfb;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u723d\u70b9;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u75d2\u70b9;
import top.bienvenido.date_24323.\u8f6c\u578b;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u94fe\u8def;

@Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"Ltop/bienvenido/mundo/supervisor/MundoSupervisorProvider;", "Landroid/content/ContentProvider;", "<init>", "()V", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoSupervisorProvider
extends ContentProvider {
    public final Bundle call(String string2, String string3, Bundle bundle) {
        \u8f6c\u578b.\u8d4b\u80fd.getClass();
        return \u8f6c\u578b.\u6293\u624b;
    }

    public final int delete(Uri uri, String string2, String[] arrstring) {
        return 0;
    }

    public final boolean onCreate() {
        \u4f53\u7cfb.\u6293\u624b();
        \u6587\u6848.\u843d\u5730.\u4e2d\u53f0 = \u516c\u5173.\u6293\u624b;
        \u4e0b\u6e38.\u843d\u5730.\u4e2d\u53f0 = \u8fb9\u754c.\u6293\u624b;
        \u723d\u70b9.\u843d\u5730.\u4e2d\u53f0 = \u75d2\u70b9.\u6293\u624b;
        \u94fe\u8def.\u843d\u5730.\u4e2d\u53f0 = \u5408\u529b.\u6293\u624b;
        \u751f\u6001.\u843d\u5730.\u4e2d\u53f0 = \u683c\u5c40.\u6293\u624b;
        return true;
    }

    public final int update(Uri uri, ContentValues contentValues, String string2, String[] arrstring) {
        return 0;
    }
}

