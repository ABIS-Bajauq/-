/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.String
 *  kotlin.Metadata
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.mundo.manifest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import kotlin.Metadata;
import top.bienvenido.date_24323.\u5408\u529b;

@Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"Ltop/bienvenido/mundo/manifest/MundoReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "()V", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoReceiver
extends BroadcastReceiver {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void onReceive(Context context, Intent intent) {
        String string2;
        \u5408\u529b \u5408\u529b2;
        Intent intent2;
        block6 : {
            block5 : {
                try {
                    \u5408\u529b2 = \u5408\u529b.\u6293\u624b;
                    if (intent == null) return;
                }
                catch (Exception exception) {
                    return;
                }
                intent2 = (Intent)intent.getParcelableExtra("android.intent.extra.INTENT");
                if (intent2 != null) break block5;
                return;
            }
            string2 = intent.getStringExtra(String.class.getName());
            if (string2 != null) break block6;
            string2 = "0";
        }
        \u5408\u529b2.\u6293\u624b(intent2, string2);
    }
}

