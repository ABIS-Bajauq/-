/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package top.bienvenido.mundo.common.reflection;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1={"\u0000\u0012\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\u00048\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0007\u0010\u0006\u00a8\u0006\t"}, d2={"top/bienvenido/mundo/common/reflection/MundoReflectionStub$NeverCall", "", "<init>", "()V", "", "i", "I", "j", "Companion", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoReflectionStub$NeverCall {
    public static final Companion Companion = new Companion(null);
    public static int s;
    public static int t;
    private final int i;
    private final int j;

    @JvmStatic
    private static final void a() {
        MundoReflectionStub$NeverCall.Companion.a();
    }

    @JvmStatic
    private static final void b() {
        MundoReflectionStub$NeverCall.Companion.b();
    }

    @Metadata(d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0003J\b\u0010\u0006\u001a\u00020\u0005H\u0003R\u0012\u0010\u0007\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\t\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2={"Ltop/bienvenido/mundo/common/reflection/MundoReflectionStub$NeverCall$Companion;", "", "<init>", "()V", "a", "", "b", "s", "", "t", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        private final void a() {
        }

        @JvmStatic
        private final void b() {
        }
    }

}

