/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package top.bienvenido.mundo.manifest;

import top.bienvenido.mundo.manifest.MundoSplashLauncher;

public final class MundoSplashLauncher$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MundoSplashLauncher$$ExternalSyntheticLambda0(String string2, String string3) {
        this.f$0 = string2;
        this.f$1 = string3;
    }

    public final void run() {
        MundoSplashLauncher.\u8d4b\u80fd(this.f$0, this.f$1);
    }
}

