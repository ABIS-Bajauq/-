/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u4f18\u79c0;
import top.bienvenido.date_24323.\u611f\u6069;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u901a\u9053
extends FunctionReferenceImpl
implements Function1 {
    public static final \u901a\u9053 \u8d4b\u80fd = new \u901a\u9053();

    public \u901a\u9053() {
        super(1, \u611f\u6069.class, "asInterface", "asInterface(Landroid/os/IBinder;)Ltop/bienvenido/mundo/IMundoActivityManagerService;", 0);
    }

    public final Object invoke(Object object) {
        IBinder iBinder = (IBinder)object;
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("MundoActivityManagerService");
        if (iInterface != null && iInterface instanceof \u7b14\u82af) {
            return (\u7b14\u82af)iInterface;
        }
        return new \u4f18\u79c0(iBinder);
    }
}

