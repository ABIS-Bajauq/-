/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u697c\u5c42
 */
package top.bienvenido.date_24323;

import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u697c\u5c42;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u697c\u5c42$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ List f$0;

    public /* synthetic */ \u697c\u5c42$$ExternalSyntheticLambda0(List list) {
        this.f$0 = list;
    }

    public final Object invoke(Object object) {
        return \u697c\u5c42.\u8d4b\u80fd((List)this.f$0, (\u94f8\u9020)((\u94f8\u9020)object));
    }
}

