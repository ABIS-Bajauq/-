/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ObbInfo
 *  android.os.storage.StorageManager
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u7cbe\u7ec6\u5316
 *  top.bienvenido.date_24323.\u7eb5\u5411
 *  top.bienvenido.date_24323.\u7ed3\u6784\u5316
 */
package top.bienvenido.date_24323;

import android.content.res.ObbInfo;
import android.os.storage.StorageManager;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7cbe\u7ec6\u5316;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u7ed3\u6784\u5316;
import top.bienvenido.date_24323.\u83b7\u5ba2;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u77ed\u5e73\u5feb
extends \u96c6\u6210 {
    public static final \u77ed\u5e73\u5feb \u6293\u624b = new \u77ed\u5e73\u5feb();

    @Override
    public final void \u8d4b\u80fd() {
        Class class_;
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        boolean bl = \u62bd\u8c61.\u843d\u5730;
        String string = bl ? null : "android.os.storage.IMountService$Stub";
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("mount", \u89e6\u53d12, string);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        if (bl) {
            \u771f\u9999.\u8d4b\u80fd(StorageManager.class, "sStorageManager", null);
        } else {
            if (\u62bd\u8c61.\u4e2d\u53f0) {
                \u771f\u9999.\u8d4b\u80fd(StorageManager.class, "sMountService", null);
            }
            \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df("mounted");
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1526098847, \u79c1\u57df2);
        }
        \u7eb5\u5411 \u7eb5\u54112 = new \u7eb5\u5411(ObbInfo.class, (Function2)new \u7ed3\u6784\u5316((Object)\u7cbe\u7ec6\u5316.\u8d4b\u80fd));
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-123808234, (Object)\u7eb5\u54112);
        \u4f18\u5148\u7ea7 \u4f18\u5148\u7ea72 = \u4f18\u5148\u7ea7.\u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1850562866, \u4f18\u5148\u7ea72);
        if (\u62bd\u8c61.\u5347\u7ea7 && !\u83b7\u5ba2.\u8d4b\u80fd(class_ = Class.forName((String)"android.common.HwFrameworkFactory"), "sFactory")) {
            \u83b7\u5ba2.\u8d4b\u80fd(class_, "obj");
        }
    }
}

