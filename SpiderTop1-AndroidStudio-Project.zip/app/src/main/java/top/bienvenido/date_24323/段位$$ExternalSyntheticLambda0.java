/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda0(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final void run() {
        \u6bb5\u4f4d.\u5e73\u53f0((IBinder)this.f$0);
    }
}

