/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 *  java.util.Collection
 *  kotlin.collections.CollectionsKt
 */
package top.bienvenido.date_24323;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;
import kotlin.collections.CollectionsKt;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u56f4\u7ed5$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u56f4\u7ed5 {
    public static Object \u8d4b\u80fd(Object object, \u89e6\u8fbe \u89e6\u8fbe2) {
        \u56f4\u7ed5$$ExternalSyntheticLambda0 \u56f4\u7ed5$$ExternalSyntheticLambda0 = new \u56f4\u7ed5$$ExternalSyntheticLambda0(\u89e6\u8fbe2, object);
        ClassLoader classLoader = object.getClass().getClassLoader();
        Class class_ = object.getClass();
        \u5dee\u5f02\u5316 \u5dee\u5f02\u53162 = new \u5dee\u5f02\u5316(2);
        \u56f4\u7ed5.\u8d4b\u80fd(class_, \u5dee\u5f02\u53162);
        return Proxy.newProxyInstance((ClassLoader)classLoader, (Class[])((Class[])\u5dee\u5f02\u53162.toArray((Object[])\u4e0b\u6c89.\u6293\u624b)), (InvocationHandler)\u56f4\u7ed5$$ExternalSyntheticLambda0);
    }

    public static final Object \u8d4b\u80fd(\u89e6\u8fbe \u89e6\u8fbe2, Object object, Object object2, Method method, Object[] arrobject) {
        if (arrobject == null) {
            arrobject = \u4e0b\u6c89.\u4e2d\u53f0;
        }
        return \u89e6\u8fbe2.\u8d4b\u80fd(object, method, arrobject);
    }

    public static void \u8d4b\u80fd(Class class_, \u5dee\u5f02\u5316 \u5dee\u5f02\u53162) {
        CollectionsKt.addAll((Collection)\u5dee\u5f02\u53162, (Object[])class_.getInterfaces());
        Class class_2 = class_.getSuperclass();
        if (Object.class.equals((Object)class_2)) {
            class_2 = null;
        }
        if (class_2 != null) {
            \u56f4\u7ed5.\u8d4b\u80fd(class_2, \u5dee\u5f02\u53162);
        }
    }
}

