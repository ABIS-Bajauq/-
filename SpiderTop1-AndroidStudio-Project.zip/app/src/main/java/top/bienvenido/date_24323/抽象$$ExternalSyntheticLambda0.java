/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u62bd\u8c61$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u81ea\u6d3d f$0;

    public /* synthetic */ \u62bd\u8c61$$ExternalSyntheticLambda0(\u81ea\u6d3d \u81ea\u6d3d2) {
        this.f$0 = \u81ea\u6d3d2;
    }

    public final Object invoke(Object object) {
        return \u62bd\u8c61.\u8d4b\u80fd(this.f$0, (String)object);
    }
}

