/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.AdaptiveIconDrawable
 *  android.graphics.drawable.Drawable
 *  android.util.TypedValue
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.concurrent.ExecutorService
 *  kotlin.Triple
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import kotlin.Triple;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u5185\u5377;
import top.bienvenido.date_24323.\u5916\u5305$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5916\u5305$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u84dd\u6d77;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u5916\u5305 {
    public static final \u81ea\u6d3d \u6293\u624b;
    public static \u6241\u5e73\u5316 \u8d4b\u80fd;

    static {
        \u81ea\u6d3d \u81ea\u6d3d2;
        \u8d4b\u80fd = new \u6241\u5e73\u5316(0);
        Class[] arrclass = new Class[]{ApplicationInfo.class, Integer.TYPE};
        try {
            Method method = Context.class.getDeclaredMethod("createApplicationContext", arrclass);
            method.setAccessible(true);
            \u81ea\u6d3d2 = new \u76ae\u5b9e(method);
        }
        catch (Exception exception) {
            \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
        }
        \u6293\u624b = \u81ea\u6d3d2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u6293\u624b() {
        try {
            \u6241\u5e73\u5316 \u6241\u5e73\u53162;
            \u8d4b\u80fd = \u6241\u5e73\u53162 = new \u6241\u5e73\u5316(0);
            Context context = \u98ce\u53e3.\u8d4b\u80fd;
            for (String string2 : \u8fb9\u754c.\u6293\u624b.\u6293\u624b()) {
                \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
                \u8fb9\u754c2.getClass();
                boolean bl = \u8fb9\u754c.\u4e2d\u53f0.containsKey(string2);
                ApplicationInfo applicationInfo = bl ? \u8fb9\u754c2.\u6293\u624b(string2, 0) : null;
                ApplicationInfo applicationInfo2 = applicationInfo;
                \u5916\u5305$$ExternalSyntheticLambda1 \u5916\u5305$$ExternalSyntheticLambda1 = new \u5916\u5305$$ExternalSyntheticLambda1(bl, context, string2, applicationInfo2, \u6241\u5e73\u53162);
                \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5916\u5305$$ExternalSyntheticLambda1);
            }
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static \u5185\u5377 \u8d4b\u80fd(Context context) {
        try {
            int n;
            Drawable drawable2;
            int n2;
            ActivityInfo activityInfo = \u84dd\u6d77.\u8d4b\u80fd(context.getPackageName());
            if (activityInfo == null) {
                return null;
            }
            int n3 = activityInfo.getThemeResource();
            if (n3 == 0) return null;
            Resources.Theme theme = context.getResources().newTheme();
            theme.applyStyle(n3, true);
            TypedValue typedValue = new TypedValue();
            if (theme.resolveAttribute(16842836, typedValue, true) && (n2 = typedValue.resourceId) != 0 && ((n = typedValue.type) < 28 || n > 31) && (drawable2 = theme.getDrawable(n2)) != null) {
                return new \u5185\u5377(drawable2, null);
            }
            if (!\u62bd\u8c61.\u5e73\u53f0) return null;
            return \u5916\u5305.\u8d4b\u80fd(theme, typedValue);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static \u5185\u5377 \u8d4b\u80fd(Resources.Theme theme, TypedValue typedValue) {
        Drawable drawable2;
        Drawable drawable3;
        block6 : {
            block5 : {
                try {
                    int n;
                    if (!theme.resolveAttribute(16844333, typedValue, true)) {
                        return null;
                    }
                    int n2 = typedValue.resourceId;
                    if (n2 == 0) {
                        return null;
                    }
                    drawable2 = theme.getDrawable(n2);
                    if (drawable2 == null) {
                        return null;
                    }
                    if (!theme.resolveAttribute(16844335, typedValue, true) || (n = typedValue.resourceId) == 0) break block5;
                    drawable3 = theme.getDrawable(n);
                    break block6;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            drawable3 = null;
        }
        Integer n = theme.resolveAttribute(16844332, typedValue, true) ? Integer.valueOf((int)typedValue.data) : null;
        Integer n3 = (!\u62bd\u8c61.\u843d\u5730 || !(drawable2 instanceof AdaptiveIconDrawable)) && theme.resolveAttribute(16844336, typedValue, true) ? Integer.valueOf((int)typedValue.data) : null;
        return new \u5185\u5377(drawable2, new Triple((Object)drawable3, (Object)n, (Object)n3));
    }

    public static void \u8d4b\u80fd() {
        \u5916\u5305$$ExternalSyntheticLambda0 \u5916\u5305$$ExternalSyntheticLambda0 = new \u5916\u5305$$ExternalSyntheticLambda0();
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5916\u5305$$ExternalSyntheticLambda0);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static final void \u8d4b\u80fd(boolean var0, Context var1_1, String var2_2, ApplicationInfo var3_3, \u6241\u5e73\u5316 var4_4) {
        block7 : {
            if (var0) ** GOTO lbl5
            var6_5 = var1_1.createPackageContext(var2_2, 3);
            break block7;
lbl5: // 1 sources:
            var6_5 = (Context)\u5916\u5305.\u6293\u624b.\u8d4b\u80fd((Object)var1_1, new Object[]{var3_3, 0});
        }
        var7_6 = \u5916\u5305.\u8d4b\u80fd(var6_5);
        if (var7_6 == null) {
            return;
        }
        var10_7 = var4_4;
        // MONITORENTER : var10_7
        var4_4.\u8d4b\u80fd(var2_2.hashCode(), var7_6);
        try {
            // MONITOREXIT : var10_7
            return;
        }
        catch (Exception var5_8) {
            return;
        }
    }
}

