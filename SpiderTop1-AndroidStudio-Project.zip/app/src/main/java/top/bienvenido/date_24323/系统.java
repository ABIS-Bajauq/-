/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 *  kotlin.reflect.KMutableProperty1
 */
package top.bienvenido.date_24323;

import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.reflect.KMutableProperty1;

public final class \u7cfb\u7edf
extends FunctionReferenceImpl
implements Function2 {
    public \u7cfb\u7edf(Object object) {
        super(2, object, KMutableProperty1.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        ResolveInfo resolveInfo = (ResolveInfo)object;
        ProviderInfo providerInfo = (ProviderInfo)object2;
        ((KMutableProperty1)this.receiver).set((Object)resolveInfo, (Object)providerInfo);
        return Unit.INSTANCE;
    }
}

