/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.job.JobInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.app.job.JobInfo;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8bc4\u5ba1;

public final class \u8bc4\u4f30
extends \u89e6\u53d1 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
        JobInfo jobInfo = (JobInfo)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, JobInfo.class);
        if (jobInfo == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            \u8bc4\u5ba1.\u6293\u624b.getClass();
            \u8bc4\u5ba1.\u8d4b\u80fd(jobInfo);
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

