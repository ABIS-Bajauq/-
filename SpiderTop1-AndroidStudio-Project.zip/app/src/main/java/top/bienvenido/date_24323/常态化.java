/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AppCompatCallbacks
 *  android.graphics.Compatibility
 *  android.graphics.RecordingCanvas
 *  android.os.StrictMode
 *  dalvik.system.ZipPathValidator
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.security.Security
 *  kotlin.collections.ArraysKt
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.app.AppCompatCallbacks;
import android.graphics.Compatibility;
import android.graphics.RecordingCanvas;
import android.os.StrictMode;
import dalvik.system.ZipPathValidator;
import java.security.Security;
import kotlin.collections.ArraysKt;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public abstract class \u5e38\u6001\u5316 {
    public static void \u6293\u624b() {
        long[] arrl;
        Object object;
        \u8d77\u98de \u8d77\u98de2;
        block4 : {
            try {
                \u8d77\u98de2 = new \u8d77\u98de("disabledCompatChanges");
                \u6bb5\u4f4d.\u6293\u624b.getClass();
                object = \u6bb5\u4f4d.\u6f0f\u6597;
                arrl = (long[])\u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object);
                if (arrl != null) break block4;
                return;
            }
            catch (Throwable throwable) {
                return;
            }
        }
        long[] arrl2 = ArraysKt.plus((long[])arrl, (long[])new long[]{218865702L, 154726397L, 241104082L, 255371817L, 160794467L, 148963590L, 171317480L, 144027538L, 148964793L, 169887240L, 147798919L, 309578419L, 270674727L});
        ArraysKt.sort((long[])arrl2);
        \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object, (Object)arrl2);
        if (\u62bd\u8c61.\u5bf9\u9f50) {
            AppCompatCallbacks.install((long[])arrl2, (long[])((long[])new \u8d77\u98de((String)"mLoggableCompatChanges").\u6293\u624b.\u8d4b\u80fd(object)));
            return;
        }
        AppCompatCallbacks.install((long[])arrl2);
    }

    public static void \u8d4b\u80fd() {
        try {
            if (\u62bd\u8c61.\u4e2d\u53f0) {
                \u771f\u9999.\u6293\u624b(StrictMode.class, "disableDeathOnFileUriExposure").\u8d4b\u80fd((Object)null, new Object[0]);
                if (\u62bd\u8c61.\u6f0f\u6597) {
                    Security.removeProvider((String)"AndroidNSSP");
                    if (\u62bd\u8c61.\u6c89\u6dc0) {
                        \u771f\u9999.\u8d4b\u80fd(RecordingCanvas.class, "MAX_BITMAP_SIZE", Integer.MAX_VALUE);
                        if (\u62bd\u8c61.\u7ed9\u5230) {
                            \u5e38\u6001\u5316.\u6293\u624b();
                            if (\u62bd\u8c61.\u5e73\u53f0) {
                                Compatibility.setTargetSdkVersion((int)3);
                                if (\u62bd\u8c61.\u540c\u6b65) {
                                    ZipPathValidator.clearCallback();
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

