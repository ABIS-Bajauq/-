/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 *  kotlin.reflect.KMutableProperty1
 */
package top.bienvenido.date_24323;

import android.view.WindowManager;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.reflect.KMutableProperty1;

public final class \u7a33\u5b9a\u6027
extends FunctionReferenceImpl
implements Function2 {
    public \u7a33\u5b9a\u6027(Object object) {
        super(2, object, KMutableProperty1.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams)object;
        String string = (String)object2;
        ((KMutableProperty1)this.receiver).set((Object)layoutParams, (Object)string);
        return Unit.INSTANCE;
    }
}

