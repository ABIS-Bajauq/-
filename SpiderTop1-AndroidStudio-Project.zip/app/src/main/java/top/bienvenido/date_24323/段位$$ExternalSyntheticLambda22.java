/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda22
implements Function0 {
    public final Object invoke() {
        return \u6bb5\u4f4d.\u5bf9\u9f50();
    }
}

