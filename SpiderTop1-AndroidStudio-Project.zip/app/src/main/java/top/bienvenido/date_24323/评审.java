/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.job.JobInfo
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.IBinder
 *  android.os.PersistableBundle
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u8bc4\u4f30
 */
package top.bienvenido.date_24323;

import android.app.job.JobInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.PersistableBundle;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8bc4\u4f30;
import top.bienvenido.date_24323.\u8bc4\u5ba1$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.common.ext.MundoServiceConnection;
import top.bienvenido.mundo.manifest.MundoService$Companion$STUB;

public final class \u8bc4\u5ba1
extends \u96c6\u6210 {
    public static final \u8d77\u98de \u4e2d\u53f0;
    public static final \u8bc4\u5ba1 \u6293\u624b;
    public static final \u5e73\u53f0\u5316 \u843d\u5730;
    public static final \u8d77\u98de \u95ed\u73af;

    static {
        \u6293\u624b = new \u8bc4\u5ba1();
        \u4e2d\u53f0 = new \u8d77\u98de("service");
        \u95ed\u73af = new \u8d77\u98de("extras");
        \u843d\u5730 = new \u5e73\u53f0\u5316(8);
    }

    public static final int \u8d4b\u80fd(ComponentName componentName, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u6293\u624b(new Intent().setComponent(componentName), (IBinder)new MundoServiceConnection(null), \u6c34\u4f4d.\u95ed\u73af);
    }

    public static void \u8d4b\u80fd(JobInfo jobInfo) {
        String string;
        ComponentName componentName = jobInfo.getService();
        String string2 = componentName.getPackageName();
        if (Intrinsics.areEqual((Object)string2, (Object)(string = \u98ce\u53e3.\u6293\u624b))) {
            return;
        }
        \u5e73\u53f0\u5316 \u5e73\u53f0\u53162 = \u843d\u5730;
        if (\u5e73\u53f0\u53162.\u8d4b\u80fd(componentName.getClassName().hashCode())) {
            \u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u8bc4\u5ba1$$ExternalSyntheticLambda0(componentName));
            if (\u5e73\u53f0\u53162.\u6293\u624b > 128) {
                \u5e73\u53f0\u53162.\u6293\u624b = 0;
            }
        }
        \u8d77\u98de \u8d77\u98de2 = \u95ed\u73af;
        PersistableBundle persistableBundle = new PersistableBundle();
        persistableBundle.putPersistableBundle("mundo_base_bundle", jobInfo.getExtras());
        persistableBundle.putString("mundo_base_string", componentName.flattenToString());
        \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)jobInfo, (Object)persistableBundle);
        \u8d77\u98de \u8d77\u98de3 = \u4e2d\u53f0;
        String string3 = MundoService$Companion$STUB.class.getName();
        int n = \u6c34\u4f4d.\u6c89\u6dc0;
        ComponentName componentName2 = new ComponentName(string, string3 + n);
        \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd((Object)jobInfo, (Object)componentName2);
    }

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("jobscheduler", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{2027195101, -697920873, -1594257912}, (\u89e6\u8fbe)new \u8bc4\u4f30());
    }
}

