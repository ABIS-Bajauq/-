/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u56f0\u5c40;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u73af\u8282
extends \u89e6\u8fbe {
    public final /* synthetic */ \u56f0\u5c40 \u6293\u624b;
    public final /* synthetic */ Function1 \u8d4b\u80fd;

    public \u73af\u8282(Function1 function1, \u56f0\u5c40 \u56f0\u5c402) {
        this.\u8d4b\u80fd = function1;
        this.\u6293\u624b = \u56f0\u5c402;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        block3 : {
            Object object2;
            try {
                object2 = method.invoke(object, arrobject);
                if (object2 == null) break block3;
            }
            catch (Exception exception) {
                return null;
            }
            Function1 function1 = this.\u8d4b\u80fd;
            \u56f0\u5c40 \u56f0\u5c402 = this.\u6293\u624b;
            Object object3 = function1.invoke(object2);
            \u56f0\u5c402.\u8d4b\u80fd = new \u79c1\u57df(object3);
            return object3;
        }
        return null;
    }
}

