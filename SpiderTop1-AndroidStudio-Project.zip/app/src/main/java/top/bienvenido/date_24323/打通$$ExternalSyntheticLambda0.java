/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6253\u901a
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import top.bienvenido.date_24323.\u6253\u901a;

public final class \u6253\u901a$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ Intent f$0;

    public /* synthetic */ \u6253\u901a$$ExternalSyntheticLambda0(Intent intent) {
        this.f$0 = intent;
    }

    public final void run() {
        \u6253\u901a.\u8d4b\u80fd((Intent)this.f$0);
    }
}

