/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;
import top.bienvenido.date_24323.\u683c\u5c40;

public final class \u4fc3\u6d3b
extends \u5f00\u573a\u5b50 {
    public final String[] \u540c\u6b65;
    public ArrayList \u5bf9\u6807;
    public Account[] \u5bf9\u9f50;
    public int \u8fed\u4ee3;

    public \u4fc3\u6d3b(IAccountManagerResponse iAccountManagerResponse, String string, String[] arrstring) {
        super(iAccountManagerResponse, string, false, true, null, false, false);
        this.\u540c\u6b65 = arrstring;
    }

    @Override
    public final void onResult(Bundle bundle) {
        if (bundle == null) {
            this.onError(5, "null bundle");
            return;
        }
        if (bundle.getBoolean("booleanResult", false)) {
            this.\u5bf9\u6807.add((Object)this.\u5bf9\u9f50[this.\u8fed\u4ee3]);
        }
        this.\u8fed\u4ee3 = 1 + this.\u8fed\u4ee3;
        this.\u5bf9\u6807();
    }

    public final void \u5bf9\u6807() {
        Account[] arraccount;
        IAccountAuthenticator iAccountAuthenticator;
        int n;
        block14 : {
            block13 : {
                block12 : {
                    n = this.\u8fed\u4ee3;
                    arraccount = this.\u5bf9\u9f50;
                    if (n < arraccount.length) break block12;
                    IAccountManagerResponse iAccountManagerResponse = this.\u540c\u6b65();
                    if (iAccountManagerResponse != null) {
                        int n2 = this.\u5bf9\u6807.size();
                        Account[] arraccount2 = new Account[n2];
                        for (int i = 0; i < n2; ++i) {
                            arraccount2[i] = this.\u5bf9\u6807.get(i);
                        }
                        try {
                            Bundle bundle = new Bundle();
                            bundle.putParcelableArray("accounts", (Parcelable[])arraccount2);
                            iAccountManagerResponse.onResult(bundle);
                            return;
                        }
                        catch (Exception exception) {
                            return;
                        }
                    }
                    break block13;
                }
                iAccountAuthenticator = this.\u7ed9\u5230;
                if (iAccountAuthenticator != null) break block14;
            }
            return;
        }
        try {
            iAccountAuthenticator.hasFeatures((IAccountAuthenticatorResponse)this, arraccount[n], this.\u540c\u6b65);
            return;
        }
        catch (Exception exception) {
            this.onError(1, "remote exception");
            return;
        }
    }

    @Override
    public final void \u5bf9\u9f50() {
        Account[] arraccount = \u683c\u5c40.\u6293\u624b.\u8ddf\u8fdb(this.\u8d4b\u80fd);
        this.\u5bf9\u6807 = new ArrayList(arraccount.length);
        this.\u5bf9\u9f50 = arraccount;
        this.\u8fed\u4ee3 = 0;
        this.\u5bf9\u6807();
    }
}

