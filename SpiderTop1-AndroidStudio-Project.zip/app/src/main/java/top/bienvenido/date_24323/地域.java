/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function3
 *  top.bienvenido.date_24323.\u5c5e\u6027
 *  top.bienvenido.date_24323.\u7c98\u6027
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import top.bienvenido.date_24323.\u5c5e\u6027;
import top.bienvenido.date_24323.\u5e74\u6846;
import top.bienvenido.date_24323.\u7c98\u6027;
import top.bienvenido.date_24323.\u8499\u5c42;

public final class \u5730\u57df
extends \u8499\u5c42 {
    public final \u7c98\u6027 \u6293\u624b = new \u7c98\u6027();
    public final \u5c5e\u6027 \u8d4b\u80fd = \u5c5e\u6027.\u8d4b\u80fd;

    @Override
    public final Function3 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        \u5e74\u6846.\u8d4b\u80fd(\u5e74\u6846.\u6293\u624b, arrobject);
        return super.\u8d4b\u80fd(object, method, arrobject);
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

