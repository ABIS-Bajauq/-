/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u6253\u901a
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6253\u901a;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u6253\u901a$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Intent f$0;

    public /* synthetic */ \u6253\u901a$$ExternalSyntheticLambda1(Intent intent) {
        this.f$0 = intent;
    }

    public final Object invoke(Object object) {
        return \u6253\u901a.\u8d4b\u80fd((Intent)this.f$0, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

