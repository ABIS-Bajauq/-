/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u6e17\u900f
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            if (Intrinsics.areEqual((Object)object2, (Object)59) || Intrinsics.areEqual((Object)object2, (Object)60) || Intrinsics.areEqual((Object)object2, (Object)92)) {
                Integer n = 0;
                return n;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

