/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.AdaptedFunctionReference
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.AdaptedFunctionReference;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u8e1d\u90e8;

public final class \u660e\u7ade\u4e89
extends AdaptedFunctionReference
implements Function1 {
    public static final \u660e\u7ade\u4e89 \u8d4b\u80fd = new \u660e\u7ade\u4e89();

    public \u660e\u7ade\u4e89() {
        super(1, \u6253\u78e8.class, "returnThisFunction", "returnThisFunction(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;", 1);
    }

    public final Object invoke(Object object) {
        return (\u8e1d\u90e8)object;
    }
}

