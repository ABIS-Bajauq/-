/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ProviderInfo
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ProviderInfo;
import android.os.IBinder;
import android.os.IInterface;
import java.util.ArrayList;

public interface \u7b14\u82af
extends IInterface {
    public int \u4e2d\u53f0(Intent var1, String var2);

    public boolean \u4e2d\u53f0(IBinder var1);

    public void \u5e73\u53f0(String var1);

    public int \u6293\u624b(Intent var1, IBinder var2, String var3);

    public int \u6293\u624b(Intent var1, String var2);

    public void \u6293\u624b(IBinder var1);

    public ArrayList \u6f0f\u6597(int var1);

    public boolean \u6f0f\u6597(String var1, String var2);

    public ComponentName \u843d\u5730(Intent var1, String var2);

    public IBinder \u8d4b\u80fd(ComponentName var1, String var2);

    public IBinder \u8d4b\u80fd(String var1, String var2, ProviderInfo[] var3, String[] var4, int var5);

    public void \u8d4b\u80fd(int var1, IBinder var2, IntentFilter var3);

    public void \u8d4b\u80fd(String var1, String var2, String var3);

    public boolean \u8d4b\u80fd(ComponentName var1, IBinder var2, int var3);

    public boolean \u8d4b\u80fd(IBinder var1, Intent var2, IBinder var3);

    public IBinder \u95ed\u73af(Intent var1, String var2);

    public void \u95ed\u73af();

    public void \u95ed\u73af(String var1, String var2);

    public String[] \u95ed\u73af(int var1);
}

