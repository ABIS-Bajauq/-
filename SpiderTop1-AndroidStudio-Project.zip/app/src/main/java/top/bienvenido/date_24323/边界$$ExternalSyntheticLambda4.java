/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.List
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import java.util.List;
import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ List f$0;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda4(List list) {
        this.f$0 = list;
    }

    public final void run() {
        \u8fb9\u754c.\u6293\u624b((List)this.f$0);
    }
}

