/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.telephony.SubscriptionInfo
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.collections.CollectionsKt
 *  sun.misc.Unsafe
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.telephony.SubscriptionInfo;
import java.security.SecureRandom;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u9020\u5e02 {
    public static final ArrayList \u4e2d\u53f0;
    public static final String \u6293\u624b;
    public static final String \u8d4b\u80fd;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        ArrayList arrayList;
        block16 : {
            block14 : {
                SubscriptionInfo subscriptionInfo;
                Object[] arrobject;
                block15 : {
                    char c;
                    Pair[] arrpair;
                    StringBuilder stringBuilder = new StringBuilder();
                    SecureRandom secureRandom = new SecureRandom();
                    for (int i = 0; i < 16; ++i) {
                        stringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(secureRandom.nextInt(36)));
                    }
                    \u8d4b\u80fd = stringBuilder.toString();
                    String[] arrstring = new String[]{"35133133", "86576905", "86811305", "86538206", "35619596", "86415006", "86953506", "86866106"};
                    SecureRandom secureRandom2 = new SecureRandom();
                    StringBuilder stringBuilder2 = new StringBuilder(arrstring[secureRandom2.nextInt(8)]);
                    for (int i = 0; i < 6; ++i) {
                        stringBuilder2.append(secureRandom2.nextInt(10));
                    }
                    String string2 = stringBuilder2.toString();
                    int n = 0;
                    int n2 = 0;
                    int n3 = 0;
                    do {
                        c = '0';
                        if (n >= 14) break;
                        if (n % 2 == 0) {
                            n2 = -48 + (n2 + string2.charAt(n));
                        } else {
                            int n4 = 2 * (string2.charAt(n) - c);
                            n3 = n4 < 10 ? (n3 += n4) : n4 + (n3 + 1) - 10;
                        }
                        ++n;
                    } while (true);
                    int n5 = (n2 + n3) % 10;
                    if (n5 != 0) {
                        c = (char)(58 - n5);
                    }
                    stringBuilder2.append(c);
                    \u6293\u624b = stringBuilder2.toString();
                    if (!\u62bd\u8c61.\u6293\u624b) break block14;
                    arrobject = new SubscriptionInfo[1];
                    subscriptionInfo = (SubscriptionInfo)\u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(SubscriptionInfo.class);
                    try {
                        Pair pair = TuplesKt.to((Object)"mDisplayName", (Object)"Three.62v.net");
                        String string3 = \u8d4b\u80fd;
                        Pair[] arrpair2 = new Pair[]{pair, TuplesKt.to((Object)"mIccId", (Object)string3), TuplesKt.to((Object)"mCarrierName", (Object)"Three.62v.net"), TuplesKt.to((Object)"mNumber", (Object)String.valueOf((long)System.currentTimeMillis())), TuplesKt.to((Object)"mCountryIso", (Object)"826")};
                        for (int i = 0; i < 5; ++i) {
                            Pair pair2 = arrpair2[i];
                            String string4 = (String)pair2.getFirst();
                            Object object = pair2.getSecond();
                            new \u8d77\u98de((String)string4).\u6293\u624b.\u8d4b\u80fd((Object)subscriptionInfo, object);
                        }
                        if (!\u62bd\u8c61.\u6c89\u6dc0) break block15;
                        Pair pair3 = TuplesKt.to((Object)"mGroupOwner", (Object)"");
                        Pair pair4 = TuplesKt.to((Object)"mCardString", (Object)string3);
                        String[] arrstring2 = \u4e0b\u6c89.\u95ed\u73af;
                        arrpair = new Pair[]{pair3, pair4, TuplesKt.to((Object)"mEhplmns", (Object)arrstring2), TuplesKt.to((Object)"mHplmns", (Object)arrstring2)};
                    }
                    catch (Exception exception) {
                        // empty catch block
                        break block15;
                    }
                    for (int i = 0; i < 4; ++i) {
                        Pair pair = arrpair[i];
                        String string5 = (String)pair.getFirst();
                        Object object = pair.getSecond();
                        new \u8d77\u98de((String)string5).\u6293\u624b.\u8d4b\u80fd((Object)subscriptionInfo, object);
                    }
                }
                try {
                    arrobject[0] = subscriptionInfo;
                    arrayList = CollectionsKt.arrayListOf((Object[])arrobject);
                    break block16;
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            arrayList = null;
        }
        \u4e2d\u53f0 = arrayList;
    }
}

