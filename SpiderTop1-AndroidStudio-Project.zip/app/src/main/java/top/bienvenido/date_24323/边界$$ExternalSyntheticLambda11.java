/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda11
implements Function0 {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda11(String string) {
        this.f$0 = string;
    }

    public final Object invoke() {
        return \u8fb9\u754c.\u590d\u76d8(this.f$0);
    }
}

