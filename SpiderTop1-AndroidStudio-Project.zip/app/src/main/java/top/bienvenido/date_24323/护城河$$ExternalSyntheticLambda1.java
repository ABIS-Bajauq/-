/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;

public final class \u62a4\u57ce\u6cb3$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Method f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Class f$2;
    public final /* synthetic */ long f$3;

    public /* synthetic */ \u62a4\u57ce\u6cb3$$ExternalSyntheticLambda1(Method method, Object object, Class class_, long l) {
        this.f$0 = method;
        this.f$1 = object;
        this.f$2 = class_;
        this.f$3 = l;
    }

    public final Object invoke(Object object) {
        return \u62a4\u57ce\u6cb3.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, this.f$3, object);
    }
}

