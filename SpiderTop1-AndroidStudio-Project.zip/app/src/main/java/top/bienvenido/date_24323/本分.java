/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Pair
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u672c\u5206
extends \u81ea\u6d3d {
    public final /* synthetic */ Pair \u6293\u624b;

    public \u672c\u5206(Pair pair) {
        this.\u6293\u624b = pair;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object) {
        return ((Function0)this.\u6293\u624b.getFirst()).invoke();
    }

    @Override
    public final void \u8d4b\u80fd(Object object, Object object2) {
        ((Function1)this.\u6293\u624b.getSecond()).invoke(object2);
    }
}

