/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.IServiceConnection
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.collections.ArraysKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.app.IServiceConnection;
import android.content.ComponentName;
import android.content.Intent;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4ed8\u8d39;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u91cf\u5316$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u91cf\u5316
extends \u89e6\u53d1 {
    public static final int \u8d4b\u80fd(Intent intent, IServiceConnection iServiceConnection, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u6293\u624b(intent, iServiceConnection.asBinder(), \u6c34\u4f4d.\u95ed\u73af);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        String string;
        Intent intent;
        block4 : {
            int n;
            try {
                int n2;
                Integer n3;
                String string2;
                if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
                intent = (Intent)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Intent.class);
                if (intent == null) return super.\u8d4b\u80fd(object, method, arrobject);
                ComponentName componentName = intent.getComponent();
                if (componentName == null || (string2 = componentName.getPackageName()) == null) {
                    string2 = intent.getPackage();
                }
                if (Intrinsics.areEqual((Object)string2, (Object)\u98ce\u53e3.\u6293\u624b)) return super.\u8d4b\u80fd(object, method, arrobject);
                IServiceConnection iServiceConnection = (IServiceConnection)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, IServiceConnection.class);
                if (iServiceConnection != null && (n2 = (n3 = (Integer)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u91cf\u5316$$ExternalSyntheticLambda0(intent, iServiceConnection))) != null ? n3 : -1) >= 0) {
                    return n2;
                }
                if (string2 == null) return super.\u8d4b\u80fd(object, method, arrobject);
                n = string2.hashCode();
                if (!\u4ed8\u8d39.\u8d4b\u80fd && ArraysKt.contains((int[])\u4ed8\u8d39.\u6293\u624b, (int)n)) break block4;
            }
            catch (Throwable throwable) {
                // empty catch block
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            if (n != -1115994113) return super.\u8d4b\u80fd(object, method, arrobject);
        }
        int n = (string = intent.getAction()) != null ? string.hashCode() : 0;
        int n4 = 0;
        if (n != 1035177747) return n4;
        n4 = 1;
        return n4;
    }
}

