/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u68b3\u7406$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u68b3\u7406
extends \u89e6\u8fbe {
    public static final Account[] \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        Object object = arrobject[0];
        String string = object != null ? object.toString() : null;
        return \u589e\u957f2.\u8ddf\u8fdb(string);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Account[] arraccount = (Account[])\u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u68b3\u7406$$ExternalSyntheticLambda0(arrobject));
        if (arraccount == null) {
            arraccount = new Account[]{};
        }
        return arraccount;
    }
}

