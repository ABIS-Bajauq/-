/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u73af\u8282;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u56f0\u5c40
extends \u89e6\u8fbe {
    public \u89e6\u8fbe \u8d4b\u80fd;

    public \u56f0\u5c40(Function1 function1) {
        this.\u8d4b\u80fd = new \u73af\u8282(function1, this);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return this.\u8d4b\u80fd.\u8d4b\u80fd(object, method, arrobject);
    }
}

