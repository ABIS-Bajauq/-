/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.ExecutorService
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import java.util.concurrent.ExecutorService;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u9635\u5730$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u9ad8\u5730;

public final class \u9635\u5730
implements IBinder.DeathRecipient {
    public final /* synthetic */ \u54c1\u724c \u6293\u624b;
    public final /* synthetic */ IBinder \u8d4b\u80fd;

    public \u9635\u5730(IBinder iBinder, \u54c1\u724c \u54c1\u724c2) {
        this.\u8d4b\u80fd = iBinder;
        this.\u6293\u624b = \u54c1\u724c2;
    }

    public static final void \u8d4b\u80fd(IBinder iBinder, \u9635\u5730 \u9635\u57302, \u54c1\u724c \u54c1\u724c2) {
        try {
            iBinder.unlinkToDeath((IBinder.DeathRecipient)\u9635\u57302, 0);
            \u9ad8\u5730.\u6293\u624b(\u54c1\u724c2);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final void binderDied() {
        \u9635\u5730$$ExternalSyntheticLambda0 \u9635\u5730$$ExternalSyntheticLambda0 = new \u9635\u5730$$ExternalSyntheticLambda0(this.\u8d4b\u80fd, this, this.\u6293\u624b);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u9635\u5730$$ExternalSyntheticLambda0);
    }
}

