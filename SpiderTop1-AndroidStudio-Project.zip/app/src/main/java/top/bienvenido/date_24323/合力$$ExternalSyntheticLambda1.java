/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda1(String string2) {
        this.f$0 = string2;
    }

    public final void run() {
        \u5408\u529b.\u5347\u7ea7((String)this.f$0);
    }
}

