/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.ConcurrentLinkedDeque
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import java.util.concurrent.ConcurrentLinkedDeque;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;

public final class \u8bae\u7a0b
extends FunctionReferenceImpl
implements Function0 {
    public static final \u8bae\u7a0b \u8d4b\u80fd = new \u8bae\u7a0b();

    public \u8bae\u7a0b() {
        super(0, ConcurrentLinkedDeque.class, "<init>", "<init>()V", 0);
    }

    public final Object invoke() {
        return new ConcurrentLinkedDeque();
    }
}

