/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageInstaller
 *  android.content.pm.PackageInstaller$SessionParams
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u62c6\u89e3
 *  top.bienvenido.date_24323.\u7eb5\u5411
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageInstaller;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0a\u62a5;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u56f0\u5c40;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6293\u5305;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u62c6\u89e3;
import top.bienvenido.date_24323.\u6355\u83b7$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6355\u83b7$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u76d1\u63a7;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u89c2\u5bdf;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u6355\u83b7
extends \u89e6\u8fbe {
    public static final \u6293\u5305 \u4e2d\u53f0;
    public static final \u76d1\u63a7 \u6293\u624b;
    public static final \u89c2\u5bdf \u843d\u5730;
    public static final \u6355\u83b7 \u8d4b\u80fd;
    public static final \u4e0a\u62a5 \u95ed\u73af;

    static {
        \u8d4b\u80fd = new \u6355\u83b7();
        \u6293\u624b = new \u76d1\u63a7();
        \u4e2d\u53f0 = new \u6293\u5305();
        \u95ed\u73af = new \u4e0a\u62a5();
        \u843d\u5730 = new \u89c2\u5bdf();
    }

    public static final int \u8d4b\u80fd(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u4f18\u5316(string);
    }

    public static final Object \u8d4b\u80fd(Object object) {
        \u89e6\u53d1 \u89e6\u53d12 = \u62bd\u8c61.\u540c\u6b65 ? new \u7eb5\u5411(PackageInstaller.SessionParams.class, (Function2)\u62c6\u89e3.\u8d4b\u80fd, null) : \u672c\u6211.\u4e2d\u53f0;
        return \u56f4\u7ed5.\u8d4b\u80fd(object, \u89e6\u53d12);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            String string = object2 != null ? object2.toString() : null;
            if (!\u6c34\u4f4d.\u8d4b\u80fd) return method.invoke(object, arrobject);
            if (string == null) return method.invoke(object, arrobject);
            if (Intrinsics.areEqual((Object)string, (Object)\u6c34\u4f4d.\u6293\u624b)) {
                return \u98ce\u53e3.\u4e2d\u53f0;
            }
            Integer n = (Integer)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u6355\u83b7$$ExternalSyntheticLambda0(string));
            if (n == null) return method.invoke(object, arrobject);
            int n2 = n;
            if (n2 < 0) return method.invoke(object, arrobject);
            return n2;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }

    public final void \u8d4b\u80fd(\u51fa\u51fb \u51fa\u51fb2) {
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-268426720, this);
        \u76d1\u63a7 \u76d1\u63a72 = \u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-923564278, \u76d1\u63a72);
        \u6293\u5305 \u6293\u53052 = \u4e2d\u53f0;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1422431960, \u6293\u53052);
        \u4e0a\u62a5 \u4e0a\u62a52 = \u95ed\u73af;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1118934913, \u4e0a\u62a52);
        \u56f0\u5c40 \u56f0\u5c402 = new \u56f0\u5c40(new \u6355\u83b7$$ExternalSyntheticLambda1());
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(433060184, \u56f0\u5c402);
        \u53d8\u8fc1 \u53d8\u8fc12 = \u672c\u6211.\u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(268289313, \u53d8\u8fc12);
        \u89c2\u5bdf \u89c2\u5bdf2 = \u843d\u5730;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-2128065382, \u89c2\u5bdf2);
    }
}

