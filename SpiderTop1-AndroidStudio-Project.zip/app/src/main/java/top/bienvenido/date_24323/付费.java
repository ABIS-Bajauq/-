/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

public abstract class \u4ed8\u8d39 {
    public static final int[] \u6293\u624b = new int[]{325967443, 325967270, -1046965711};
    public static boolean \u8d4b\u80fd;
}

