/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.TaskInfo
 *  android.window.IWindowContainerToken
 *  android.window.WindowContainerToken
 *  java.lang.Object
 *  java.lang.Throwable
 *  kotlin.jvm.functions.Function0
 *  top.bienvenido.date_24323.\u4e0d\u53ef\u63a7$
 *  top.bienvenido.date_24323.\u4e0d\u53ef\u63a7$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u4e0d\u53ef\u63a7$$ExternalSyntheticLambda1
 */
package top.bienvenido.date_24323;

import android.app.TaskInfo;
import android.window.IWindowContainerToken;
import android.window.WindowContainerToken;
import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u4e0d\u53ef\u63a7$;
import top.bienvenido.date_24323.\u5f3a\u4f9d\u8d56;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public abstract class \u4e0d\u53ef\u63a7 {
    public static final \u81ea\u6d3d \u4e2d\u53f0;
    public static final \u81ea\u6d3d \u6293\u624b;
    public static Function0 \u8d4b\u80fd;

    static {
        \u8d4b\u80fd = new $ExternalSyntheticLambda0();
        \u81ea\u6d3d \u81ea\u6d3d2 = \u62bd\u8c61.\u7ed9\u5230 ? \u771f\u9999.\u8d4b\u80fd(TaskInfo.class, "token") : \u81ea\u6d3d.\u8d4b\u80fd;
        \u6293\u624b = \u81ea\u6d3d2;
        \u81ea\u6d3d \u81ea\u6d3d3 = \u62bd\u8c61.\u5e73\u53f0 ? \u771f\u9999.\u8d4b\u80fd(TaskInfo.class, "isVisible") : \u81ea\u6d3d.\u8d4b\u80fd;
        \u4e2d\u53f0 = \u81ea\u6d3d3;
    }

    public static final WindowContainerToken \u8d4b\u80fd() {
        try {
            WindowContainerToken windowContainerToken = new WindowContainerToken((IWindowContainerToken)new \u5f3a\u4f9d\u8d56());
            \u8d4b\u80fd = new $ExternalSyntheticLambda1(windowContainerToken);
            return windowContainerToken;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static final WindowContainerToken \u8d4b\u80fd(WindowContainerToken windowContainerToken) {
        return windowContainerToken;
    }
}

