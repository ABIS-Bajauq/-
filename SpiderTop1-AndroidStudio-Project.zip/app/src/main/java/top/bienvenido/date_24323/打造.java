/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.IContentObserver
 *  android.net.Uri
 *  android.os.IBinder
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.database.IContentObserver;
import android.net.Uri;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u6253\u9020$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u723d\u70b9;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8ba2\u9605;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u6253\u9020
extends \u89e6\u53d1 {
    public static final Unit \u8d4b\u80fd(Uri uri, Object[] arrobject, IContentObserver iContentObserver, \u8ba2\u9605 \u8ba2\u96052) {
        boolean bl = (Boolean)arrobject[1];
        \u8ba2\u96052.\u6293\u624b(uri, iContentObserver.asBinder(), bl);
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Uri uri = (Uri)arrobject[0];
            IContentObserver iContentObserver = (IContentObserver)arrobject[2];
            if (uri != null && iContentObserver != null) {
                \u723d\u70b9.\u843d\u5730.\u8d4b\u80fd(new \u6253\u9020$$ExternalSyntheticLambda0(uri, arrobject, iContentObserver));
            }
            if (!\u62bd\u8c61.\u843d\u5730) return super.\u8d4b\u80fd(object, method, arrobject);
            arrobject[4] = 22;
            if (!\u62bd\u8c61.\u5bf9\u9f50) return super.\u8d4b\u80fd(object, method, arrobject);
            if (!Intrinsics.areEqual((Object)arrobject[arrobject.length - 2], (Object)-2)) return super.\u8d4b\u80fd(object, method, arrobject);
            arrobject[arrobject.length - 2] = \u98ce\u53e3.\u95ed\u73af;
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

