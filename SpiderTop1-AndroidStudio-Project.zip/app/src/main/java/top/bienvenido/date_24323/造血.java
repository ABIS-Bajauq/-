/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u6253\u9020
 *  top.bienvenido.date_24323.\u8f93\u8840
 */
package top.bienvenido.date_24323;

import android.content.ContentResolver;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u53cd\u54fa;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u9020;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8f93\u8840;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u9020\u8840
extends \u96c6\u6210 {
    public static final \u9020\u8840 \u6293\u624b = new \u9020\u8840();

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("content", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u771f\u9999.\u8d4b\u80fd(ContentResolver.class, "sContentService", \u51fa\u51fb2.\u95ed\u73af);
        \u6253\u9020 \u6253\u90202 = new \u6253\u9020();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1429369164, (Object)\u6253\u90202);
        \u53cd\u54fa \u53cd\u54fa2 = new \u53cd\u54fa();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(133236371, \u53cd\u54fa2);
        \u8f93\u8840 \u8f93\u88402 = new \u8f93\u8840();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1000160345, (Object)\u8f93\u88402);
    }
}

