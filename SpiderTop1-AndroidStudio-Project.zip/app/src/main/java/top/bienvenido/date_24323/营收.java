/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.app.Notification;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u56de\u6d41;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u8425\u6536
extends \u89e6\u53d1 {
    public static final \u8425\u6536 \u6293\u624b = new \u8425\u6536();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        int n;
        block5 : {
            int n2;
            block4 : {
                try {
                    if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
                    n2 = arrobject.length;
                    break block4;
                }
                catch (Exception exception) {
                    // empty catch block
                }
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            for (n = 0; n < n2; ++n) {
                if (!Notification.class.isInstance(arrobject[n])) {
                    continue;
                }
                break block5;
            }
            n = -1;
        }
        if (n < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        Notification notification = ((Notification)arrobject[n]).clone();
        \u56de\u6d41.\u8d4b\u80fd(notification, \u6c34\u4f4d.\u6293\u624b);
        arrobject[n] = notification;
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

