/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.reflect.Method
 *  java.util.concurrent.ExecutorService
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5171\u521b$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5171\u521b$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u964d\u7ea7;

public final class \u5171\u521b
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(IBinder iBinder, \u5e03\u5c40 \u5e03\u5c402) {
        \u5e03\u5c402.\u6f0f\u6597(iBinder);
        return Unit.INSTANCE;
    }

    public static final void \u8d4b\u80fd(IBinder iBinder) {
        \u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u5171\u521b$$ExternalSyntheticLambda0(iBinder));
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IBinder iBinder = (IBinder)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, IBinder.class);
        if (iBinder != null) {
            \u5171\u521b$$ExternalSyntheticLambda1 \u5171\u521b$$ExternalSyntheticLambda1 = new \u5171\u521b$$ExternalSyntheticLambda1(iBinder);
            \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u5171\u521b$$ExternalSyntheticLambda1);
        }
        return method.invoke(object, arrobject);
    }
}

