/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  com.android.internal.R
 *  com.android.internal.R$styleable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u4e32\u8054$
 *  top.bienvenido.date_24323.\u4e32\u8054$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.android.internal.R;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e32\u8054$;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u9884\u8a00;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u4e32\u8054 {
    public static ArrayList \u8d4b\u80fd() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = \u8fb9\u754c.\u6293\u624b.\u6293\u624b();
        Intent intent = new Intent("android.accounts.AccountAuthenticator");
        for (String string2 : arrayList2) {
            \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
            \u8fb9\u754c2.getClass();
            if (\u8fb9\u754c.\u4e2d\u53f0.containsKey(string2)) {
                arrayList.addAll((Collection)\u8fb9\u754c2.\u6293\u624b(intent.setPackage(string2), null, 128));
                continue;
            }
            List list = (List)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(intent, string2, 128));
            if (list == null) continue;
            arrayList.addAll((Collection)list);
        }
        return arrayList;
    }

    public static final List \u8d4b\u80fd(Intent intent, String string2, int n, PackageManager packageManager) {
        return packageManager.queryIntentServices(intent.setPackage(string2), n);
    }

    /*
     * Exception decompiling
     */
    public static \u9884\u8a00 \u8d4b\u80fd(ResolveInfo var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static \u9884\u8a00 \u8d4b\u80fd(Resources resources, String string2, AttributeSet attributeSet, ServiceInfo serviceInfo) {
        try {
            typedArray = resources.obtainAttributes(attributeSet, R.styleable.AccountAuthenticator);
        }
        catch (Throwable throwable) {
            return null;
        }
        string3 = typedArray.getString(R.styleable.AccountAuthenticator_accountType);
        if (string3 == null || string3.length() == 0) ** GOTO lbl20
        n = typedArray.getResourceId(R.styleable.AccountAuthenticator_label, 0);
        n2 = typedArray.getResourceId(R.styleable.AccountAuthenticator_icon, 0);
        n3 = typedArray.getResourceId(R.styleable.AccountAuthenticator_smallIcon, 0);
        n4 = typedArray.getResourceId(R.styleable.AccountAuthenticator_accountPreferences, 0);
        bl = typedArray.getBoolean(R.styleable.AccountAuthenticator_customTokens, false);
        \u9884\u8a002 = new \u9884\u8a00(string3, string2, n, n2, n3, n4, bl, serviceInfo);
        {
            catch (Throwable throwable) {
                typedArray.recycle();
                throw throwable;
            }
        }
        typedArray.recycle();
        return \u9884\u8a002;
lbl20: // 1 sources:
        typedArray.recycle();
        return null;
    }
}

