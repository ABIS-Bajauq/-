/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 */
package top.bienvenido.date_24323;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public final class \u5dee\u5f02\u5316
extends ArrayList {
    public \u5dee\u5f02\u5316() {
    }

    public \u5dee\u5f02\u5316(int n) {
        super(n);
    }

    public \u5dee\u5f02\u5316(String string2) {
        super(1);
        super.add((Object)string2);
    }

    public final boolean add(Object object) {
        int n = this.\u8d4b\u80fd(object);
        if (n < 0) {
            this.add(n, object);
            return true;
        }
        return false;
    }

    public final boolean addAll(int n, Collection collection) {
        return this.addAll(collection);
    }

    public final boolean addAll(Collection collection) {
        Iterator iterator = collection.iterator();
        boolean bl = false;
        while (iterator.hasNext()) {
            if (!this.add(iterator.next()) && !bl) {
                bl = false;
                continue;
            }
            bl = true;
        }
        return bl;
    }

    public final boolean contains(Object object) {
        return this.\u8d4b\u80fd(object) >= 0;
    }

    public final int indexOf(Object object) {
        return this.\u8d4b\u80fd(object);
    }

    public final int lastIndexOf(Object object) {
        return this.\u8d4b\u80fd(object);
    }

    public final boolean remove(Object object) {
        int n = this.\u8d4b\u80fd(object);
        if (n >= 0) {
            this.remove(n);
            return true;
        }
        return false;
    }

    public final int \u8d4b\u80fd(Object object) {
        int n = -1 + this.size();
        int n2 = object.hashCode();
        int n3 = 0;
        while (n3 <= n) {
            int n4 = n3 + n >>> 1;
            int n5 = this.get(n4).hashCode();
            if (n5 < n2) {
                n3 = n4 + 1;
                continue;
            }
            if (n5 > n2) {
                n = n4 - 1;
                continue;
            }
            return n4;
        }
        return n3;
    }
}

