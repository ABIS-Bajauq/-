/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u7ef4\u5ea6
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ Account \u540c\u6b65;
    public final /* synthetic */ Bundle \u5bf9\u6807;
    public final /* synthetic */ String \u5bf9\u9f50;

    public \u7ef4\u5ea6(boolean bl, Account account, String string, Bundle bundle, IAccountManagerResponse iAccountManagerResponse, String string2, String string3) {
        this.\u540c\u6b65 = account;
        this.\u5bf9\u9f50 = string;
        this.\u5bf9\u6807 = bundle;
        super(iAccountManagerResponse, string2, bl, true, string3, false, true);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.updateCredentials((IAccountAuthenticatorResponse)this, this.\u540c\u6b65, this.\u5bf9\u9f50, this.\u5bf9\u6807);
        }
    }
}

