/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 *  top.bienvenido.date_24323.\u8d44\u6e90
 */
package top.bienvenido.date_24323;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u8d44\u6e90;

public final class \u8d44\u6e90$$ExternalSyntheticLambda0
implements InvocationHandler {
    public final Object invoke(Object object, Method method, Object[] arrobject) {
        return \u8d44\u6e90.\u8d4b\u80fd((Object)object, (Method)method, (Object[])arrobject);
    }
}

