/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u8bdd\u672f
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u8bdd\u672f;

public final class \u6587\u6848
extends \u5361\u4f4d {
    public static final \u6587\u6848 \u843d\u5730 = new \u6587\u6848();

    public \u6587\u6848() {
        super((Function1)\u8bdd\u672f.\u8d4b\u80fd, "MundoWindowManagerService");
    }
}

