/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d44\u6e90;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u56de\u6eaf
extends \u96c6\u6210 {
    public static final \u56de\u6eaf \u6293\u624b = new \u56de\u6eaf();

    @Override
    public final void \u8d4b\u80fd() {
        this.\u8d4b\u80fd = \u672c\u6211.\u4e2d\u53f0;
        try {
            if (\u62bd\u8c61.\u5e73\u53f0 && \u62bd\u8c61.\u4f18\u5316) {
                \u8d44\u6e90.\u6293\u624b.\u8d4b\u80fd();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        \u6d1e\u81ea\u8eab.\u8d4b\u80fd("clipboard", this.\u8d4b\u80fd, null);
    }
}

