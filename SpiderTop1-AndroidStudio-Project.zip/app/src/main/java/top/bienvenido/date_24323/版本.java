/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u6269\u5c55;

public final class \u7248\u672c
extends FunctionReferenceImpl
implements Function1 {
    public \u7248\u672c() {
        super(1, (Object)\u6269\u5c55.\u8d4b\u80fd, \u6269\u5c55.class, "modifyApplicationInfo", "modifyApplicationInfo(Landroid/content/pm/ApplicationInfo;)Z", 0);
    }

    public final Object invoke(Object object) {
        ApplicationInfo applicationInfo = (ApplicationInfo)object;
        ((\u6269\u5c55)this.receiver).getClass();
        return \u6269\u5c55.\u8d4b\u80fd(applicationInfo);
    }
}

