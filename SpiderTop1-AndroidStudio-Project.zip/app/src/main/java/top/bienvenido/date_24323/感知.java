/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.os.IBinder
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.concurrent.ExecutorService
 *  kotlin.Triple
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.IBinder;
import java.util.concurrent.ExecutorService;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u592f\u5b9e;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u5fc3\u667a;
import top.bienvenido.date_24323.\u611f\u77e5$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u611f\u77e5$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u805a\u5408;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u964d\u7ea7;

public final class \u611f\u77e5
implements Function2 {
    public final /* synthetic */ \u81ea\u6d3d \u4e2d\u53f0;
    public final /* synthetic */ \u81ea\u6d3d \u6293\u624b;
    public final /* synthetic */ \u81ea\u6d3d \u8d4b\u80fd;

    public \u611f\u77e5(\u81ea\u6d3d \u81ea\u6d3d2, \u81ea\u6d3d \u81ea\u6d3d3, \u81ea\u6d3d \u81ea\u6d3d4) {
        this.\u8d4b\u80fd = \u81ea\u6d3d2;
        this.\u6293\u624b = \u81ea\u6d3d3;
        this.\u4e2d\u53f0 = \u81ea\u6d3d4;
    }

    public static final Unit \u8d4b\u80fd(IBinder iBinder, IBinder iBinder2, \u5e03\u5c40 \u5e03\u5c402) {
        \u5e03\u5c402.\u8d4b\u80fd(iBinder, iBinder2);
        return Unit.INSTANCE;
    }

    public static final void \u8d4b\u80fd(IBinder iBinder, IBinder iBinder2) {
        \u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u611f\u77e5$$ExternalSyntheticLambda1(iBinder, iBinder2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void \u8d4b\u80fd(Object object, IBinder iBinder) {
        try {
            Intent intent = (Intent)this.\u8d4b\u80fd.\u8d4b\u80fd(object);
            if (intent == null) {
                return;
            }
            Triple triple = \u805a\u5408.\u8d4b\u80fd(intent);
            if (triple == null) {
                return;
            }
            Intent intent2 = (Intent)triple.getFirst();
            ComponentName componentName = intent2.getComponent();
            ActivityInfo activityInfo = componentName != null ? (ActivityInfo)\u592f\u5b9e.\u6293\u624b.\u8d4b\u80fd(componentName.getClassName().hashCode()) : null;
            if (activityInfo == null && (activityInfo = \u5fc3\u667a.\u8d4b\u80fd(intent2)) == null) {
                return;
            }
            this.\u6293\u624b.\u8d4b\u80fd(object, (Object)activityInfo);
            this.\u4e2d\u53f0.\u8d4b\u80fd(object, triple.getThird());
            this.\u8d4b\u80fd.\u8d4b\u80fd(object, (Object)intent2);
            IBinder iBinder2 = (IBinder)triple.getSecond();
            if (iBinder2 == null) return;
            {
                \u611f\u77e5$$ExternalSyntheticLambda0 \u611f\u77e5$$ExternalSyntheticLambda0 = new \u611f\u77e5$$ExternalSyntheticLambda0(iBinder, iBinder2);
                \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u611f\u77e5$$ExternalSyntheticLambda0);
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

