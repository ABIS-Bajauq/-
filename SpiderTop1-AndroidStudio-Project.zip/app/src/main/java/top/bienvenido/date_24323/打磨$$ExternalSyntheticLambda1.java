/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Comparator
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import java.util.Comparator;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u6253\u78e8;

public final class \u6253\u78e8$$ExternalSyntheticLambda1
implements Comparator {
    public final /* synthetic */ Function2 f$0;

    public /* synthetic */ \u6253\u78e8$$ExternalSyntheticLambda1(Function2 function2) {
        this.f$0 = function2;
    }

    public final int compare(Object object, Object object2) {
        return \u6253\u78e8.\u8d4b\u80fd(this.f$0, object, object2);
    }
}

