/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.inputmethod.EditorInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u5212\u6c34
 *  top.bienvenido.date_24323.\u6478\u9c7c
 *  top.bienvenido.date_24323.\u7eb5\u5411
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.view.inputmethod.EditorInfo;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5212\u6c34;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6478\u9c7c;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u4f17\u7b79
extends \u96c6\u6210 {
    public static final \u4f17\u7b79 \u6293\u624b = new \u4f17\u7b79();

    @Override
    public final void \u8d4b\u80fd() {
        \u7eb5\u5411 \u7eb5\u54112 = new \u7eb5\u5411(EditorInfo.class, (Function2)new \u6478\u9c7c((Object)\u5212\u6c34.\u8d4b\u80fd));
        this.\u8d4b\u80fd = \u7eb5\u54112;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("input_method", (\u89e6\u8fbe)\u7eb5\u54112, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        if (\u62bd\u8c61.\u540c\u6b65) {
            \u771f\u9999.\u8d4b\u80fd("android.view.inputmethod.IInputMethodManagerGlobalInvoker", "sServiceCache").\u8d4b\u80fd((Object)null, \u51fa\u51fb2.\u95ed\u73af);
            return;
        }
        Object object = \u98ce\u53e3.\u8d4b\u80fd.getSystemService("input_method");
        Object object2 = \u51fa\u51fb2.\u95ed\u73af;
        new \u8d77\u98de((String)"mService").\u6293\u624b.\u8d4b\u80fd(object, object2);
    }
}

