/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IIntentReceiver
 *  android.content.IntentFilter
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6253\u5e73
 */
package top.bienvenido.date_24323;

import android.content.IIntentReceiver;
import android.content.IntentFilter;
import top.bienvenido.date_24323.\u6253\u5e73;

public final class \u6253\u5e73$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ IIntentReceiver f$0;
    public final /* synthetic */ IntentFilter f$1;

    public /* synthetic */ \u6253\u5e73$$ExternalSyntheticLambda0(IIntentReceiver iIntentReceiver, IntentFilter intentFilter) {
        this.f$0 = iIntentReceiver;
        this.f$1 = intentFilter;
    }

    public final void run() {
        \u6253\u5e73.\u8d4b\u80fd((IIntentReceiver)this.f$0, (IntentFilter)this.f$1);
    }
}

