/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u7cbe\u51c6;

public abstract class \u7075\u6d3b {
    public final \u7cbe\u51c6 \u8d4b\u80fd = new \u7cbe\u51c6(this);
}

