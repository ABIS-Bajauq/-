/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Parcel
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Arrays
 *  kotlin.io.FilesKt
 *  top.bienvenido.date_24323.\u64cd\u76d8
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.os.Parcel;
import java.io.File;
import java.util.Arrays;
import kotlin.io.FilesKt;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u5934\u90e8;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u64cd\u76d8;
import top.bienvenido.date_24323.\u6f14\u7ece;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u89e6\u53ca;
import top.bienvenido.date_24323.\u8fd4\u4f63;

public final class \u6df1\u5165 {
    public final \u6f14\u7ece \u6293\u624b;
    public final \u64cd\u76d8 \u8d4b\u80fd;

    public \u6df1\u5165(\u64cd\u76d8 \u64cd\u76d82) {
        this.\u8d4b\u80fd = \u64cd\u76d82;
        this.\u6293\u624b = new \u6f14\u7ece();
    }

    public final void \u6293\u624b() {
        try {
            \u6f14\u7ece \u6f14\u7ece2 = this.\u6293\u624b;
            int n = \u6f14\u7ece2.\u4e2d\u53f0;
            int[] arrn = Arrays.copyOf((int[])\u6f14\u7ece2.\u8d4b\u80fd, (int)n);
            int[] arrn2 = Arrays.copyOf((int[])this.\u6293\u624b.\u6293\u624b, (int)n);
            Parcel parcel = Parcel.obtain();
            parcel.writeInt(n);
            parcel.writeIntArray(arrn);
            parcel.writeIntArray(arrn2);
            byte[] arrby = parcel.marshall();
            parcel.recycle();
            String string2 = this.\u8d4b\u80fd.\u8d4b\u80fd;
            FilesKt.writeBytes((File)\u6253\u78e8.\u8d4b\u80fd(\u89e6\u53ca.\u6293\u624b, string2, "components.bin"), (byte[])arrby);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final int \u8d4b\u80fd(String string2) {
        int n;
        \u6f14\u7ece \u6f14\u7ece2;
        block3 : {
            try {
                \u6f14\u7ece2 = this.\u6293\u624b;
                int n2 = string2.hashCode();
                n = \u753b\u997c.\u8d4b\u80fd(\u6f14\u7ece2.\u8d4b\u80fd, \u6f14\u7ece2.\u4e2d\u53f0, n2);
                if (n >= 0) break block3;
                return 0;
            }
            catch (Exception exception) {
                return 0;
            }
        }
        int n3 = \u6f14\u7ece2.\u6293\u624b[n];
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void \u8d4b\u80fd() {
        ActivityInfo[] arractivityInfo;
        ProviderInfo[] arrproviderInfo;
        int n;
        ActivityInfo[] arractivityInfo2;
        block10 : {
            ServiceInfo[] arrserviceInfo;
            int n2;
            try {
                String string2 = this.\u8d4b\u80fd.\u8d4b\u80fd;
                File file = \u89e6\u53ca.\u6293\u624b;
                String[] arrstring = new String[2];
                n = 0;
                arrstring[0] = string2;
                arrstring[1] = "components.bin";
                File file2 = \u6253\u78e8.\u8d4b\u80fd(file, arrstring);
                if (!file2.exists()) return;
                byte[] arrby = FilesKt.readBytes((File)file2);
                Parcel parcel = Parcel.obtain();
                parcel.unmarshall(arrby, 0, arrby.length);
                parcel.setDataPosition(0);
                int n3 = parcel.readInt();
                int[] arrn = new int[n3];
                int[] arrn2 = new int[n3];
                parcel.readIntArray(arrn);
                parcel.readIntArray(arrn2);
                parcel.recycle();
                \u6f14\u7ece \u6f14\u7ece2 = this.\u6293\u624b;
                \u6f14\u7ece2.\u4e2d\u53f0 = n3;
                \u6f14\u7ece2.\u8d4b\u80fd = arrn;
                \u6f14\u7ece2.\u6293\u624b = arrn2;
                arrserviceInfo = this.\u8d4b\u80fd.\u4e2d\u53f0.services;
                if (arrserviceInfo == null) break block10;
                n2 = arrserviceInfo.length;
            }
            catch (Exception exception) {
                // empty catch block
                return;
            }
            for (int i = 0; i < n2; ++i) {
                ServiceInfo serviceInfo = arrserviceInfo[i];
                if (serviceInfo.enabled || this.\u8d4b\u80fd(serviceInfo.name) != 1) continue;
                serviceInfo.enabled = true;
            }
        }
        if ((arractivityInfo = this.\u8d4b\u80fd.\u4e2d\u53f0.activities) != null) {
            for (ActivityInfo activityInfo : arractivityInfo) {
                if (activityInfo.enabled || this.\u8d4b\u80fd(activityInfo.name) != 1) continue;
                activityInfo.enabled = true;
            }
        }
        if ((arrproviderInfo = this.\u8d4b\u80fd.\u4e2d\u53f0.providers) != null) {
            for (ProviderInfo providerInfo : arrproviderInfo) {
                if (providerInfo.enabled || this.\u8d4b\u80fd(providerInfo.name) != 1) continue;
                providerInfo.enabled = true;
            }
        }
        if ((arractivityInfo2 = this.\u8d4b\u80fd.\u4e2d\u53f0.receivers) == null) return;
        {
            int n4 = arractivityInfo2.length;
            while (n < n4) {
                ActivityInfo activityInfo = arractivityInfo2[n];
                if (!activityInfo.enabled && this.\u8d4b\u80fd(activityInfo.name) == 1) {
                    activityInfo.enabled = true;
                }
                ++n;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void \u8d4b\u80fd(String string2, int n) {
        try {
            ComponentInfo componentInfo = (ComponentInfo)this.\u8d4b\u80fd.\u6f0f\u6597.\u8d4b\u80fd.\u8d4b\u80fd(string2.hashCode());
            if (componentInfo == null) {
                return;
            }
            \u6f14\u7ece \u6f14\u7ece2 = this.\u6293\u624b;
            if (n == 0) {
                int n2 = string2.hashCode();
                int n3 = \u753b\u997c.\u8d4b\u80fd(\u6f14\u7ece2.\u8d4b\u80fd, \u6f14\u7ece2.\u4e2d\u53f0, n2);
                if (n3 >= 0) {
                    int[] arrn = \u6f14\u7ece2.\u8d4b\u80fd;
                    int n4 = n3 + 1;
                    System.arraycopy((Object)arrn, (int)n4, (Object)arrn, (int)n3, (int)(\u6f14\u7ece2.\u4e2d\u53f0 - n4));
                    int[] arrn2 = \u6f14\u7ece2.\u6293\u624b;
                    System.arraycopy((Object)arrn2, (int)n4, (Object)arrn2, (int)n3, (int)(\u6f14\u7ece2.\u4e2d\u53f0 - n4));
                    --\u6f14\u7ece2.\u4e2d\u53f0;
                }
                if (\u6f14\u7ece2.\u4e2d\u53f0 == 0) {
                    \u6f14\u7ece2.\u4e2d\u53f0 = 0;
                    int[] arrn = \u4e0b\u6c89.\u8d4b\u80fd;
                    \u6f14\u7ece2.\u8d4b\u80fd = arrn;
                    \u6f14\u7ece2.\u6293\u624b = arrn;
                }
            } else {
                \u6f14\u7ece2.\u8d4b\u80fd(string2.hashCode(), n);
            }
        }
        catch (Exception exception) {
            return;
        }
        boolean bl = false;
        if (n != 2) {
            bl = false;
            if (n != 3) {
                bl = true;
            }
        }
        componentInfo.enabled = bl;
    }
}

