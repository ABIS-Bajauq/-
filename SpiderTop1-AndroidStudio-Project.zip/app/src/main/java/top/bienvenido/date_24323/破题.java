/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Activity
 *  android.content.pm.PackageParser$ActivityIntentInfo
 *  android.content.pm.PackageParser$IntentInfo
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u51fb\u7a7f
 *  top.bienvenido.date_24323.\u7834\u51b0
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageParser;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u5171\u4eab;
import top.bienvenido.date_24323.\u51fb\u7a7f;
import top.bienvenido.date_24323.\u7834\u51b0;
import top.bienvenido.date_24323.\u7ea6\u675f;

public final class \u7834\u9898
extends \u5171\u4eab {
    public final /* synthetic */ \u7ea6\u675f \u6c89\u6dc0;

    public \u7834\u9898(\u7ea6\u675f \u7ea6\u675f2, ArrayList arrayList) {
        this.\u6c89\u6dc0 = \u7ea6\u675f2;
        for (PackageParser.Activity activity : arrayList) {
            ArrayList arrayList2;
            if (activity.info == null || (arrayList2 = activity.intents) == null) continue;
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                this.\u8d4b\u80fd((IntentFilter)((PackageParser.ActivityIntentInfo)iterator.next()));
            }
        }
    }

    @Override
    public final int \u6293\u624b(IntentFilter intentFilter) {
        ActivityInfo activityInfo = ((PackageParser.ActivityIntentInfo)intentFilter).activity.info;
        String string = activityInfo.targetActivity;
        if (string == null) {
            string = activityInfo.name;
        }
        return string.hashCode();
    }

    @Override
    public final Object \u8d4b\u80fd(IntentFilter intentFilter, int n, int n2) {
        PackageParser.ActivityIntentInfo activityIntentInfo = (PackageParser.ActivityIntentInfo)intentFilter;
        return \u7ea6\u675f.\u8d4b\u80fd(this.\u6c89\u6dc0, (ComponentInfo)activityIntentInfo.activity.info, (Function2)new \u51fb\u7a7f((Object)\u7834\u51b0.\u8d4b\u80fd), (PackageParser.IntentInfo)activityIntentInfo, n2, n);
    }
}

