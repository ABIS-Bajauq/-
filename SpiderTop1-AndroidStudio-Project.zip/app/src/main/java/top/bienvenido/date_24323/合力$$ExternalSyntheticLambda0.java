/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ ComponentName f$0;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda0(ComponentName componentName) {
        this.f$0 = componentName;
    }

    public final Object invoke(Object object) {
        return \u5408\u529b.\u8d4b\u80fd(this.f$0, (PackageManager)object);
    }
}

