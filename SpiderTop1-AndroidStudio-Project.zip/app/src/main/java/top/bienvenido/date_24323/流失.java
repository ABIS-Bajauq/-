/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import java.util.List;

public interface \u6d41\u5931 {
    public List \u4e2d\u53f0(Intent var1, String var2, int var3);

    public List \u6293\u624b(Intent var1, String var2, int var3);

    public List \u8d4b\u80fd(Intent var1, String var2, int var3);

    public List \u95ed\u73af(Intent var1, String var2, int var3);
}

