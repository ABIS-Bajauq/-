/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u65b9\u6848;

public final class \u65b9\u6848$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;
    public final /* synthetic */ \u65b9\u6848 f$1;

    public /* synthetic */ \u65b9\u6848$$ExternalSyntheticLambda0(Object[] arrobject, \u65b9\u6848 \u65b9\u68482) {
        this.f$0 = arrobject;
        this.f$1 = \u65b9\u68482;
    }

    public final Object invoke(Object object) {
        return \u65b9\u6848.\u8d4b\u80fd(this.f$0, this.f$1, (\u589e\u957f)object);
    }
}

