/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u5fc3\u667a$
 *  top.bienvenido.date_24323.\u5fc3\u667a$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u5fc3\u667a$$ExternalSyntheticLambda1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5fc3\u667a$;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u5fc3\u667a {
    public static ActivityInfo \u8d4b\u80fd(Intent intent) {
        block6 : {
            block5 : {
                try {
                    if (\u6c34\u4f4d.\u8d4b\u80fd) break block5;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            ResolveInfo resolveInfo = \u6c34\u4f4d.\u6f0f\u6597 ? (ResolveInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(intent)) : (ResolveInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda1(intent));
            if (resolveInfo == null) break block6;
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            if (activityInfo == null) break block6;
            \u6269\u5c55.\u8d4b\u80fd(activityInfo.applicationInfo);
            return activityInfo;
        }
        return null;
    }

    public static final ResolveInfo \u8d4b\u80fd(Intent intent, PackageManager packageManager) {
        return packageManager.resolveActivity(intent, 512);
    }

    public static final ResolveInfo \u8d4b\u80fd(Intent intent, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u843d\u5730(intent, null, 0);
    }
}

