/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.os.Bundle
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.reflect.Proxy
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u4f53\u7cfb$
 *  top.bienvenido.date_24323.\u4f53\u7cfb$$ExternalSyntheticLambda1
 *  top.bienvenido.date_24323.\u4f53\u7cfb$$ExternalSyntheticLambda2
 *  top.bienvenido.date_24323.\u4f53\u7cfb$$ExternalSyntheticLambda4
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.io.Serializable;
import java.lang.reflect.Proxy;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4f53\u7cfb$;
import top.bienvenido.date_24323.\u4f53\u7cfb$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u4f53\u7cfb$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u780d\u4e00\u5200;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.common.initialize.MNative;

public abstract class \u4f53\u7cfb {
    public static final ApplicationInfo \u4e2d\u53f0(PackageManager packageManager) {
        return packageManager.getApplicationInfo(\u98ce\u53e3.\u6293\u624b, 128);
    }

    public static final void \u4e2d\u53f0() {
        \u4f53\u7cfb.\u843d\u5730();
        \u4f53\u7cfb.\u95ed\u73af();
    }

    public static final void \u4e2d\u53f0(String string2) {
        \u4f53\u7cfb.\u8d4b\u80fd(string2, 0);
    }

    public static final Unit \u6293\u624b(PackageManager packageManager) {
        packageManager.setComponentEnabledSetting(new ComponentName(\u98ce\u53e3.\u6293\u624b, "top.bienvenido.mundo.FBLoginAbility"), 1, 1);
        return Unit.INSTANCE;
    }

    public static void \u6293\u624b() {
        new Thread((Runnable)new \u4f53\u7cfb$$ExternalSyntheticLambda0()).start();
    }

    public static void \u6293\u624b(String string2) {
        new Thread((Runnable)new \u4f53\u7cfb$$ExternalSyntheticLambda3(string2)).start();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void \u843d\u5730() {
        ApplicationInfo applicationInfo;
        block6 : {
            applicationInfo = (ApplicationInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda4());
            if (applicationInfo != null) break block6;
            return;
        }
        Bundle bundle = applicationInfo.metaData;
        if (bundle == null) return;
        String string2 = bundle.getString("MUNDO_APP_KEY", "");
        if (string2 == null) return;
        try {
            if (string2.length() == 0) {
                return;
            }
            \u4f53\u7cfb.\u8d4b\u80fd(string2, 0);
            return;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static final int \u8d4b\u80fd(PackageManager packageManager) {
        return packageManager.getComponentEnabledSetting(new ComponentName(\u98ce\u53e3.\u6293\u624b, "top.bienvenido.mundo.FBLoginAbility"));
    }

    public static String \u8d4b\u80fd(String string2) {
        block3 : {
            Object object;
            try {
                object = MNative.\u8d4b\u80fd(61183, (Serializable)string2);
                if (object == null) break block3;
            }
            catch (Throwable throwable) {
                return null;
            }
            String string3 = object.toString();
            return string3;
        }
        return null;
    }

    public static boolean \u8d4b\u80fd() {
        Object object;
        block3 : {
            try {
                object = MNative.\u8d4b\u80fd(61181, null);
                if (object != null) break block3;
                return false;
            }
            catch (Throwable throwable) {
                return false;
            }
        }
        boolean bl = Boolean.parseBoolean((String)object.toString());
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean \u8d4b\u80fd(String string2, int n) {
        String string3;
        block5 : {
            Object object;
            block4 : {
                if (n > 2) return false;
                try {
                    if (string2.length() == 0) {
                        return false;
                    }
                    object = \u780d\u4e00\u5200.\u8d4b\u80fd(\u98ce\u53e3.\u8d4b\u80fd);
                    if (!(object instanceof Proxy)) break block4;
                    string3 = "";
                    break block5;
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                return false;
            }
            if (object == null) {
                return true;
            }
            string3 = string2;
        }
        MNative.\u8d4b\u80fd(61180, (Serializable)string3);
        if (\u4f53\u7cfb.\u8d4b\u80fd()) return true;
        return \u4f53\u7cfb.\u8d4b\u80fd(string2, n + 1);
    }

    public static Object \u95ed\u73af(String string2) {
        try {
            Object object = MNative.\u8d4b\u80fd(61188, (Serializable)string2);
            return object;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u95ed\u73af() {
        int n;
        try {
            Integer n2 = (Integer)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda1());
            if (n2 == null) return;
            n = n2;
        }
        catch (Throwable throwable) {
            return;
        }
        if (n != 0 && n != 2 && n != 3) {
            if (n != 4) return;
        }
        \u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda2());
    }
}

