/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable$Creator
 *  android.os.Process
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6fc0\u6d3b;

public abstract class \u6fc0\u52b1
extends Binder
implements \u6fc0\u6d3b {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u6fc0\u52b1() {
        this.attachInterface((IInterface)this, "MundoAppThread");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        if (n >= 1 && n <= 16777215) {
            parcel.enforceInterface("MundoAppThread");
        }
        if (n == 1598968902) {
            parcel2.writeString("MundoAppThread");
            return true;
        }
        Object object = null;
        switch (n) {
            default: {
                return super.onTransact(n, parcel, parcel2, n2);
            }
            case 9: {
                String string = parcel.readString();
                ((\u6bb5\u4f4d)this).\u54cd\u5e94(string);
                return true;
            }
            case 8: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                ((\u6bb5\u4f4d)this).\u8d4b\u80fd(intent, iBinder, string);
                return true;
            }
            case 7: {
                String string = parcel.readString();
                IBinder iBinder = ((\u6bb5\u4f4d)this).\u5bf9\u9f50(string);
                parcel2.writeNoException();
                parcel2.writeStrongBinder(iBinder);
                return true;
            }
            case 6: {
                Process.killProcess((int)Process.myPid());
                return true;
            }
            case 5: {
                IBinder iBinder = parcel.readStrongBinder();
                ((\u6bb5\u4f4d)this).\u6c89\u6dc0(iBinder);
                return true;
            }
            case 4: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                int n3 = parcel.readInt();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                ((\u6bb5\u4f4d)this).\u8d4b\u80fd(string, intent, iBinder, n3);
                return true;
            }
            case 3: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                ((\u6bb5\u4f4d)this).\u6293\u624b(iBinder, intent);
                return true;
            }
            case 2: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                ((\u6bb5\u4f4d)this).\u8d4b\u80fd(iBinder, intent);
                return true;
            }
            case 1: 
        }
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        boolean bl = parcel.readInt() != 0;
        String string4 = parcel.readString();
        ((\u6bb5\u4f4d)this).\u8d4b\u80fd(string, string2, string3, bl, string4);
        return true;
    }
}

