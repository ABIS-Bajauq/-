/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e32\u8054;

public final class \u4e32\u8054$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ \u4e32\u8054$$ExternalSyntheticLambda0(Intent intent, String string, int n) {
        this.f$0 = intent;
        this.f$1 = string;
        this.f$2 = n;
    }

    public final Object invoke(Object object) {
        return \u4e32\u8054.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (PackageManager)object);
    }
}

