/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ProviderInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ProviderInfo;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u89c4\u8303$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u89c4\u8303
extends \u89e6\u8fbe {
    public static final ProviderInfo \u8d4b\u80fd(Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u7ed9\u5230(String.valueOf((Object)arrobject[0]));
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        ProviderInfo providerInfo;
        block5 : {
            try {
                providerInfo = (ProviderInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u89c4\u8303$$ExternalSyntheticLambda0(arrobject));
                if (providerInfo != null) break block5;
            }
            catch (Exception exception) {
                return null;
            }
            \u89e6\u8fbe.\u8d4b\u80fd(arrobject, 1);
            providerInfo = (ProviderInfo)method.invoke(object, arrobject);
        }
        if (providerInfo != null) {
            \u6269\u5c55.\u8d4b\u80fd(providerInfo.applicationInfo);
            return providerInfo;
        }
        return null;
    }
}

