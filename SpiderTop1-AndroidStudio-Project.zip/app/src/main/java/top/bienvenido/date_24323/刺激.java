/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u523a\u6fc0
extends \u5f00\u573a\u5b50 {
    public \u523a\u6fc0(String string, boolean bl, IAccountManagerResponse iAccountManagerResponse) {
        super(iAccountManagerResponse, string, bl, true, null, false, false);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.editProperties((IAccountAuthenticatorResponse)this, this.\u8d4b\u80fd);
        }
    }
}

