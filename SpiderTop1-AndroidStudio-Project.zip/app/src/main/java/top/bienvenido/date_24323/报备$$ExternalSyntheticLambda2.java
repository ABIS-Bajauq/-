/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62a5\u5907;

public final class \u62a5\u5907$$ExternalSyntheticLambda2
implements Function1 {
    public final Object invoke(Object object) {
        return \u62a5\u5907.\u4e2d\u53f0((Object[])object);
    }
}

