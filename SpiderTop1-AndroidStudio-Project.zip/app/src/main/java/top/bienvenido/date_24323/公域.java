/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcelable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.os.Parcelable;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u516c\u57df
extends \u89e6\u8fbe {
    public final Object \u4e2d\u53f0;
    public final Class \u6293\u624b;
    public final \u89e6\u8fbe \u8d4b\u80fd;

    public \u516c\u57df(\u89e6\u8fbe \u89e6\u8fbe2, Class class_, Parcelable parcelable) {
        this.\u8d4b\u80fd = \u89e6\u8fbe2;
        this.\u6293\u624b = class_;
        this.\u4e2d\u53f0 = parcelable;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Class class_ = this.\u6293\u624b;
        Object object2 = this.\u4e2d\u53f0;
        int n = arrobject.length;
        for (int i = 0; i < n; ++i) {
            try {
                if (!class_.isInstance(arrobject[i])) continue;
                arrobject[i] = object2;
                break;
            }
            catch (Exception exception) {
                // empty catch block
                break;
            }
        }
        return this.\u8d4b\u80fd.\u8d4b\u80fd(object, method, arrobject);
    }
}

