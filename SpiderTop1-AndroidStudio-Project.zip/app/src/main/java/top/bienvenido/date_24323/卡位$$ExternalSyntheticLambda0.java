/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.Bundle;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;

public final class \u5361\u4f4d$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u5361\u4f4d f$0;

    public /* synthetic */ \u5361\u4f4d$$ExternalSyntheticLambda0(\u5361\u4f4d \u5361\u4f4d2) {
        this.f$0 = \u5361\u4f4d2;
    }

    public final Object invoke(Object object) {
        return \u5361\u4f4d.\u8d4b\u80fd(this.f$0, (Bundle)object);
    }
}

