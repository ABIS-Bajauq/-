/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.SyncNotedAppOp
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.app.SyncNotedAppOp;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u54ac\u5408
extends \u89e6\u53d1 {
    public final \u8d77\u98de \u6293\u624b = new \u8d77\u98de("mOpMode");

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = super.\u8d4b\u80fd(object, method, arrobject);
        try {
            if (\u6c34\u4f4d.\u8d4b\u80fd && object2 instanceof SyncNotedAppOp) {
                \u8d77\u98de \u8d77\u98de2 = this.\u6293\u624b;
                Integer n = 0;
                \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object2, (Object)n);
                return object2;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return object2;
    }
}

