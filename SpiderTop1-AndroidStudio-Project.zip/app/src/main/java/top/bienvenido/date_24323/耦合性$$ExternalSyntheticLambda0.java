/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import android.view.WindowManager;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u8026\u5408\u6027;

public final class \u8026\u5408\u6027$$ExternalSyntheticLambda0
implements Function2 {
    public final /* synthetic */ \u5e73\u53f0\u5316 f$0;

    public /* synthetic */ \u8026\u5408\u6027$$ExternalSyntheticLambda0(\u5e73\u53f0\u5316 \u5e73\u53f0\u53162) {
        this.f$0 = \u5e73\u53f0\u53162;
    }

    public final Object invoke(Object object, Object object2) {
        return \u8026\u5408\u6027.\u8d4b\u80fd(this.f$0, (WindowManager.LayoutParams)object, (String)object2);
    }
}

