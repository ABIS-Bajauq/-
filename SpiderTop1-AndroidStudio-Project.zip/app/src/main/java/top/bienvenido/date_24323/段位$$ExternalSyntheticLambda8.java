/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda8
implements Runnable {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda8(String string2) {
        this.f$0 = string2;
    }

    public final void run() {
        \u6bb5\u4f4d.\u4ea4\u4ed8((String)this.f$0);
    }
}

