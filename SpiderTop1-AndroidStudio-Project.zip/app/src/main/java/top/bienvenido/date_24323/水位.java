/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

public abstract class \u6c34\u4f4d {
    public static String \u4e2d\u53f0 = "";
    public static String \u6293\u624b = "";
    public static int \u6c89\u6dc0 = 0;
    public static boolean \u6f0f\u6597 = false;
    public static String \u7ed9\u5230 = "";
    public static String \u843d\u5730 = "";
    public static boolean \u8d4b\u80fd = false;
    public static String \u95ed\u73af = "";
}

