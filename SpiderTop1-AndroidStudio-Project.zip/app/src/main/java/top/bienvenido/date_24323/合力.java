/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.app.IBinderSession
 *  android.app.IServiceConnection
 *  android.app.IServiceConnection$Stub
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.Intent$FilterComparison
 *  android.content.IntentFilter
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Process
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ExecutorService
 *  kotlin.Pair
 *  kotlin.Result
 *  kotlin.ResultKt
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function3
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.app.ActivityManager;
import android.app.IBinderSession;
import android.app.IServiceConnection;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Process;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u53d8\u9769;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda10;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda11;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda12;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda13;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda14;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda15;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda16;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda17;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda4;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda5;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda6;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda7;
import top.bienvenido.date_24323.\u5408\u529b$$ExternalSyntheticLambda8;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5bf9\u4e00\u4e0b;
import top.bienvenido.date_24323.\u5c01\u88c5;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u611f\u6069;
import top.bienvenido.date_24323.\u6218\u5f79;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6fc0\u6d3b;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u9ad8\u5730;
import top.bienvenido.date_24323.\u9ad8\u7a7a;

public final class \u5408\u529b
extends \u611f\u6069 {
    public static final ConcurrentHashMap \u4e2d\u53f0;
    public static final \u5408\u529b \u6293\u624b;
    public static final ConcurrentHashMap \u6f0f\u6597;
    public static final \u6218\u5f79 \u843d\u5730;
    public static final Function3 \u95ed\u73af;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        void var1_7;
        block8 : {
            \u6293\u624b = new \u5408\u529b();
            \u4e2d\u53f0 = new ConcurrentHashMap();
            try {
                if (\u62bd\u8c61.\u843d\u5730) {
                    boolean bl = \u62bd\u8c61.\u5bf9\u6807;
                    boolean bl2 = false;
                    if (bl) {
                        \u771f\u9999.\u8d4b\u80fd(Bundle.class, "intentClass", null);
                        try {
                            bl2 = Class.forName((String)"android.app.IBinderSession", (boolean)false, (ClassLoader)IBinder.class.getClassLoader()).isInterface();
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                    if (bl2) {
                        \u5408\u529b$$ExternalSyntheticLambda5 \u5408\u529b$$ExternalSyntheticLambda5 = new \u5408\u529b$$ExternalSyntheticLambda5();
                    } else {
                        \u5408\u529b$$ExternalSyntheticLambda6 \u5408\u529b$$ExternalSyntheticLambda6 = new \u5408\u529b$$ExternalSyntheticLambda6();
                    }
                    break block8;
                }
                \u5408\u529b$$ExternalSyntheticLambda7 \u5408\u529b$$ExternalSyntheticLambda7 = new \u5408\u529b$$ExternalSyntheticLambda7();
            }
            catch (Throwable throwable) {
                \u5408\u529b$$ExternalSyntheticLambda8 \u5408\u529b$$ExternalSyntheticLambda8 = new \u5408\u529b$$ExternalSyntheticLambda8();
            }
        }
        \u95ed\u73af = var1_7;
        \u843d\u5730 = new \u6218\u5f79();
        \u6f0f\u6597 = new ConcurrentHashMap();
    }

    public static final Unit \u4e2d\u53f0(Object object, ComponentName componentName, IBinder iBinder) {
        ((IServiceConnection)object).connected(componentName, iBinder);
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u4e2d\u53f0(String string, String string2, String string3) {
        Object object;
        block4 : {
            \u5408\u529b \u5408\u529b2;
            block3 : {
                \u5408\u529b2 = \u6293\u624b;
                try {
                    if (string2 != null && string2.length() != 0) break block3;
                }
                catch (Throwable throwable) {
                    object = Result.constructor-impl((Object)ResultKt.createFailure((Throwable)throwable));
                    break block4;
                }
                string2 = null;
            }
            if (string3 == null || string3.length() == 0) {
                string3 = null;
            }
            \u5408\u529b2.getClass();
            \u5408\u529b.\u6293\u624b(string, string2, string3);
            object = Result.constructor-impl((Object)Unit.INSTANCE);
        }
        Result.exceptionOrNull-impl((Object)object);
    }

    public static final void \u5347\u7ea7(String string) {
        Object object;
        \u5408\u529b \u5408\u529b2 = \u6293\u624b;
        try {
            if (Intrinsics.areEqual((Object)\u9ad8\u5730.\u843d\u5730, (Object)string)) {
                return;
            }
            \u9ad8\u5730.\u843d\u5730 = string;
            \u5408\u529b2.getClass();
            \u5408\u529b.\u6293\u624b(string, null, null);
            object = Result.constructor-impl((Object)Unit.INSTANCE);
        }
        catch (Throwable throwable) {
            object = Result.constructor-impl((Object)ResultKt.createFailure((Throwable)throwable));
        }
        Result.exceptionOrNull-impl((Object)object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u5e73\u53f0(IBinder iBinder) {
        try {
            \u6fc0\u6d3b \u6fc0\u6d3b2 = ((\u53d8\u9769)iBinder).\u8d4b\u80fd.\u7ed9\u5230;
            if (\u6fc0\u6d3b2 != null) {
                \u6fc0\u6d3b2.\u6c89\u6dc0(iBinder);
            }
            ((\u53d8\u9769)iBinder).\u8d4b\u80fd.\u5bf9\u9f50.\u6293\u624b(((\u53d8\u9769)iBinder).\u6293\u624b.name.hashCode());
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final ResolveInfo \u6293\u624b(Intent intent, PackageManager packageManager) {
        return packageManager.resolveService(intent, 512);
    }

    public static final Unit \u6293\u624b(Object object, ComponentName componentName, IBinder iBinder) {
        ((IServiceConnection)object).connected(componentName, iBinder, false);
        return Unit.INSTANCE;
    }

    public static void \u6293\u624b(String string, String string2, String string3) {
        Object[] arrobject = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd.\u8d4b\u80fd();
        int n = arrobject.length;
        for (int i = 0; i < n; ++i) {
            \u6fc0\u6d3b \u6fc0\u6d3b2;
            \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)arrobject[i];
            if (string2 != null && !Intrinsics.areEqual((Object)\u54c1\u724c2.\u8d4b\u80fd, (Object)string2) || string3 != null && !Intrinsics.areEqual((Object)\u54c1\u724c2.\u4e2d\u53f0, (Object)string3) || (\u6fc0\u6d3b2 = \u54c1\u724c2.\u7ed9\u5230) == null) continue;
            \u6fc0\u6d3b2.\u54cd\u5e94(string);
        }
        \u9ad8\u7a7a.\u8d4b\u80fd(string, string2, string3);
    }

    public static final ProviderInfo \u8d4b\u80fd(String string, PackageManager packageManager) {
        return packageManager.resolveContentProvider(string, 512);
    }

    public static final ServiceInfo \u8d4b\u80fd(ComponentName componentName, PackageManager packageManager) {
        return packageManager.getServiceInfo(componentName, 512);
    }

    public static ServiceInfo \u8d4b\u80fd(Intent intent) {
        ResolveInfo resolveInfo = (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(\u8fb9\u754c.\u6293\u624b.\u6293\u624b(intent, null, 0)));
        if (resolveInfo != null) {
            return resolveInfo.serviceInfo;
        }
        ResolveInfo resolveInfo2 = (ResolveInfo)\u98ce\u53e3.\u8d4b\u80fd(new \u5408\u529b$$ExternalSyntheticLambda12(intent));
        if (resolveInfo2 != null) {
            ServiceInfo serviceInfo = resolveInfo2.serviceInfo;
            String string = serviceInfo.packageName;
            if (\u8fb9\u754c.\u95ed\u73af.containsKey(string)) {
                return serviceInfo;
            }
        }
        return null;
    }

    public static final List \u8d4b\u80fd(Intent intent, PackageManager packageManager) {
        return packageManager.queryBroadcastReceivers(intent, 0);
    }

    public static final Unit \u8d4b\u80fd(Object object, ComponentName componentName, IBinder iBinder) {
        ((IServiceConnection)object).connected(componentName, iBinder, null, false);
        return Unit.INSTANCE;
    }

    public static final void \u8d4b\u80fd(IBinder iBinder, Intent intent, IBinder iBinder2, IBinder iBinder3) {
        try {
            ((\u53d8\u9769)iBinder).\u4e2d\u53f0 = new Pair((Object)intent, (Object)iBinder2);
            IServiceConnection iServiceConnection = IServiceConnection.Stub.asInterface((IBinder)iBinder3);
            \u95ed\u73af.invoke((Object)iServiceConnection, (Object)\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)((\u53d8\u9769)iBinder).\u6293\u624b), (Object)iBinder2);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static final void \u8d4b\u80fd(IBinder iBinder, \u53d8\u9769 \u53d8\u97692, Pair pair) {
        try {
            IServiceConnection iServiceConnection = IServiceConnection.Stub.asInterface((IBinder)iBinder);
            ComponentName componentName = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u53d8\u97692.\u6293\u624b);
            \u95ed\u73af.invoke((Object)iServiceConnection, (Object)componentName, pair.getSecond());
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u8d4b\u80fd(\u53d8\u9769 \u53d8\u97692, Intent intent, IBinder iBinder, \u54c1\u724c \u54c1\u724c2) {
        \u53d8\u97692.\u843d\u5730.put((Object)new Intent.FilterComparison(intent), (Object)iBinder);
        \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c2.\u7ed9\u5230;
        if (\u6fc0\u6d3b2 == null) return;
        try {
            \u6fc0\u6d3b2.\u8d4b\u80fd((IBinder)\u53d8\u97692, intent);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(\u53d8\u9769 \u53d8\u97692, IBinder iBinder) {
        try {
            Intent intent;
            \u53d8\u97692.\u6f0f\u6597.remove((Object)iBinder);
            \u53d8\u97692.\u8d4b\u80fd.\u540c\u6b65.remove((Object)iBinder);
            if (!\u53d8\u97692.\u6f0f\u6597.isEmpty()) return;
            \u6fc0\u6d3b \u6fc0\u6d3b2 = \u53d8\u97692.\u8d4b\u80fd.\u7ed9\u5230;
            if (\u6fc0\u6d3b2 == null) return;
            if (!\u6fc0\u6d3b2.asBinder().isBinderAlive()) return;
            Pair pair = \u53d8\u97692.\u4e2d\u53f0;
            if (pair == null || (intent = (Intent)pair.getFirst()) == null) {
                intent = new Intent().setComponent(\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u53d8\u97692.\u6293\u624b));
            }
            \u6fc0\u6d3b2.\u6293\u624b((IBinder)\u53d8\u97692, intent);
            if (\u53d8\u97692.\u95ed\u73af > 0) return;
            \u53d8\u97692.\u8d4b\u80fd.\u5bf9\u9f50.\u6293\u624b(\u53d8\u97692.\u6293\u624b.name.hashCode());
            \u6fc0\u6d3b2.\u6c89\u6dc0((IBinder)\u53d8\u97692);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static final void \u8d4b\u80fd(\u53d8\u9769 \u53d8\u97692, \u54c1\u724c \u54c1\u724c2, IBinder iBinder) {
        IBinder[] arriBinder;
        int n;
        \u5dee\u5f02\u5316 \u5dee\u5f02\u53162 = \u53d8\u97692.\u6f0f\u6597;
        try {
            arriBinder = (IBinder[])\u5dee\u5f02\u53162.toArray((Object[])new IBinder[0]);
            n = arriBinder.length;
        }
        catch (Exception exception) {
            return;
        }
        for (int i = 0; i < n; ++i) {
            if (arriBinder[i].isBinderAlive()) continue;
            \u54c1\u724c2.\u540c\u6b65.remove((Object)iBinder);
            \u53d8\u97692.\u6f0f\u6597.remove((Object)iBinder);
            \u4e2d\u53f0.remove((Object)iBinder);
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(\u54c1\u724c \u54c1\u724c2, ServiceInfo serviceInfo, Intent intent) {
        try {
            int n;
            \u53d8\u9769 \u53d8\u97692 = (\u53d8\u9769)((Object)\u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode()));
            if (\u53d8\u97692 == null) {
                \u53d8\u97692 = new \u53d8\u9769(\u54c1\u724c2, serviceInfo);
                \u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode(), (Object)\u53d8\u97692);
            }
            \u53d8\u97692.\u95ed\u73af = n = 1 + \u53d8\u97692.\u95ed\u73af;
            \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c2.\u7ed9\u5230;
            if (\u6fc0\u6d3b2 == null) return;
            \u6fc0\u6d3b2.\u8d4b\u80fd(serviceInfo.name, intent, (IBinder)\u53d8\u97692, n);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(\u54c1\u724c \u54c1\u724c2, \u53d8\u9769 \u53d8\u97692, ServiceInfo serviceInfo) {
        try {
            \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c2.\u7ed9\u5230;
            if (\u6fc0\u6d3b2 != null) {
                \u6fc0\u6d3b2.\u6c89\u6dc0((IBinder)\u53d8\u97692);
            }
            \u54c1\u724c2.\u5bf9\u9f50.\u6293\u624b(serviceInfo.name.hashCode());
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final Unit \u95ed\u73af(Object object, ComponentName componentName, IBinder iBinder) {
        return Unit.INSTANCE;
    }

    @Override
    public final int \u4e2d\u53f0(Intent intent, String string) {
        \u53d8\u9769 \u53d8\u97692;
        \u54c1\u724c \u54c1\u724c2;
        ServiceInfo serviceInfo;
        block9 : {
            block8 : {
                block7 : {
                    block6 : {
                        try {
                            serviceInfo = \u5408\u529b.\u8d4b\u80fd(intent);
                            if (serviceInfo != null) break block6;
                            return -1;
                        }
                        catch (Exception exception) {
                            return -1;
                        }
                    }
                    \u54c1\u724c2 = \u9ad8\u5730.\u8d4b\u80fd(serviceInfo.processName, string);
                    if (\u54c1\u724c2 != null) break block7;
                    return 0;
                }
                \u53d8\u97692 = (\u53d8\u9769)((Object)\u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode()));
                if (\u53d8\u97692 != null) break block8;
                return 0;
            }
            \u53d8\u97692.\u95ed\u73af = 0;
            if (\u53d8\u97692.\u6f0f\u6597.isEmpty()) break block9;
            return 0;
        }
        \u5408\u529b$$ExternalSyntheticLambda17 \u5408\u529b$$ExternalSyntheticLambda17 = new \u5408\u529b$$ExternalSyntheticLambda17(\u54c1\u724c2, \u53d8\u97692, serviceInfo);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda17);
        return 1;
    }

    @Override
    public final boolean \u4e2d\u53f0(IBinder iBinder) {
        \u53d8\u9769 \u53d8\u97692;
        block3 : {
            try {
                \u53d8\u97692 = (\u53d8\u9769)((Object)\u4e2d\u53f0.remove((Object)iBinder));
                if (\u53d8\u97692 != null) break block3;
                return false;
            }
            catch (Exception exception) {
                return false;
            }
        }
        \u5408\u529b$$ExternalSyntheticLambda11 \u5408\u529b$$ExternalSyntheticLambda11 = new \u5408\u529b$$ExternalSyntheticLambda11(\u53d8\u97692, iBinder);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda11);
        return true;
    }

    @Override
    public final void \u5e73\u53f0(String string) {
        \u5408\u529b$$ExternalSyntheticLambda1 \u5408\u529b$$ExternalSyntheticLambda1 = new \u5408\u529b$$ExternalSyntheticLambda1(string);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda1);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final int \u6293\u624b(Intent intent, IBinder iBinder, String string) {
        try {
            ConcurrentHashMap concurrentHashMap;
            Pair pair;
            ServiceInfo serviceInfo = \u5408\u529b.\u8d4b\u80fd(intent);
            if (serviceInfo == null) {
                return -1;
            }
            \u54c1\u724c \u54c1\u724c2 = \u9ad8\u5730.\u6293\u624b(serviceInfo.packageName, serviceInfo.processName, string);
            if (\u54c1\u724c2 == null) {
                return 0;
            }
            \u53d8\u9769 \u53d8\u97692 = (\u53d8\u9769)((Object)\u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode()));
            if (\u53d8\u97692 == null) {
                \u53d8\u97692 = new \u53d8\u9769(\u54c1\u724c2, serviceInfo);
                \u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode(), (Object)\u53d8\u97692);
                \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c2.\u7ed9\u5230;
                if (\u6fc0\u6d3b2 != null) {
                    \u6fc0\u6d3b2.\u8d4b\u80fd(serviceInfo.name, null, (IBinder)\u53d8\u97692, 0);
                }
            }
            if (!(concurrentHashMap = \u4e2d\u53f0).containsKey((Object)iBinder)) {
                int n = \u53d8\u97692.\u6f0f\u6597.size();
                if (n > 3000) {
                    return 0;
                }
                \u54c1\u724c2.\u540c\u6b65.add((Object)iBinder);
                \u53d8\u97692.\u6f0f\u6597.add((Object)iBinder);
                concurrentHashMap.put((Object)iBinder, (Object)\u53d8\u97692);
                if (n > 500) {
                    \u5408\u529b$$ExternalSyntheticLambda13 \u5408\u529b$$ExternalSyntheticLambda13 = new \u5408\u529b$$ExternalSyntheticLambda13(\u53d8\u97692, \u54c1\u724c2, iBinder);
                    \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda13);
                }
            }
            if ((pair = \u53d8\u97692.\u4e2d\u53f0) != null && ((Intent)pair.getFirst()).filterEquals(intent)) {
                \u5408\u529b$$ExternalSyntheticLambda14 \u5408\u529b$$ExternalSyntheticLambda14 = new \u5408\u529b$$ExternalSyntheticLambda14(iBinder, \u53d8\u97692, pair);
                \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda14);
                return 1;
            }
            \u5408\u529b$$ExternalSyntheticLambda15 \u5408\u529b$$ExternalSyntheticLambda15 = new \u5408\u529b$$ExternalSyntheticLambda15(\u53d8\u97692, intent, iBinder, \u54c1\u724c2);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda15);
            return 1;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public final int \u6293\u624b(Intent var1_1, String var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 10[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void \u6293\u624b(IBinder iBinder) {
        \u5bf9\u4e00\u4e0b \u5bf9\u4e00\u4e0b2;
        block4 : {
            \u5bf9\u4e00\u4e0b2 = (\u5bf9\u4e00\u4e0b)((Object)\u6f0f\u6597.remove((Object)iBinder));
            if (\u5bf9\u4e00\u4e0b2 != null) break block4;
            return;
        }
        try {
            \u5bf9\u4e00\u4e0b2.\u6293\u624b.\u5bf9\u6807.remove((Object)iBinder);
            Iterator iterator = \u5bf9\u4e00\u4e0b2.iterator();
            while (iterator.hasNext()) {
                \u5c01\u88c5 \u5c01\u88c52 = (\u5c01\u88c5)((Object)iterator.next());
                \u843d\u5730.\u8d4b\u80fd(\u5c01\u88c52);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final ArrayList \u6f0f\u6597(int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        try {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return new ArrayList(0);
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        ArrayList arrayList = new ArrayList();
        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd;
        int n2 = 0;
        do {
            boolean bl = n2 < \u6241\u5e73\u53162.\u4e2d\u53f0;
            if (!bl) return arrayList;
            Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
            int n3 = n2 + 1;
            \u54c1\u724c \u54c1\u724c3 = (\u54c1\u724c)arrobject[n2];
            if (\u54c1\u724c2 == null || Intrinsics.areEqual((Object)\u54c1\u724c2.\u4e2d\u53f0, (Object)\u54c1\u724c3.\u4e2d\u53f0) && Intrinsics.areEqual((Object)\u54c1\u724c2.\u8d4b\u80fd, (Object)\u54c1\u724c3.\u8d4b\u80fd)) {
                ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
                runningAppProcessInfo.processName = \u54c1\u724c3.\u6293\u624b;
                runningAppProcessInfo.pid = \u54c1\u724c3.\u5e73\u53f0;
                runningAppProcessInfo.pkgList = new String[]{\u54c1\u724c3.\u8d4b\u80fd};
                runningAppProcessInfo.uid = \u98ce\u53e3.\u4e2d\u53f0;
                runningAppProcessInfo.importance = 100;
                arrayList.add((Object)runningAppProcessInfo);
            }
            n2 = n3;
        } while (true);
    }

    @Override
    public final boolean \u6f0f\u6597(String string, String string2) {
        return \u516c\u5173.\u6293\u624b.\u6f0f\u6597(string, string2);
    }

    @Override
    public final ComponentName \u843d\u5730(Intent intent, String string) {
        \u54c1\u724c \u54c1\u724c2;
        ServiceInfo serviceInfo;
        block5 : {
            block4 : {
                try {
                    serviceInfo = \u5408\u529b.\u8d4b\u80fd(intent);
                    if (serviceInfo != null) break block4;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            \u54c1\u724c2 = \u9ad8\u5730.\u6293\u624b(serviceInfo.packageName, serviceInfo.processName, string);
            if (\u54c1\u724c2 != null) break block5;
            return null;
        }
        \u5408\u529b$$ExternalSyntheticLambda3 \u5408\u529b$$ExternalSyntheticLambda3 = new \u5408\u529b$$ExternalSyntheticLambda3(\u54c1\u724c2, serviceInfo, intent);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda3);
        ComponentName componentName = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)serviceInfo);
        return componentName;
    }

    @Override
    public final IBinder \u8d4b\u80fd(ComponentName componentName, String string) {
        ServiceInfo serviceInfo;
        \u54c1\u724c \u54c1\u724c2;
        block6 : {
            block5 : {
                try {
                    \u8fb9\u754c.\u6293\u624b.getClass();
                    serviceInfo = (ServiceInfo)\u8fb9\u754c.\u6f0f\u6597(componentName);
                    if (serviceInfo != null) break block5;
                }
                catch (Exception exception) {
                    return null;
                }
                serviceInfo = (ServiceInfo)\u98ce\u53e3.\u8d4b\u80fd(new \u5408\u529b$$ExternalSyntheticLambda0(componentName));
                if (serviceInfo != null) break block5;
                return null;
            }
            \u54c1\u724c2 = \u9ad8\u5730.\u8d4b\u80fd(serviceInfo.processName, string);
            if (\u54c1\u724c2 != null) break block6;
            return null;
        }
        IBinder iBinder = (IBinder)\u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode());
        return iBinder;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final IBinder \u8d4b\u80fd(String string, String string2, ProviderInfo[] arrproviderInfo, String[] arrstring, int n) {
        ProviderInfo providerInfo;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        try {
            providerInfo = \u8fb9\u754c.\u6293\u624b.\u7ed9\u5230(string);
            if (providerInfo == null) {
                providerInfo = (ProviderInfo)\u98ce\u53e3.\u8d4b\u80fd(new \u5408\u529b$$ExternalSyntheticLambda10(string));
                if (providerInfo == null) return null;
                String string3 = providerInfo.packageName;
                if (!\u8fb9\u754c.\u95ed\u73af.containsKey(string3)) return null;
                if (providerInfo == null) {
                    return null;
                }
            }
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return null;
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        if (\u54c1\u724c2 != null && Intrinsics.areEqual((Object)\u54c1\u724c2.\u8d4b\u80fd, (Object)providerInfo.packageName) && (Intrinsics.areEqual((Object)\u54c1\u724c2.\u6293\u624b, (Object)providerInfo.processName) || providerInfo.multiprocess)) {
            arrproviderInfo[0] = providerInfo;
            return null;
        }
        \u54c1\u724c \u54c1\u724c3 = \u9ad8\u5730.\u6293\u624b(providerInfo.packageName, providerInfo.processName, string2);
        if (\u54c1\u724c3 == null) {
            return null;
        }
        \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c3.\u7ed9\u5230;
        if (\u6fc0\u6d3b2 == null) return null;
        IBinder iBinder = \u6fc0\u6d3b2.\u5bf9\u9f50(string);
        if (iBinder == null) return null;
        String string4 = \u98ce\u53e3.\u6293\u624b;
        int n2 = \u54c1\u724c3.\u843d\u5730;
        arrstring[0] = string4 + ".provider.stub" + n2;
        return iBinder;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void \u8d4b\u80fd(int n, IBinder iBinder, IntentFilter intentFilter) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        try {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return;
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        if (\u54c1\u724c2 == null) {
            return;
        }
        if (\u54c1\u724c2.\u5bf9\u6807.size() >= 100) {
            return;
        }
        ConcurrentHashMap concurrentHashMap = \u6f0f\u6597;
        \u5bf9\u4e00\u4e0b \u5bf9\u4e00\u4e0b2 = (\u5bf9\u4e00\u4e0b)((Object)concurrentHashMap.get((Object)iBinder));
        if (\u5bf9\u4e00\u4e0b2 == null) {
            \u5bf9\u4e00\u4e0b2 = new \u5bf9\u4e00\u4e0b(iBinder, \u54c1\u724c2);
            concurrentHashMap.put((Object)iBinder, (Object)\u5bf9\u4e00\u4e0b2);
            \u54c1\u724c2.\u5bf9\u6807.add((Object)iBinder);
        }
        if (\u5bf9\u4e00\u4e0b2.\u8d4b\u80fd(intentFilter)) {
            return;
        }
        \u5c01\u88c5 \u5c01\u88c52 = new \u5c01\u88c5(intentFilter, \u5bf9\u4e00\u4e0b2, \u54c1\u724c2.\u8d4b\u80fd);
        \u5bf9\u4e00\u4e0b2.add((Object)\u5c01\u88c52);
        \u843d\u5730.\u8d4b\u80fd((IntentFilter)\u5c01\u88c52);
    }

    @Override
    public final void \u8d4b\u80fd(String string, String string2, String string3) {
        \u5408\u529b$$ExternalSyntheticLambda4 \u5408\u529b$$ExternalSyntheticLambda4 = new \u5408\u529b$$ExternalSyntheticLambda4(string, string2, string3);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda4);
    }

    public final void \u8d4b\u80fd(\u54c1\u724c \u54c1\u724c2) {
        Iterator iterator = \u54c1\u724c2.\u540c\u6b65.iterator();
        while (iterator.hasNext()) {
            IBinder iBinder = (IBinder)iterator.next();
            \u4e2d\u53f0.remove((Object)iBinder);
        }
        \u5dee\u5f02\u5316 \u5dee\u5f02\u53162 = \u54c1\u724c2.\u5bf9\u6807;
        IBinder[] arriBinder = (IBinder[])\u5dee\u5f02\u53162.toArray((Object[])new IBinder[0]);
        \u54c1\u724c2.\u5bf9\u6807.clear();
        int n = arriBinder.length;
        for (int i = 0; i < n; ++i) {
            try {
                this.\u6293\u624b(arriBinder[i]);
            }
            catch (Exception exception) {
                // empty catch block
                break;
            }
            continue;
        }
    }

    @Override
    public final boolean \u8d4b\u80fd(ComponentName componentName, IBinder iBinder, int n) {
        block10 : {
            block9 : {
                block8 : {
                    try {
                        if (!(iBinder instanceof \u53d8\u9769)) {
                            return false;
                        }
                        if (componentName == null) break block8;
                    }
                    catch (Exception exception) {
                        return false;
                    }
                    if (Intrinsics.areEqual((Object)componentName.getClassName(), (Object)((\u53d8\u9769)iBinder).\u6293\u624b.name)) break block8;
                    return true;
                }
                if (n >= 0) {
                    if (((\u53d8\u9769)iBinder).\u95ed\u73af == n) break block9;
                    return true;
                }
            }
            if (((\u53d8\u9769)iBinder).\u6f0f\u6597.isEmpty()) break block10;
            return true;
        }
        \u5408\u529b$$ExternalSyntheticLambda16 \u5408\u529b$$ExternalSyntheticLambda16 = new \u5408\u529b$$ExternalSyntheticLambda16(iBinder);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda16);
        return true;
    }

    @Override
    public final boolean \u8d4b\u80fd(IBinder iBinder, Intent intent, IBinder iBinder2) {
        IBinder iBinder3;
        block5 : {
            block4 : {
                try {
                    if (iBinder instanceof \u53d8\u9769) break block4;
                    return false;
                }
                catch (Throwable throwable) {
                    return false;
                }
            }
            iBinder3 = (IBinder)((\u53d8\u9769)iBinder).\u843d\u5730.remove((Object)new Intent.FilterComparison(intent));
            if (iBinder3 != null) break block5;
            return false;
        }
        \u5408\u529b$$ExternalSyntheticLambda2 \u5408\u529b$$ExternalSyntheticLambda2 = new \u5408\u529b$$ExternalSyntheticLambda2(iBinder, intent, iBinder2, iBinder3);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u5408\u529b$$ExternalSyntheticLambda2);
        return true;
    }

    @Override
    public final IBinder \u95ed\u73af(Intent intent, String string) {
        block6 : {
            \u53d8\u9769 \u53d8\u97692;
            block7 : {
                ServiceInfo serviceInfo;
                block5 : {
                    try {
                        serviceInfo = \u5408\u529b.\u8d4b\u80fd(intent);
                        if (serviceInfo != null) break block5;
                        return null;
                    }
                    catch (Exception exception) {
                        return null;
                    }
                }
                \u54c1\u724c \u54c1\u724c2 = \u9ad8\u5730.\u8d4b\u80fd(serviceInfo.processName, string);
                if (\u54c1\u724c2 == null) break block6;
                \u53d8\u97692 = (\u53d8\u9769)((Object)\u54c1\u724c2.\u5bf9\u9f50.\u8d4b\u80fd(serviceInfo.name.hashCode()));
                if (\u53d8\u97692 != null) break block7;
                return null;
            }
            IBinder iBinder = (IBinder)\u53d8\u97692.\u843d\u5730.get((Object)new Intent.FilterComparison(intent));
            return iBinder;
        }
        return null;
    }

    @Override
    public final void \u95ed\u73af() {
        \u9ad8\u5730.\u8d4b\u80fd();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void \u95ed\u73af(String string, String string2) {
        Iterator iterator;
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        ArrayList arrayList;
        int n;
        try {
            arrayList = new ArrayList();
            \u6241\u5e73\u53162 = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd;
            n = 0;
        }
        catch (Exception exception) {
            // empty catch block
            return;
        }
        do {
            boolean bl;
            int n2;
            if (bl = n < \u6241\u5e73\u53162.\u4e2d\u53f0) {
                Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
                n2 = n + 1;
                \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)arrobject[n];
                if ((string == null || string.length() == 0 || Intrinsics.areEqual((Object)\u54c1\u724c2.\u8d4b\u80fd, (Object)string)) && (string2 == null || string2.length() == 0 || Intrinsics.areEqual((Object)\u54c1\u724c2.\u4e2d\u53f0, (Object)string2))) {
                    arrayList.add((Object)\u54c1\u724c2);
                }
            } else {
                iterator = arrayList.iterator();
                break;
            }
            n = n2;
        } while (true);
        while (iterator.hasNext()) {
            \u54c1\u724c \u54c1\u724c3 = (\u54c1\u724c)iterator.next();
            try {
                int n3 = \u54c1\u724c3.\u5e73\u53f0;
                if (n3 > 0) {
                    Process.killProcess((int)n3);
                    continue;
                }
                \u6fc0\u6d3b \u6fc0\u6d3b2 = \u54c1\u724c3.\u7ed9\u5230;
                if (\u6fc0\u6d3b2 == null) continue;
                \u6fc0\u6d3b2.\u6f0f\u6597();
            }
            catch (Exception exception) {}
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final String[] \u95ed\u73af(int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        String[] arrstring = new String[3];
        for (int i = 0; i < 3; ++i) {
            arrstring[i] = "";
        }
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u4e2d\u53f0;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        try {
            \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
            if (\u54c1\u724c2 == null) return arrstring;
            arrstring[0] = \u54c1\u724c2.\u8d4b\u80fd;
            arrstring[1] = \u54c1\u724c2.\u6293\u624b;
            arrstring[2] = \u54c1\u724c2.\u4e2d\u53f0;
            return arrstring;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrstring;
    }
}

