/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;

public interface \u6fc0\u6d3b
extends IInterface {
    public void \u54cd\u5e94(String var1);

    public IBinder \u5bf9\u9f50(String var1);

    public void \u6293\u624b(IBinder var1, Intent var2);

    public void \u6c89\u6dc0(IBinder var1);

    public void \u6f0f\u6597();

    public void \u8d4b\u80fd(Intent var1, IBinder var2, String var3);

    public void \u8d4b\u80fd(IBinder var1, Intent var2);

    public void \u8d4b\u80fd(String var1, Intent var2, IBinder var3, int var4);

    public void \u8d4b\u80fd(String var1, String var2, String var3, boolean var4, String var5);
}

