/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u7ea2\u6d77
extends FunctionReferenceImpl
implements Function2 {
    public \u7ea2\u6d77(\u8d77\u98de \u8d77\u98de2) {
        super(2, (Object)\u8d77\u98de2, \u81ea\u6d3d.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        ((\u81ea\u6d3d)this.receiver).\u8d4b\u80fd(object, object2);
        return Unit.INSTANCE;
    }
}

