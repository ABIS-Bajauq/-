/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u53ec\u56de;
import top.bienvenido.date_24323.\u6388\u6743;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u4e0a\u6e38
extends FunctionReferenceImpl
implements Function1 {
    public static final \u4e0a\u6e38 \u8d4b\u80fd = new \u4e0a\u6e38();

    public \u4e0a\u6e38() {
        super(1, \u6388\u6743.class, "asInterface", "asInterface(Landroid/os/IBinder;)Ltop/bienvenido/mundo/IMundoPackageManagerService;", 0);
    }

    public final Object invoke(Object object) {
        IBinder iBinder = (IBinder)object;
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("MundoPackageManagerService");
        if (iInterface != null && iInterface instanceof \u94f8\u9020) {
            return (\u94f8\u9020)iInterface;
        }
        return new \u53ec\u56de(iBinder);
    }
}

