/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8ddf\u8fdb$$ExternalSyntheticLambda0;

public final class \u8ddf\u8fdb
extends \u89e6\u8fbe {
    public static final boolean \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        return \u589e\u957f2.\u6293\u624b((Account)arrobject[0]);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u8ddf\u8fdb$$ExternalSyntheticLambda0(arrobject));
    }
}

