/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u6316\u6398
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6316\u6398;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u6316\u6398$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;

    public /* synthetic */ \u6316\u6398$$ExternalSyntheticLambda0(Object[] arrobject) {
        this.f$0 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u6316\u6398.\u8d4b\u80fd((Object[])this.f$0, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

