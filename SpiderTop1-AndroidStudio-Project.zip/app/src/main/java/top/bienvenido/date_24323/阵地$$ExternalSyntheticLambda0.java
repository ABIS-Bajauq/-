/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u9635\u5730;

public final class \u9635\u5730$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ \u9635\u5730 f$1;
    public final /* synthetic */ \u54c1\u724c f$2;

    public /* synthetic */ \u9635\u5730$$ExternalSyntheticLambda0(IBinder iBinder, \u9635\u5730 \u9635\u57302, \u54c1\u724c \u54c1\u724c2) {
        this.f$0 = iBinder;
        this.f$1 = \u9635\u57302;
        this.f$2 = \u54c1\u724c2;
    }

    public final void run() {
        \u9635\u5730.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2);
    }
}

