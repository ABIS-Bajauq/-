/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  sun.misc.Unsafe
 */
package top.bienvenido.date_24323;

import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u5782\u76f4
extends \u81ea\u6d3d {
    public final /* synthetic */ long \u6293\u624b;

    public \u5782\u76f4(long l) {
        this.\u6293\u624b = l;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object) {
        \u62a4\u57ce\u6cb3.\u8d4b\u80fd.getClass();
        return \u62a4\u57ce\u6cb3.\u6293\u624b.getObject(object, this.\u6293\u624b);
    }

    @Override
    public final void \u8d4b\u80fd(Object object, Object object2) {
        \u62a4\u57ce\u6cb3.\u8d4b\u80fd.getClass();
        \u62a4\u57ce\u6cb3.\u6293\u624b.putObject(object, this.\u6293\u624b, object2);
    }
}

