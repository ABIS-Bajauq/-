/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.IInterface;
import java.util.ArrayList;
import java.util.List;

public interface \u94f8\u9020
extends IInterface {
    public PackageInfo \u4e2d\u53f0(String var1, int var2);

    public ProviderInfo \u4e2d\u53f0(ComponentName var1);

    public ArrayList \u4e2d\u53f0(int var1);

    public List \u4e2d\u53f0(Intent var1, String var2, int var3);

    public void \u4e2d\u53f0(String var1, String var2);

    public int \u4f18\u5316(String var1);

    public void \u540c\u6b65(String var1);

    public boolean \u5bf9\u6807(String var1);

    public ArrayList \u5e73\u53f0(String var1, String var2);

    public ActivityInfo \u6293\u624b(ComponentName var1);

    public ApplicationInfo \u6293\u624b(String var1, int var2);

    public ArrayList \u6293\u624b();

    public List \u6293\u624b(Intent var1, String var2, int var3);

    public void \u6293\u624b(int var1);

    public boolean \u6293\u624b(String var1);

    public void \u6c89\u6dc0();

    public String[] \u6c89\u6dc0(int var1);

    public String[] \u6c89\u6dc0(String var1);

    public int \u6f0f\u6597(String var1);

    public List \u6f0f\u6597(Intent var1, String var2, int var3);

    public ProviderInfo \u7ed9\u5230(String var1);

    public void \u7ed9\u5230(String var1, String var2);

    public ResolveInfo \u843d\u5730(Intent var1, String var2, int var3);

    public ServiceInfo \u843d\u5730(ComponentName var1);

    public ArrayList \u843d\u5730(int var1);

    public boolean \u843d\u5730(String var1);

    public int \u8d4b\u80fd(ComponentName var1);

    public int \u8d4b\u80fd(String var1, int var2);

    public String \u8d4b\u80fd(int var1);

    public List \u8d4b\u80fd(Intent var1, String var2, int var3);

    public void \u8d4b\u80fd(ComponentName var1, int var2);

    public void \u8d4b\u80fd(List var1);

    public String[] \u8d4b\u80fd(int[] var1);

    public String \u8fed\u4ee3(String var1);

    public ActivityInfo \u95ed\u73af(ComponentName var1);

    public ResolveInfo \u95ed\u73af(Intent var1, String var2, int var3);

    public boolean \u95ed\u73af(String var1);
}

