/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.List
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u8f90\u5c04
extends \u89e6\u8fbe {
    public static final \u8f90\u5c04 \u8d4b\u80fd = new \u8f90\u5c04();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            String string = object2 != null ? object2.toString() : null;
            if (!Intrinsics.areEqual((Object)\u6c34\u4f4d.\u6293\u624b, (Object)string)) return method.invoke(object, arrobject);
            return Collections.EMPTY_LIST;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

