/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5361\u4f4d$
 *  top.bienvenido.date_24323.\u5361\u4f4d$$ExternalSyntheticLambda0
 *  top.bienvenido.mundo.manifest.MundoService
 *  top.bienvenido.mundo.manifest.MundoService$Companion
 *  top.bienvenido.mundo.manifest.MundoService$Companion$STUB
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import java.util.ArrayList;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d$;
import top.bienvenido.date_24323.\u5361\u70b9;
import top.bienvenido.date_24323.\u6c34\u51c6;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.manifest.MundoService;

public abstract class \u5361\u4f4d {
    public static final ArrayList \u95ed\u73af = new ArrayList();
    public Object \u4e2d\u53f0;
    public final String \u6293\u624b;
    public final Function1 \u8d4b\u80fd;

    public \u5361\u4f4d(Function1 function1, String string2) {
        this.\u8d4b\u80fd = function1;
        this.\u6293\u624b = string2;
        try {
            \u95ed\u73af.add((Object)new $ExternalSyntheticLambda0(this));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final Unit \u8d4b\u80fd(\u5361\u4f4d \u5361\u4f4d2, Bundle bundle) {
        IBinder iBinder = bundle.getBinder(\u5361\u4f4d2.\u6293\u624b);
        if (iBinder != null) {
            Object object = \u5361\u4f4d2.\u8d4b\u80fd.invoke((Object)iBinder);
            if (object != null) {
                iBinder.linkToDeath((IBinder.DeathRecipient)new \u6c34\u51c6(iBinder, \u5361\u4f4d2), 0);
            } else {
                object = null;
            }
            \u5361\u4f4d2.\u4e2d\u53f0 = object;
        }
        return Unit.INSTANCE;
    }

    public final Object \u8d4b\u80fd() {
        Object object = this.\u4e2d\u53f0;
        if (object == null) {
            \u5361\u70b9.\u8d4b\u80fd();
            object = this.\u4e2d\u53f0;
        }
        return object;
    }

    public final Object \u8d4b\u80fd(Function1 function1) {
        try {
            Object object = function1.invoke(this.\u8d4b\u80fd());
            return object;
        }
        catch (Exception exception) {
            try {
                Context context = \u98ce\u53e3.\u8d4b\u80fd;
                context.startService(new Intent(context, MundoService.Companion.STUB.class));
            }
            catch (Exception exception2) {
                // empty catch block
            }
            return null;
        }
    }
}

