/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5171\u60c5;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5171\u60c5$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u5171\u60c5 f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ \u5171\u60c5$$ExternalSyntheticLambda0(\u5171\u60c5 \u5171\u60c52, Object object) {
        this.f$0 = \u5171\u60c52;
        this.f$1 = object;
    }

    public final Object invoke(Object object) {
        return \u5171\u60c5.\u8d4b\u80fd(this.f$0, this.f$1, (\u94f8\u9020)object);
    }
}

