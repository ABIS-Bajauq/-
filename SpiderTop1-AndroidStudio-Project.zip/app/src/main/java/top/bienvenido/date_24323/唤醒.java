/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u8ba4\u8bc1
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u8ba4\u8bc1;

public final class \u5524\u9192 {
    public static final \u8ba4\u8bc1 \u8d4b\u80fd = new \u8ba4\u8bc1();
}

