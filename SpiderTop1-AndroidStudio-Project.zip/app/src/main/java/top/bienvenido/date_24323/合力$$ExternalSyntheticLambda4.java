/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda4(String string2, String string3, String string4) {
        this.f$0 = string2;
        this.f$1 = string3;
        this.f$2 = string4;
    }

    public final void run() {
        \u5408\u529b.\u4e2d\u53f0((String)this.f$0, (String)this.f$1, (String)this.f$2);
    }
}

