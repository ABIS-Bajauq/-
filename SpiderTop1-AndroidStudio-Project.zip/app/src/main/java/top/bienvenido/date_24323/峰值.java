/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u5cf0\u503c
extends MutablePropertyReference1Impl {
    public static final \u5cf0\u503c \u8d4b\u80fd = new \u5cf0\u503c();

    public \u5cf0\u503c() {
        super(ResolveInfo.class, "serviceInfo", "getServiceInfo()Landroid/content/pm/ServiceInfo;", 0);
    }

    public final Object get(Object object) {
        return ((ResolveInfo)object).serviceInfo;
    }

    public final void set(Object object, Object object2) {
        ((ResolveInfo)object).serviceInfo = (ServiceInfo)object2;
    }
}

