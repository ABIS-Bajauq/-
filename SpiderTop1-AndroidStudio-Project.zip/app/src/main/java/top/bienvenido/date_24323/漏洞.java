/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ResolveInfo
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function4
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u6f0f\u6d1e
extends FunctionReferenceImpl
implements Function4 {
    public static final \u6f0f\u6d1e \u8d4b\u80fd = new \u6f0f\u6d1e();

    public \u6f0f\u6d1e() {
        super(4, \u94f8\u9020.class, "resolveService", "resolveService(Landroid/content/Intent;Ljava/lang/String;I)Landroid/content/pm/ResolveInfo;", 0);
    }

    public final Object invoke(Object object, Object object2, Object object3, Object object4) {
        return ((\u94f8\u9020)object).\u95ed\u73af((Intent)object2, (String)object3, ((Number)object4).intValue());
    }
}

