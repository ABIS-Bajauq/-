/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ProviderInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.collections.ArraysKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.ProviderInfo;
import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

public final class \u5c65\u7ea6
extends FunctionReferenceImpl
implements Function1 {
    public static final \u5c65\u7ea6 \u8d4b\u80fd = new \u5c65\u7ea6();

    public \u5c65\u7ea6() {
        super(1, ArraysKt.class, "toTypedArray", "toTypedArray(Ljava/util/Collection;)[Ljava/lang/Object;", 1);
    }

    public final Object invoke(Object object) {
        return (ProviderInfo[])((List)object).toArray((Object[])new ProviderInfo[0]);
    }
}

