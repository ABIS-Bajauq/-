/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;

public abstract class \u6536\u53e3 {
    public static Intent \u8d4b\u80fd(IBinder iBinder, Intent intent) {
        Intent intent2 = new Intent();
        if (intent != null) {
            intent2.putExtra("mundo_base_bundle", (Parcelable)intent);
        }
        if (iBinder != null) {
            Bundle bundle = new Bundle();
            bundle.putBinder("mundo_base_string", iBinder);
            intent2.putExtras(bundle);
        }
        return intent2;
    }

    public static IBinder \u8d4b\u80fd(Intent intent, Intent intent2) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Intent intent3 = (Intent)intent.getParcelableExtra("mundo_base_bundle");
            if (intent3 != null) {
                try {
                    intent2.fillIn(intent3, -1);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            return bundle.getBinder("mundo_base_string");
        }
        return null;
    }
}

