/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityThread
 *  android.app.Application
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  kotlin.collections.ArraysKt
 */
package top.bienvenido.date_24323;

import android.app.ActivityThread;
import android.app.Application;
import java.lang.reflect.Field;
import kotlin.collections.ArraysKt;
import top.bienvenido.date_24323.\u6c34\u4f4d;

public abstract class \u7559\u5b58 {
    public static final String[] \u8d4b\u80fd = new String[]{"com.rekoo.pubgm", "com.pubg.krmobile", "com.vng.pubgmobile", "com.pubg.imobile", "com.tencent.ig"};

    public static void \u8d4b\u80fd() {
        Application application;
        if (ArraysKt.contains((Object[])\u8d4b\u80fd, (Object)\u6c34\u4f4d.\u6293\u624b) && (application = ActivityThread.currentApplication()) != null) {
            ClassLoader classLoader = application.getClassLoader();
            if (classLoader == null) {
                return;
            }
            Class class_ = classLoader.loadClass("com.facebook.login.LoginBehavior");
            Field field = class_.getDeclaredField("NATIVE_WITH_FALLBACK");
            field.setAccessible(true);
            Object object = field.get(null);
            Field field2 = class_.getDeclaredField("allowsGetTokenAuth");
            field2.setAccessible(true);
            Boolean bl = Boolean.FALSE;
            field2.set(object, (Object)bl);
            Field field3 = class_.getDeclaredField("allowsKatanaAuth");
            field3.setAccessible(true);
            field3.set(object, (Object)bl);
            Field field4 = class_.getDeclaredField("allowsFacebookLiteAuth");
            field4.setAccessible(true);
            field4.set(object, (Object)bl);
            Field field5 = class_.getDeclaredField("allowsInstagramAppAuth");
            field5.setAccessible(true);
            field5.set(object, (Object)bl);
        }
    }
}

