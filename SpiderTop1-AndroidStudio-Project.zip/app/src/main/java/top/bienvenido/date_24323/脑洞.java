/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.TypeIntrinsics
 *  top.bienvenido.date_24323.\u8111\u66b4
 *  top.bienvenido.date_24323.\u8111\u6d1e$
 *  top.bienvenido.date_24323.\u8111\u6d1e$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.TypeIntrinsics;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8111\u66b4;
import top.bienvenido.date_24323.\u8111\u6d1e$;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u8111\u6d1e {
    public final Function1 \u6293\u624b;
    public final \u81ea\u6d3d \u8d4b\u80fd = \u771f\u9999.\u8d4b\u80fd("android.app.PropertyInvalidatedCache", "mCache");

    public \u8111\u6d1e() {
        Object object = \u62bd\u8c61.\u5bf9\u6807 ? new \u8111\u66b4() : new $ExternalSyntheticLambda0();
        this.\u6293\u624b = object;
    }

    public static final Unit \u8d4b\u80fd(Object object) {
        TypeIntrinsics.asMutableMap((Object)object).clear();
        return Unit.INSTANCE;
    }

    public final void \u8d4b\u80fd(Class class_, String string2) {
        Function1 function1 = this.\u6293\u624b;
        \u81ea\u6d3d \u81ea\u6d3d2 = this.\u8d4b\u80fd;
        Object object = \u771f\u9999.\u4e2d\u53f0(class_, string2);
        if (object == null) {
            return;
        }
        function1.invoke(\u81ea\u6d3d2.\u8d4b\u80fd(object));
    }
}

