/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Singleton
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u5171\u521b
 *  top.bienvenido.date_24323.\u534f\u540c
 *  top.bienvenido.date_24323.\u53d8\u8fc1
 *  top.bienvenido.date_24323.\u5f15\u5bfc
 *  top.bienvenido.date_24323.\u62c9\u5347
 *  top.bienvenido.date_24323.\u62c9\u901a
 *  top.bienvenido.date_24323.\u8054\u52a8
 *  top.bienvenido.date_24323.\u878d\u5408
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.util.Singleton;
import top.bienvenido.date_24323.\u5171\u521b;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u5f15\u5bfc;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62c9\u5347;
import top.bienvenido.date_24323.\u62c9\u901a;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8054\u52a8;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u878d\u5408;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d70\u51fa\u53bb;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u900f\u4f20;

public final class \u6d1e\u5bdf {
    public static final \u6d1e\u5bdf \u8d4b\u80fd = new \u6d1e\u5bdf();

    public static void \u8d4b\u80fd() {
        Object object = \u771f\u9999.\u4e2d\u53f0(Class.forName((String)"android.app.ActivityClient"), "INTERFACE_SINGLETON");
        if (object == null) {
            return;
        }
        if (object instanceof Singleton) {
            \u8d70\u51fa\u53bb.\u8d4b\u80fd.\u8d4b\u80fd(object, (Object)null);
            \u8d77\u98de \u8d77\u98de2 = new \u8d77\u98de("mKnownInstance");
            Object object2 = \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object);
            if (object2 == null) {
                return;
            }
            \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object2, (\u89e6\u8fbe)\u672c\u6211.\u6293\u624b);
            \u5171\u521b \u5171\u521b2 = new \u5171\u521b();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(463520714, (Object)\u5171\u521b2);
            \u878d\u5408 \u878d\u54082 = new \u878d\u5408();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1293072352, (Object)\u878d\u54082);
            \u8054\u52a8 \u8054\u52a82 = \u900f\u4f20.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1666360360, (Object)\u8054\u52a82);
            \u534f\u540c \u534f\u540c2 = \u900f\u4f20.\u6293\u624b;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1770569149, (Object)\u534f\u540c2);
            \u62c9\u901a \u62c9\u901a2 = new \u62c9\u901a();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1349683719, (Object)\u62c9\u901a2);
            \u62c9\u5347 \u62c9\u53472 = new \u62c9\u5347();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1985825802, (Object)\u62c9\u53472);
            \u5f15\u5bfc \u5f15\u5bfc2 = \u5f15\u5bfc.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1111243300, (Object)\u5f15\u5bfc2);
            Object object3 = \u51fa\u51fb2.\u95ed\u73af;
            \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object, object3);
        }
    }
}

