/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u53d8\u9769;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda11
implements Runnable {
    public final /* synthetic */ \u53d8\u9769 f$0;
    public final /* synthetic */ IBinder f$1;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda11(\u53d8\u9769 \u53d8\u97692, IBinder iBinder) {
        this.f$0 = \u53d8\u97692;
        this.f$1 = iBinder;
    }

    public final void run() {
        \u5408\u529b.\u8d4b\u80fd((\u53d8\u9769)this.f$0, (IBinder)this.f$1);
    }
}

