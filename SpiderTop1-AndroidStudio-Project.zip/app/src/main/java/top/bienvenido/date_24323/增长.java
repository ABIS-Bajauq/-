/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.AuthenticatorDescription
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.AuthenticatorDescription;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import java.util.HashMap;
import java.util.Map;

public interface \u589e\u957f
extends IInterface {
    public String \u4e2d\u53f0(Account var1);

    public String \u4e2d\u53f0(Account var1, String var2);

    public HashMap \u54cd\u5e94(String var1, String var2);

    public String \u6293\u624b(Account var1, String var2);

    public void \u6293\u624b(Account var1, String var2, String var3);

    public void \u6293\u624b(IBinder var1, String var2, String[] var3);

    public boolean \u6293\u624b(Account var1);

    public Account[] \u7ed9\u5230();

    public AuthenticatorDescription[] \u843d\u5730();

    public void \u8d4b\u80fd(Account var1, String var2);

    public void \u8d4b\u80fd(Account var1, String var2, String var3);

    public void \u8d4b\u80fd(IBinder var1, Account var2);

    public void \u8d4b\u80fd(IBinder var1, Account var2, Bundle var3, boolean var4);

    public void \u8d4b\u80fd(IBinder var1, Account var2, String var3);

    public void \u8d4b\u80fd(IBinder var1, Account var2, String var3, boolean var4, Bundle var5);

    public void \u8d4b\u80fd(IBinder var1, Account var2, String var3, boolean var4, boolean var5, Bundle var6);

    public void \u8d4b\u80fd(IBinder var1, Account var2, boolean var3);

    public void \u8d4b\u80fd(IBinder var1, Account var2, String[] var3);

    public void \u8d4b\u80fd(IBinder var1, String var2, String var3);

    public void \u8d4b\u80fd(IBinder var1, String var2, String var3, String[] var4, boolean var5, Bundle var6);

    public void \u8d4b\u80fd(IBinder var1, String var2, boolean var3);

    public void \u8d4b\u80fd(IBinder var1, String var2, String[] var3);

    public void \u8d4b\u80fd(String var1, String var2);

    public boolean \u8d4b\u80fd(Account var1);

    public boolean \u8d4b\u80fd(Account var1, String var2, Bundle var3, Map var4);

    public Account[] \u8ddf\u8fdb(String var1);
}

