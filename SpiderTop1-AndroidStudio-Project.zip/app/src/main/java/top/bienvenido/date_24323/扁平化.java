/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 *  java.util.Arrays
 */
package top.bienvenido.date_24323;

import java.util.Arrays;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u8bb2\u6545\u4e8b;

public final class \u6241\u5e73\u5316 {
    public int \u4e2d\u53f0;
    public Object[] \u6293\u624b;
    public int[] \u8d4b\u80fd;

    public \u6241\u5e73\u5316(int n) {
        if (n == 0) {
            this.\u8d4b\u80fd = \u4e0b\u6c89.\u8d4b\u80fd;
            this.\u6293\u624b = \u4e0b\u6c89.\u4e2d\u53f0;
        } else {
            this.\u6293\u624b = new Object[n];
            this.\u8d4b\u80fd = new int[n];
        }
        this.\u4e2d\u53f0 = 0;
    }

    public final boolean \u6293\u624b(int n) {
        int[] arrn = this.\u8d4b\u80fd;
        int n2 = this.\u4e2d\u53f0;
        int n3 = \u753b\u997c.\u8d4b\u80fd(arrn, n2, n);
        if (n3 < 0) {
            return false;
        }
        if (n2 == 1) {
            this.\u4e2d\u53f0 = 0;
            this.\u8d4b\u80fd = \u4e0b\u6c89.\u8d4b\u80fd;
            this.\u6293\u624b = \u4e0b\u6c89.\u4e2d\u53f0;
            return true;
        }
        int n4 = n2 - 1;
        int n5 = n4 - n3;
        Object[] arrobject = this.\u6293\u624b;
        if (n4 < arrobject.length >> 2) {
            Object[] arrobject2 = new Object[n4];
            int[] arrn2 = new int[n4];
            if (n3 != 0) {
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n3);
                System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)n3);
            }
            if (n5 != 0) {
                int n6 = n3 + 1;
                System.arraycopy((Object)arrobject, (int)n6, (Object)arrobject2, (int)n3, (int)n5);
                System.arraycopy((Object)arrn, (int)n6, (Object)arrn2, (int)n3, (int)n5);
            }
            this.\u6293\u624b = arrobject2;
            this.\u8d4b\u80fd = arrn2;
        } else {
            if (n5 != 0) {
                int n7 = n3 + 1;
                System.arraycopy((Object)arrobject, (int)n7, (Object)arrobject, (int)n3, (int)n5);
                System.arraycopy((Object)arrn, (int)n7, (Object)arrn, (int)n3, (int)n5);
            }
            arrobject[n4] = null;
        }
        this.\u4e2d\u53f0 = n4;
        return true;
    }

    public final Object \u8d4b\u80fd(int n) {
        int n2 = \u753b\u997c.\u8d4b\u80fd(this.\u8d4b\u80fd, this.\u4e2d\u53f0, n);
        if (n2 < 0) {
            return null;
        }
        return this.\u6293\u624b[n2];
    }

    public final void \u8d4b\u80fd(int n, Object object) {
        int[] arrn = this.\u8d4b\u80fd;
        int n2 = this.\u4e2d\u53f0;
        int n3 = \u753b\u997c.\u8d4b\u80fd(arrn, n2, n);
        if (n3 >= 0) {
            this.\u6293\u624b[n3] = object;
            return;
        }
        int n4 = n3;
        this.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n2, n4, n);
        int n5 = n2 + 1;
        Object[] arrobject = this.\u6293\u624b;
        if (n5 <= arrobject.length) {
            System.arraycopy((Object)arrobject, (int)n4, (Object)arrobject, (int)(n4 + 1), (int)(n2 - n4));
            arrobject[n4] = object;
        } else {
            Object[] arrobject2 = new Object[(n2 | 1) << 1];
            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n4);
            arrobject2[n4] = object;
            System.arraycopy((Object)arrobject, (int)n4, (Object)arrobject2, (int)(n4 + 1), (int)(arrobject.length - n4));
            arrobject = arrobject2;
        }
        this.\u6293\u624b = arrobject;
        this.\u4e2d\u53f0 = n5;
    }

    public final Object[] \u8d4b\u80fd() {
        return Arrays.copyOf((Object[])this.\u6293\u624b, (int)this.\u4e2d\u53f0);
    }
}

