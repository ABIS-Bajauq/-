/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.AttributionSourceState
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ProviderInfo
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.Triple
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  sun.misc.Unsafe
 */
package top.bienvenido.date_24323;

import android.content.AttributionSourceState;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ProviderInfo;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcelable;
import java.lang.reflect.Method;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u56de\u5f52;
import top.bienvenido.date_24323.\u5bfc\u6d41$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u6295\u653e;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u63a8\u5e7f;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8170\u90e8;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u5bfc\u6d41
extends \u89e6\u53d1 {
    public static final int \u4e2d\u53f0;
    public static final \u89e6\u8fbe \u5e73\u53f0;
    public static final \u5bfc\u6d41 \u6293\u624b;
    public static final \u8d77\u98de \u6c89\u6dc0;
    public static final \u8d77\u98de \u6f0f\u6597;
    public static final \u8d77\u98de \u7ed9\u5230;
    public static final \u81ea\u6d3d \u843d\u5730;
    public static final String \u95ed\u73af;

    static {
        \u81ea\u6d3d \u81ea\u6d3d2;
        \u6293\u624b = new \u5bfc\u6d41();
        int n = \u62bd\u8c61.\u6c89\u6dc0 ? 2 : 1;
        \u4e2d\u53f0 = n;
        String string = \u98ce\u53e3.\u6293\u624b;
        \u95ed\u73af = string + ".service.provider";
        Class[] arrclass = new Class[]{IBinder.class};
        Class class_ = Class.forName((String)"android.content.ContentProviderNative");
        try {
            Method method = class_.getDeclaredMethod("asInterface", arrclass);
            method.setAccessible(true);
            \u81ea\u6d3d2 = new \u76ae\u5b9e(method);
        }
        catch (Exception exception) {
            try {
                \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
            }
            catch (Exception exception2) {
                \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
            }
        }
        \u843d\u5730 = \u81ea\u6d3d2;
        try {
            if (\u62bd\u8c61.\u5e73\u53f0) {
                \u5bfc\u6d41$$ExternalSyntheticLambda0 \u5bfc\u6d41$$ExternalSyntheticLambda0 = new \u5bfc\u6d41$$ExternalSyntheticLambda0();
                \u81ea\u6d3d \u81ea\u6d3d3 = \u771f\u9999.\u8d4b\u80fd(AttributionSourceState.class, "CREATOR");
                \u81ea\u6d3d3.\u8d4b\u80fd((Object)null, (Object)new \u8170\u90e8((Parcelable.Creator)\u81ea\u6d3d3.\u8d4b\u80fd(null), \u5bfc\u6d41$$ExternalSyntheticLambda0));
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        \u6f0f\u6597 = new \u8d77\u98de("provider");
        \u6c89\u6dc0 = new \u8d77\u98de("info");
        \u7ed9\u5230 = new \u8d77\u98de("mLocal");
        \u5e73\u53f0 = \u672c\u6211.\u8d4b\u80fd(new \u63a8\u5e7f());
    }

    public static Object \u8d4b\u80fd(Object object) {
        \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u5e73\u53f0);
        try {
            if (\u62bd\u8c61.\u7ed9\u5230) {
                \u6295\u653e \u6295\u653e2 = new \u6295\u653e();
                \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(107944136, \u6295\u653e2);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return \u51fa\u51fb2.\u95ed\u73af;
    }

    public static final Unit \u8d4b\u80fd(AttributionSourceState attributionSourceState) {
        try {
            attributionSourceState.uid = Binder.getCallingUid();
            if (\u62bd\u8c61.\u54cd\u5e94) {
                attributionSourceState.pid = -1;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        block13 : {
            try {
                if (!\u6c34\u4f4d.\u8d4b\u80fd) {
                    return super.\u8d4b\u80fd(object, method, arrobject);
                }
                int n = \u4e2d\u53f0;
                Object object3 = arrobject[n];
                if (object3 == null) return super.\u8d4b\u80fd(object, method, arrobject);
                String string = object3.toString();
                if (string != null) {
                    if (Intrinsics.areEqual((Object)string, (Object)\u95ed\u73af)) {
                        return super.\u8d4b\u80fd(object, method, arrobject);
                    }
                    Triple triple = \u56de\u5f52.\u8d4b\u80fd(string);
                    IBinder iBinder = (IBinder)triple.getFirst();
                    if (iBinder != null) {
                        String string2 = (String)triple.getSecond();
                        if (string2 != null) {
                            Object object4 = \u843d\u5730.\u8d4b\u80fd((Object)null, new Object[]{iBinder});
                            if (object4 != null) {
                                \u5bfc\u6d41 \u5bfc\u6d412 = \u6293\u624b;
                                arrobject[n] = string2;
                                Object object5 = super.\u8d4b\u80fd(object, method, arrobject);
                                \u5bfc\u6d41.\u6f0f\u6597.\u6293\u624b.\u8d4b\u80fd(object5, object4);
                                ProviderInfo providerInfo = (ProviderInfo)\u5bfc\u6d41.\u6c89\u6dc0.\u6293\u624b.\u8d4b\u80fd(object5);
                                if (providerInfo == null) return object5;
                                providerInfo.authority = string;
                                return object5;
                            }
                        }
                    } else {
                        ProviderInfo providerInfo = (ProviderInfo)triple.getThird();
                        if (providerInfo != null) {
                            Object object6 = \u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(method.getReturnType());
                            \u8d77\u98de \u8d77\u98de2 = \u6c89\u6dc0;
                            \u6269\u5c55.\u8d4b\u80fd(providerInfo.applicationInfo);
                            \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object6, (Object)providerInfo);
                            if (!\u62bd\u8c61.\u5e73\u53f0) return object6;
                            \u8d77\u98de \u8d77\u98de3 = \u7ed9\u5230;
                            Boolean bl = Boolean.TRUE;
                            \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd(object6, (Object)bl);
                            return object6;
                        }
                    }
                    break block13;
                }
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if ((object2 = super.\u8d4b\u80fd(object, method, arrobject)) == null) return null;
        try {
            \u8d77\u98de \u8d77\u98de4 = \u6f0f\u6597;
            Object object7 = \u8d77\u98de4.\u6293\u624b.\u8d4b\u80fd(object2);
            if (object7 == null) {
                return object2;
            }
            Object object8 = \u5bfc\u6d41.\u8d4b\u80fd(object7);
            \u8d77\u98de4.\u6293\u624b.\u8d4b\u80fd(object2, object8);
            return object2;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return object2;
    }
}

