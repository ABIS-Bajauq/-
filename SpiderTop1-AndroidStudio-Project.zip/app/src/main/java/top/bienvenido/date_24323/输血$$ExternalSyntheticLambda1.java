/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.IContentObserver
 *  android.net.Uri
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u8f93\u8840
 */
package top.bienvenido.date_24323;

import android.database.IContentObserver;
import android.net.Uri;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u8ba2\u9605;
import top.bienvenido.date_24323.\u8f93\u8840;

public final class \u8f93\u8840$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Uri f$0;
    public final /* synthetic */ IContentObserver f$1;
    public final /* synthetic */ boolean f$2;

    public /* synthetic */ \u8f93\u8840$$ExternalSyntheticLambda1(Uri uri, IContentObserver iContentObserver, boolean bl) {
        this.f$0 = uri;
        this.f$1 = iContentObserver;
        this.f$2 = bl;
    }

    public final Object invoke(Object object) {
        return \u8f93\u8840.\u6293\u624b((Uri)this.f$0, (IContentObserver)this.f$1, (boolean)this.f$2, (\u8ba2\u9605)((\u8ba2\u9605)object));
    }
}

