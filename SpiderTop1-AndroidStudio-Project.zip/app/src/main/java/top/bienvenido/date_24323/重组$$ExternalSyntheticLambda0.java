/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u91cd\u7ec4
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u91cd\u7ec4;

public final class \u91cd\u7ec4$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ int f$0;
    public final /* synthetic */ Intent f$1;

    public /* synthetic */ \u91cd\u7ec4$$ExternalSyntheticLambda0(int n, Intent intent) {
        this.f$0 = n;
        this.f$1 = intent;
    }

    public final Object invoke(Object object) {
        return \u91cd\u7ec4.\u8d4b\u80fd((int)this.f$0, (Intent)this.f$1, (\u5e03\u5c40)((\u5e03\u5c40)object));
    }
}

