/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function3
 *  top.bienvenido.date_24323.\u53e3\u7891
 *  top.bienvenido.date_24323.\u7248\u672c
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import top.bienvenido.date_24323.\u53e3\u7891;
import top.bienvenido.date_24323.\u7248\u672c;
import top.bienvenido.date_24323.\u8499\u5c42;

public final class \u6307\u6807
extends \u8499\u5c42 {
    public final \u7248\u672c \u6293\u624b = new \u7248\u672c();
    public final \u53e3\u7891 \u8d4b\u80fd = \u53e3\u7891.\u8d4b\u80fd;

    @Override
    public final Function3 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

