/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

public abstract class \u4e0b\u6c89 {
    public static final Object[] \u4e2d\u53f0;
    public static final Class[] \u6293\u624b;
    public static final int[] \u8d4b\u80fd;
    public static final String[] \u95ed\u73af;

    static {
        \u8d4b\u80fd = new int[0];
        \u6293\u624b = new Class[0];
        \u4e2d\u53f0 = new Object[0];
        \u95ed\u73af = new String[0];
    }
}

