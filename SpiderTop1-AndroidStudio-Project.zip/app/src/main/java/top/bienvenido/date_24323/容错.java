/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.bluetooth.IBluetooth
 *  android.bluetooth.IBluetooth$Stub
 *  android.bluetooth.IBluetoothManagerCallback
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Exception
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.bluetooth.IBluetooth;
import android.bluetooth.IBluetoothManagerCallback;
import android.os.IBinder;
import android.os.IInterface;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8e1d\u90e8;
import top.bienvenido.mundo.common.ext.MundoBleCallback;

public final class \u5bb9\u9519
extends MundoBleCallback {
    public final /* synthetic */ \u89e6\u8fbe \u6293\u624b;
    public final /* synthetic */ IBluetoothManagerCallback \u8d4b\u80fd;

    public \u5bb9\u9519(IBluetoothManagerCallback iBluetoothManagerCallback, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.\u8d4b\u80fd = iBluetoothManagerCallback;
        this.\u6293\u624b = \u89e6\u8fbe2;
    }

    @Override
    public final void onBluetoothOff() {
        try {
            this.\u8d4b\u80fd.onBluetoothOff();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public final void onBluetoothOn() {
        try {
            this.\u8d4b\u80fd.onBluetoothOn();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public final void onBluetoothServiceDown() {
        try {
            this.\u8d4b\u80fd.onBluetoothServiceDown();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void onBluetoothServiceUp(IBluetooth iBluetooth) {
        IBluetooth iBluetooth2;
        IBluetoothManagerCallback iBluetoothManagerCallback;
        try {
            iBluetoothManagerCallback = this.\u8d4b\u80fd;
            iBluetooth2 = iBluetooth != null ? (IBluetooth)\u56f4\u7ed5.\u8d4b\u80fd((Object)iBluetooth, this.\u6293\u624b) : null;
        }
        catch (Exception exception) {
            return;
        }
        iBluetoothManagerCallback.onBluetoothServiceUp(iBluetooth2);
    }

    @Override
    public final void onBluetoothServiceUp(IBinder iBinder) {
        try {
            this.\u8d4b\u80fd.onBluetoothServiceUp((IBinder)new \u8e1d\u90e8(iBinder, (IInterface)\u56f4\u7ed5.\u8d4b\u80fd((Object)IBluetooth.Stub.asInterface((IBinder)iBinder), this.\u6293\u624b)));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public final void onBrEdrDown() {
        try {
            this.\u8d4b\u80fd.onBrEdrDown();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

