/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$IntentInfo
 *  android.content.pm.PackageParser$Package
 *  android.content.pm.ResolveInfo
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageParser;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u5236\u7ea6;
import top.bienvenido.date_24323.\u6d41\u5931;
import top.bienvenido.date_24323.\u7834\u5c40;
import top.bienvenido.date_24323.\u7834\u9898;

public final class \u7ea6\u675f
implements \u6d41\u5931 {
    public final \u5236\u7ea6 \u4e2d\u53f0;
    public final \u7834\u9898 \u6293\u624b;
    public final \u7834\u9898 \u8d4b\u80fd;
    public final \u7834\u5c40 \u95ed\u73af;

    public \u7ea6\u675f(PackageParser.Package package_) {
        this.\u8d4b\u80fd = new \u7834\u9898(this, package_.activities);
        this.\u6293\u624b = new \u7834\u9898(this, package_.receivers);
        this.\u4e2d\u53f0 = new \u5236\u7ea6(this, package_.services);
        this.\u95ed\u73af = new \u7834\u5c40(this, package_.providers);
    }

    public static final ResolveInfo \u8d4b\u80fd(\u7ea6\u675f \u7ea6\u675f2, ComponentInfo componentInfo, Function2 function2, PackageParser.IntentInfo intentInfo, int n, int n2) {
        if (!componentInfo.enabled && (n & 512) == 0) {
            return null;
        }
        ResolveInfo resolveInfo = new ResolveInfo();
        if ((n & 64) != 0) {
            resolveInfo.filter = intentInfo;
        }
        resolveInfo.match = n2;
        resolveInfo.nonLocalizedLabel = intentInfo.nonLocalizedLabel;
        resolveInfo.priority = intentInfo.getPriority();
        resolveInfo.icon = intentInfo.icon;
        resolveInfo.labelRes = intentInfo.labelRes;
        resolveInfo.isDefault = intentInfo.hasDefault;
        function2.invoke((Object)resolveInfo, (Object)componentInfo);
        return resolveInfo;
    }

    @Override
    public final List \u4e2d\u53f0(Intent intent, String string, int n) {
        \u7834\u9898 \u7834\u98982 = this.\u8d4b\u80fd;
        \u7834\u98982.getClass();
        boolean bl = (65536 & n) != 0;
        return \u7834\u98982.\u8d4b\u80fd(intent, string, bl, n);
    }

    @Override
    public final List \u6293\u624b(Intent intent, String string, int n) {
        \u5236\u7ea6 \u5236\u7ea62 = this.\u4e2d\u53f0;
        \u5236\u7ea62.getClass();
        boolean bl = (65536 & n) != 0;
        return \u5236\u7ea62.\u8d4b\u80fd(intent, string, bl, n);
    }

    @Override
    public final List \u8d4b\u80fd(Intent intent, String string, int n) {
        \u7834\u9898 \u7834\u98982 = this.\u6293\u624b;
        \u7834\u98982.getClass();
        boolean bl = (65536 & n) != 0;
        return \u7834\u98982.\u8d4b\u80fd(intent, string, bl, n);
    }

    @Override
    public final List \u95ed\u73af(Intent intent, String string, int n) {
        \u7834\u5c40 \u7834\u5c402 = this.\u95ed\u73af;
        \u7834\u5c402.getClass();
        boolean bl = (65536 & n) != 0;
        return \u7834\u5c402.\u8d4b\u80fd(intent, string, bl, n);
    }
}

