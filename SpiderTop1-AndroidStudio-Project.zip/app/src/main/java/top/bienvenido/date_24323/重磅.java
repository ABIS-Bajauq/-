/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Field
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Field;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u91cd\u78c5
extends \u81ea\u6d3d {
    public final /* synthetic */ Field \u6293\u624b;

    public \u91cd\u78c5(Field field) {
        this.\u6293\u624b = field;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object) {
        return this.\u6293\u624b.get(object);
    }

    @Override
    public final void \u8d4b\u80fd(Object object, Object object2) {
        this.\u6293\u624b.set(object, object2);
    }
}

