/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 *  kotlin.reflect.KMutableProperty1
 */
package top.bienvenido.date_24323;

import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.reflect.KMutableProperty1;

public final class \u58c1\u5792
extends FunctionReferenceImpl
implements Function2 {
    public \u58c1\u5792(Object object) {
        super(2, object, KMutableProperty1.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        ResolveInfo resolveInfo = (ResolveInfo)object;
        ServiceInfo serviceInfo = (ServiceInfo)object2;
        ((KMutableProperty1)this.receiver).set((Object)resolveInfo, (Object)serviceInfo);
        return Unit.INSTANCE;
    }
}

