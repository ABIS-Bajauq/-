/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class \u642d\u5efa {
    public static void \u8d4b\u80fd(Parcel parcel, Parcelable parcelable, int n) {
        if (parcelable != null) {
            parcel.writeInt(1);
            parcelable.writeToParcel(parcel, n);
            return;
        }
        parcel.writeInt(0);
    }
}

