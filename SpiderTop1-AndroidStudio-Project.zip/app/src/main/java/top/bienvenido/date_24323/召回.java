/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import top.bienvenido.date_24323.\u63a5\u5165;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u53ec\u56de
implements \u94f8\u9020 {
    public final IBinder \u8d4b\u80fd;

    public \u53ec\u56de(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final PackageInfo \u4e2d\u53f0(String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(3, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = PackageInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            PackageInfo packageInfo = (PackageInfo)object;
            return packageInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ProviderInfo \u4e2d\u53f0(ComponentName componentName) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            this.\u8d4b\u80fd.transact(8, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ProviderInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ProviderInfo providerInfo = (ProviderInfo)object;
            return providerInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final ArrayList \u4e2d\u53f0(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(15, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(PackageInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u4e2d\u53f0(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(9, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ResolveInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u4e2d\u53f0(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(28, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final int \u4f18\u5316(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(21, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u540c\u6b65(String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(20, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u5bf9\u6807(String string) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoPackageManagerService");
                parcel.writeString(string);
                this.\u8d4b\u80fd.transact(1, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final ArrayList \u5e73\u53f0(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(18, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ProviderInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ActivityInfo \u6293\u624b(ComponentName componentName) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            this.\u8d4b\u80fd.transact(5, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ActivityInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ActivityInfo activityInfo = (ActivityInfo)object;
            return activityInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ApplicationInfo \u6293\u624b(String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(4, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ApplicationInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ApplicationInfo applicationInfo = (ApplicationInfo)object;
            return applicationInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final ArrayList \u6293\u624b() {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            this.\u8d4b\u80fd.transact(32, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createStringArrayList();
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u6293\u624b(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(13, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ResolveInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u6293\u624b(int n) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(33, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u6293\u624b(String string) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoPackageManagerService");
                parcel.writeString(string);
                this.\u8d4b\u80fd.transact(31, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final void \u6c89\u6dc0() {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            this.\u8d4b\u80fd.transact(30, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String[] \u6c89\u6dc0(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(22, parcel, parcel2, 0);
            parcel2.readException();
            String[] arrstring = parcel2.createStringArray();
            return arrstring;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String[] \u6c89\u6dc0(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(29, parcel, parcel2, 0);
            parcel2.readException();
            String[] arrstring = parcel2.createStringArray();
            return arrstring;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final int \u6f0f\u6597(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(25, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u6f0f\u6597(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(14, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ResolveInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ProviderInfo \u7ed9\u5230(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(17, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ProviderInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ProviderInfo providerInfo = (ProviderInfo)object;
            return providerInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u7ed9\u5230(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(27, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ResolveInfo \u843d\u5730(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(12, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ResolveInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ResolveInfo resolveInfo = (ResolveInfo)object;
            return resolveInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ServiceInfo \u843d\u5730(ComponentName componentName) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            this.\u8d4b\u80fd.transact(7, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ServiceInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ServiceInfo serviceInfo = (ServiceInfo)object;
            return serviceInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final ArrayList \u843d\u5730(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(16, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ApplicationInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u843d\u5730(String string) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoPackageManagerService");
                parcel.writeString(string);
                this.\u8d4b\u80fd.transact(34, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final int \u8d4b\u80fd(ComponentName componentName) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            this.\u8d4b\u80fd.transact(37, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final int \u8d4b\u80fd(String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(26, parcel, parcel2, 0);
            parcel2.readException();
            int n2 = parcel2.readInt();
            return n2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String \u8d4b\u80fd(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(23, parcel, parcel2, 0);
            parcel2.readException();
            String string = parcel2.readString();
            return string;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u8d4b\u80fd(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(10, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ResolveInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(ComponentName componentName, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(36, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(List list) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, list, 0);
            this.\u8d4b\u80fd.transact(35, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String[] \u8d4b\u80fd(int[] arrn) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeIntArray(arrn);
            this.\u8d4b\u80fd.transact(24, parcel, parcel2, 0);
            parcel2.readException();
            String[] arrstring = parcel2.createStringArray();
            return arrstring;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String \u8fed\u4ee3(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(19, parcel, parcel2, 0);
            parcel2.readException();
            String string2 = parcel2.readString();
            return string2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ActivityInfo \u95ed\u73af(ComponentName componentName) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            this.\u8d4b\u80fd.transact(6, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ActivityInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ActivityInfo activityInfo = (ActivityInfo)object;
            return activityInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ResolveInfo \u95ed\u73af(Intent intent, String string, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoPackageManagerService");
            \u63a5\u5165.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(11, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ResolveInfo.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ResolveInfo resolveInfo = (ResolveInfo)object;
            return resolveInfo;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u95ed\u73af(String string) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoPackageManagerService");
                parcel.writeString(string);
                this.\u8d4b\u80fd.transact(2, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }
}

