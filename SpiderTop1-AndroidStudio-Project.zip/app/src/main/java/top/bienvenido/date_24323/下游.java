/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u4e0a\u6e38
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0a\u6e38;
import top.bienvenido.date_24323.\u5361\u4f4d;

public final class \u4e0b\u6e38
extends \u5361\u4f4d {
    public static final \u4e0b\u6e38 \u843d\u5730 = new \u4e0b\u6e38();

    public \u4e0b\u6e38() {
        super((Function1)\u4e0a\u6e38.\u8d4b\u80fd, "MundoPackageManagerService");
    }
}

