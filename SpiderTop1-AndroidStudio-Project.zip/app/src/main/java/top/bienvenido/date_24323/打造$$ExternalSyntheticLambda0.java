/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.IContentObserver
 *  android.net.Uri
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u6253\u9020
 */
package top.bienvenido.date_24323;

import android.database.IContentObserver;
import android.net.Uri;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6253\u9020;
import top.bienvenido.date_24323.\u8ba2\u9605;

public final class \u6253\u9020$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Uri f$0;
    public final /* synthetic */ Object[] f$1;
    public final /* synthetic */ IContentObserver f$2;

    public /* synthetic */ \u6253\u9020$$ExternalSyntheticLambda0(Uri uri, Object[] arrobject, IContentObserver iContentObserver) {
        this.f$0 = uri;
        this.f$1 = arrobject;
        this.f$2 = iContentObserver;
    }

    public final Object invoke(Object object) {
        return \u6253\u9020.\u8d4b\u80fd((Uri)this.f$0, (Object[])this.f$1, (IContentObserver)this.f$2, (\u8ba2\u9605)((\u8ba2\u9605)object));
    }
}

