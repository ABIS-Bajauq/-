/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;
import top.bienvenido.date_24323.\u77e9\u9635;

public final class \u7ebd\u5e26
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ IAccountManagerResponse \u540c\u6b65;
    public final /* synthetic */ Account \u5bf9\u9f50;

    public \u7ebd\u5e26(IAccountManagerResponse iAccountManagerResponse, Account account, String string, String string2) {
        this.\u540c\u6b65 = iAccountManagerResponse;
        this.\u5bf9\u9f50 = account;
        super(iAccountManagerResponse, string, false, false, string2, false, false);
    }

    @Override
    public final void onResult(Bundle bundle) {
        if (bundle != null && bundle.getBoolean("booleanResult", false)) {
            Account account = this.\u5bf9\u9f50;
            String string = account.type;
            String string2 = account.name;
            \u77e9\u9635 \u77e9\u96352 = new \u77e9\u9635(this.\u540c\u6b65, account, bundle, string, string2);
            \u77e9\u96352.\u5e73\u53f0();
            return;
        }
        super.onResult(bundle);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.getAccountCredentialsForCloning((IAccountAuthenticatorResponse)this, this.\u5bf9\u9f50);
        }
    }
}

