/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.util.LruCache
 *  android.util.Pair
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.util.LruCache;
import android.util.Pair;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u611f\u77e5\u5ea6;
import top.bienvenido.date_24323.\u7ec4\u5408\u62f3;
import top.bienvenido.date_24323.\u9897\u7c92\u5ea6;

public final class \u65b9\u6cd5\u8bba
extends LruCache {
    public final \u515c\u5e95 \u6293\u624b = new \u515c\u5e95(0);
    public final \u515c\u5e95 \u8d4b\u80fd = new \u515c\u5e95(0);

    public \u65b9\u6cd5\u8bba() {
        super(64000);
    }

    public final void entryRemoved(boolean bl, Object object, Object object2, Object object3) {
        \u9897\u7c92\u5ea6 \u9897\u7c92\u5ea62;
        \u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62 = (\u611f\u77e5\u5ea6)object;
        \u7ec4\u5408\u62f3 \u7ec4\u5408\u62f32 = (\u7ec4\u5408\u62f3)object2;
        \u7ec4\u5408\u62f3 \u7ec4\u5408\u62f33 = (\u7ec4\u5408\u62f3)object3;
        if (\u7ec4\u5408\u62f32 != null && \u7ec4\u5408\u62f33 == null && (\u9897\u7c92\u5ea62 = (\u9897\u7c92\u5ea6)this.\u8d4b\u80fd.remove((Object)new Pair((Object)\u611f\u77e5\u5ea62.\u8d4b\u80fd.type, (Object)\u7ec4\u5408\u62f32.\u8d4b\u80fd))) != null) {
            \u9897\u7c92\u5ea62.\u8d4b\u80fd();
        }
    }

    public final int sizeOf(Object object, Object object2) {
        (\u611f\u77e5\u5ea6)object;
        return ((\u7ec4\u5408\u62f3)object2).\u8d4b\u80fd.length();
    }

    public final void \u8d4b\u80fd(String string2, String string3) {
        \u9897\u7c92\u5ea6 \u9897\u7c92\u5ea62 = (\u9897\u7c92\u5ea6)this.\u8d4b\u80fd.get((Object)new Pair((Object)string2, (Object)string3));
        if (\u9897\u7c92\u5ea62 != null) {
            \u9897\u7c92\u5ea62.\u8d4b\u80fd();
        }
    }

    public final void \u8d4b\u80fd(\u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62, \u7ec4\u5408\u62f3 \u7ec4\u5408\u62f32) {
        Pair pair = new Pair((Object)\u611f\u77e5\u5ea62.\u8d4b\u80fd.type, (Object)\u7ec4\u5408\u62f32.\u8d4b\u80fd);
        \u9897\u7c92\u5ea6 \u9897\u7c92\u5ea62 = (\u9897\u7c92\u5ea6)this.\u8d4b\u80fd.get((Object)pair);
        if (\u9897\u7c92\u5ea62 == null) {
            \u9897\u7c92\u5ea62 = new \u9897\u7c92\u5ea6(this);
        }
        \u9897\u7c92\u5ea62.\u8d4b\u80fd.add((Object)\u611f\u77e5\u5ea62);
        this.\u8d4b\u80fd.put((Object)pair, \u9897\u7c92\u5ea62);
        \u9897\u7c92\u5ea6 \u9897\u7c92\u5ea63 = (\u9897\u7c92\u5ea6)this.\u6293\u624b.get((Object)\u611f\u77e5\u5ea62.\u8d4b\u80fd);
        if (\u9897\u7c92\u5ea63 == null) {
            \u9897\u7c92\u5ea63 = new \u9897\u7c92\u5ea6(this);
        }
        \u9897\u7c92\u5ea63.\u8d4b\u80fd.add((Object)\u611f\u77e5\u5ea62);
        this.\u6293\u624b.put((Object)\u611f\u77e5\u5ea62.\u8d4b\u80fd, \u9897\u7c92\u5ea63);
        this.put((Object)\u611f\u77e5\u5ea62, (Object)\u7ec4\u5408\u62f32);
    }
}

