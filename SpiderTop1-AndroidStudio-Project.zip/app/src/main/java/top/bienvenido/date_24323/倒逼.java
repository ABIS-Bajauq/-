/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.AuthenticatorDescription
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.accounts.AuthenticatorDescription;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5012\u903c$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u5012\u903c
extends \u89e6\u8fbe {
    public static final AuthenticatorDescription[] \u8d4b\u80fd(\u589e\u957f \u589e\u957f2) {
        return \u589e\u957f2.\u843d\u5730();
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        AuthenticatorDescription[] arrauthenticatorDescription = (AuthenticatorDescription[])\u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u5012\u903c$$ExternalSyntheticLambda0());
        if (arrauthenticatorDescription == null) {
            arrauthenticatorDescription = new AuthenticatorDescription[]{};
        }
        return arrauthenticatorDescription;
    }
}

