/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u901a\u9053
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u901a\u9053;

public final class \u94fe\u8def
extends \u5361\u4f4d {
    public static final \u94fe\u8def \u843d\u5730 = new \u94fe\u8def();

    public \u94fe\u8def() {
        super((Function1)\u901a\u9053.\u8d4b\u80fd, "MundoActivityManagerService");
    }
}

