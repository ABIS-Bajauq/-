/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5171\u521b
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u5171\u521b;

public final class \u5171\u521b$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u5171\u521b$$ExternalSyntheticLambda1(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final void run() {
        \u5171\u521b.\u8d4b\u80fd((IBinder)this.f$0);
    }
}

