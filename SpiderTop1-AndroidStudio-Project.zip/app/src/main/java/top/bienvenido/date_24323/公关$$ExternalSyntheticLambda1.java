/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda1
implements Function0 {
    public final Object invoke() {
        return \u516c\u5173.\u5bf9\u9f50();
    }
}

