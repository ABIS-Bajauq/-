/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u57cb\u70b9$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u57cb\u70b9
extends \u89e6\u8fbe {
    public static final boolean \u8d4b\u80fd(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u95ed\u73af(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            String string = object2 != null ? object2.toString() : null;
            if (string == null) return method.invoke(object, arrobject);
            Boolean bl = (Boolean)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u57cb\u70b9$$ExternalSyntheticLambda0(string));
            boolean bl2 = bl != null ? bl : false;
            if (!bl2) return method.invoke(object, arrobject);
            arrobject[0] = \u98ce\u53e3.\u6293\u624b;
            return method.invoke(object, arrobject);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

