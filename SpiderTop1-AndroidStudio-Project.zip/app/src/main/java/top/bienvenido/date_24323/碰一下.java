/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;

public final class \u78b0\u4e00\u4e0b {
    public final \u6241\u5e73\u5316 \u8d4b\u80fd = new \u6241\u5e73\u5316(0);

    public final void \u6293\u624b(int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = this;
        synchronized (\u78b0\u4e00\u4e0b2) {
            this.\u8d4b\u80fd.\u6293\u624b(n);
            return;
        }
    }

    public final Object \u8d4b\u80fd(int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = this;
        synchronized (\u78b0\u4e00\u4e0b2) {
            Object object = this.\u8d4b\u80fd.\u8d4b\u80fd(n);
            return object;
        }
    }

    public final void \u8d4b\u80fd(int n, \u54c1\u724c \u54c1\u724c2) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = this;
        synchronized (\u78b0\u4e00\u4e0b2) {
            this.\u8d4b\u80fd.\u8d4b\u80fd(n, \u54c1\u724c2);
            return;
        }
    }
}

