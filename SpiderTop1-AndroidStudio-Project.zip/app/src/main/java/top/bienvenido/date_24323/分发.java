/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import kotlin.jvm.internal.Intrinsics;

public abstract class \u5206\u53d1 {
    public static String \u8d4b\u80fd(String string2) {
        return "mundo@" + string2 + "@";
    }

    public static String \u8d4b\u80fd(String string2, String string3) {
        if (Intrinsics.areEqual((Object)string3, (Object)"default_channel")) {
            return string3;
        }
        String string4 = \u5206\u53d1.\u8d4b\u80fd(string2);
        return string4 + string3;
    }
}

