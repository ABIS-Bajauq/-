/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.invoke.MethodHandle
 *  java.lang.invoke.MethodHandles
 *  java.lang.invoke.MethodHandles$Lookup
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  sun.misc.Unsafe
 *  top.bienvenido.mundo.common.reflection.MundoReflectionStub
 *  top.bienvenido.mundo.common.reflection.MundoReflectionStub$Executable
 */
package top.bienvenido.date_24323;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$Class;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$InvokeStub;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$MethodHandle;
import top.bienvenido.mundo.common.reflection.MundoReflectionStub$NeverCall;

public final class \u8d85\u6211 {
    public final int \u4e2d\u53f0;
    public final long \u6293\u624b;
    public final long \u843d\u5730;
    public final long \u8d4b\u80fd;
    public final Method \u95ed\u73af;

    public \u8d85\u6211(Class class_) {
        long l;
        Unsafe unsafe = \u62a4\u57ce\u6cb3.\u6293\u624b;
        this.\u8d4b\u80fd = unsafe.objectFieldOffset(MundoReflectionStub.Executable.class.getDeclaredField("artMethod"));
        long l2 = unsafe.objectFieldOffset(MundoReflectionStub.MethodHandle.class.getDeclaredField("artFieldOrMethod"));
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        Class[] arrclass = \u4e0b\u6c89.\u6293\u624b;
        Method method = MundoReflectionStub.NeverCall.class.getDeclaredMethod("a", arrclass);
        method.setAccessible(true);
        long l3 = unsafe.getLong((Object)lookup.unreflect(method), l2);
        MethodHandles.Lookup lookup2 = MethodHandles.lookup();
        Method method2 = MundoReflectionStub.NeverCall.class.getDeclaredMethod("b", arrclass);
        method2.setAccessible(true);
        this.\u6293\u624b = l = unsafe.getLong((Object)lookup2.unreflect(method2), l2) - l3;
        Method method3 = MundoReflectionStub.InvokeStub.class.getDeclaredMethod("invoke", new Class[]{Object[].class});
        method3.setAccessible(true);
        this.\u95ed\u73af = method3;
        long l4 = unsafe.objectFieldOffset(MundoReflectionStub.Class.class.getDeclaredField("methods"));
        long l5 = unsafe.getLong((Object)class_, l4);
        this.\u4e2d\u53f0 = unsafe.getInt(l5);
        this.\u843d\u5730 = l5 + (l3 - unsafe.getLong(MundoReflectionStub.NeverCall.class, l4) - l);
    }
}

