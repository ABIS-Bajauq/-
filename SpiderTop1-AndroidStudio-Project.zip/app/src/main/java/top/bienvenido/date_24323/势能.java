/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u5206\u53d1;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u52bf\u80fd
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            if (\u6c34\u4f4d.\u8d4b\u80fd) {
                arrobject[1] = \u5206\u53d1.\u8d4b\u80fd(\u6c34\u4f4d.\u6293\u624b, String.valueOf((Object)arrobject[1]));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

