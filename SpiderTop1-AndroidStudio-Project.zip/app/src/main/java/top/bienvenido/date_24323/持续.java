/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  top.bienvenido.date_24323.\u5f00\u62d3
 */
package top.bienvenido.date_24323;

import java.util.Iterator;
import java.util.Map;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u5f00\u62d3;
import top.bienvenido.date_24323.\u7075\u6d3b;

public final class \u6301\u7eed
implements Iterator,
Map.Entry {
    public final /* synthetic */ \u7075\u6d3b \u4e2d\u53f0;
    public int \u6293\u624b;
    public final int \u8d4b\u80fd;

    public \u6301\u7eed(\u7075\u6d3b \u7075\u6d3b2) {
        this.\u4e2d\u53f0 = \u7075\u6d3b2;
        this.\u8d4b\u80fd = -1 + ((\u5f00\u62d3)\u7075\u6d3b2).\u6293\u624b.\u4e2d\u53f0;
        this.\u6293\u624b = -1;
    }

    public final Object getKey() {
        \u7075\u6d3b \u7075\u6d3b2 = this.\u4e2d\u53f0;
        int n = this.\u6293\u624b;
        return ((\u5f00\u62d3)\u7075\u6d3b2).\u6293\u624b.\u6293\u624b[n << 1];
    }

    public final Object getValue() {
        \u7075\u6d3b \u7075\u6d3b2 = this.\u4e2d\u53f0;
        int n = this.\u6293\u624b;
        return ((\u5f00\u62d3)\u7075\u6d3b2).\u6293\u624b.\u6293\u624b[1 + (n << 1)];
    }

    public final boolean hasNext() {
        return this.\u6293\u624b < this.\u8d4b\u80fd;
    }

    public final Object next() {
        this.\u6293\u624b = 1 + this.\u6293\u624b;
        return this;
    }

    public final Object setValue(Object object) {
        \u7075\u6d3b \u7075\u6d3b2 = this.\u4e2d\u53f0;
        int n = this.\u6293\u624b;
        \u515c\u5e95 \u515c\u5e952 = ((\u5f00\u62d3)\u7075\u6d3b2).\u6293\u624b;
        int n2 = 1 | n << 1;
        Object[] arrobject = \u515c\u5e952.\u6293\u624b;
        Object object2 = arrobject[n2];
        arrobject[n2] = object;
        return object2;
    }
}

