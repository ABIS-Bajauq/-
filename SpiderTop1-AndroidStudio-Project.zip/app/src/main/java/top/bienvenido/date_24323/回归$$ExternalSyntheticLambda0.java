/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ProviderInfo
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.ProviderInfo;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u56de\u5f52;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u56de\u5f52$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ ProviderInfo[] f$1;
    public final /* synthetic */ String[] f$2;

    public /* synthetic */ \u56de\u5f52$$ExternalSyntheticLambda0(String string, ProviderInfo[] arrproviderInfo, String[] arrstring) {
        this.f$0 = string;
        this.f$1 = arrproviderInfo;
        this.f$2 = arrstring;
    }

    public final Object invoke(Object object) {
        return \u56de\u5f52.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (\u7b14\u82af)object);
    }
}

