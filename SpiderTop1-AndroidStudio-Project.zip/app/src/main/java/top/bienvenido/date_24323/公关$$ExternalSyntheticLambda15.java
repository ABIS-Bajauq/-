/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda15
implements Runnable {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda15(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final void run() {
        \u516c\u5173.\u5e73\u53f0((IBinder)this.f$0);
    }
}

