/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.android.internal.net.VpnConfig
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 *  kotlin.reflect.KMutableProperty1
 */
package top.bienvenido.date_24323;

import com.android.internal.net.VpnConfig;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.reflect.KMutableProperty1;

public final class \u5236\u9ad8\u70b9
extends FunctionReferenceImpl
implements Function2 {
    public \u5236\u9ad8\u70b9(Object object) {
        super(2, object, KMutableProperty1.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        VpnConfig vpnConfig = (VpnConfig)object;
        String string = (String)object2;
        ((KMutableProperty1)this.receiver).set((Object)vpnConfig, (Object)string);
        return Unit.INSTANCE;
    }
}

