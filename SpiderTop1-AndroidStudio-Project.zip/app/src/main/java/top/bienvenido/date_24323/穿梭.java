/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u54ac\u5408
 *  top.bienvenido.date_24323.\u6e17\u900f
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u54ac\u5408;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u6e17\u900f;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u7a7f\u68ad
extends \u96c6\u6210 {
    public static final \u7a7f\u68ad \u6293\u624b = new \u7a7f\u68ad();

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("appops", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        if (\u62bd\u8c61.\u7ed9\u5230) {
            \u6e17\u900f \u6e17\u900f2 = new \u6e17\u900f();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-792315585, (Object)\u6e17\u900f2);
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1266748009, (Object)\u6e17\u900f2);
            if (\u62bd\u8c61.\u5e73\u53f0) {
                \u54ac\u5408 \u54ac\u54082 = new \u54ac\u5408();
                \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1478865707, (Object)\u54ac\u54082);
                if (\u62bd\u8c61.\u540c\u6b65) {
                    \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(286882944, (Object)\u54ac\u54082);
                    if (\u62bd\u8c61.\u5bf9\u9f50) {
                        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1007945216, (Object)\u6e17\u900f2);
                        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1009199082, (Object)\u6e17\u900f2);
                    }
                }
            }
            \u79c1\u57df \u79c1\u57df2 = \u672c\u6211.\u7ed9\u5230;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1453475157, \u79c1\u57df2);
        }
        \u79c1\u57df \u79c1\u57df3 = \u672c\u6211.\u95ed\u73af;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-867717602, \u79c1\u57df3);
    }
}

