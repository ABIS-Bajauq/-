/*
 * Decompiled with CFR 0.0.
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u7075\u6d3b;

public final class \u5f00\u62d3
extends \u7075\u6d3b {
    public final /* synthetic */ \u515c\u5e95 \u6293\u624b;

    public \u5f00\u62d3(\u515c\u5e95 \u515c\u5e952) {
        this.\u6293\u624b = \u515c\u5e952;
    }
}

