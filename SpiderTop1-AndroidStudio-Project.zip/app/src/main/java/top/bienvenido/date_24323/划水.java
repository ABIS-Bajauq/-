/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.inputmethod.EditorInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.view.inputmethod.EditorInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u5212\u6c34
extends MutablePropertyReference1Impl {
    public static final \u5212\u6c34 \u8d4b\u80fd = new \u5212\u6c34();

    public \u5212\u6c34() {
        super(EditorInfo.class, "packageName", "getPackageName()Ljava/lang/String;", 0);
    }

    public final Object get(Object object) {
        return ((EditorInfo)object).packageName;
    }

    public final void set(Object object, Object object2) {
        ((EditorInfo)object).packageName = (String)object2;
    }
}

