/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u6253\u6cd5
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ String \u540c\u6b65;
    public final /* synthetic */ Bundle \u5bf9\u6807;
    public final /* synthetic */ String[] \u5bf9\u9f50;

    public \u6253\u6cd5(String string, boolean bl, String string2, String[] arrstring, Bundle bundle, IAccountManagerResponse iAccountManagerResponse) {
        this.\u540c\u6b65 = string2;
        this.\u5bf9\u9f50 = arrstring;
        this.\u5bf9\u6807 = bundle;
        super(iAccountManagerResponse, string, bl, true, null, false, true);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.addAccount((IAccountAuthenticatorResponse)this, this.\u8d4b\u80fd, this.\u540c\u6b65, this.\u5bf9\u9f50, this.\u5bf9\u6807);
        }
    }
}

