/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentProvider
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.Intent
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.CancellationSignal
 *  android.os.IBinder
 *  android.os.ParcelFileDescriptor
 *  android.os.Process
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Pair
 *  kotlin.jvm.functions.Function0
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 *  top.bienvenido.mundo.manifest.MundoService
 *  top.bienvenido.mundo.manifest.MundoService$Companion
 *  top.bienvenido.mundo.manifest.MundoService$Companion$STUB
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u4ed8\u8d39;
import top.bienvenido.date_24323.\u5361\u70b9;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7a7a\u767d;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.manifest.MundoService;

public abstract class \u6d3c\u5730
extends ContentProvider {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Bundle call(String string2, String string3, Bundle bundle) {
        \u6bb5\u4f4d \u6bb5\u4f4d2;
        try {
            if (\u6c34\u4f4d.\u6c89\u6dc0 == 0) {
                \u6c34\u4f4d.\u6c89\u6dc0 = Integer.parseInt((String)string2);
                if (bundle != null) {
                    \u5361\u70b9.\u8d4b\u80fd(bundle);
                    \u4ed8\u8d39.\u8d4b\u80fd = bundle.getBoolean("mundo_base_bundle", false);
                }
                Context context = \u98ce\u53e3.\u8d4b\u80fd;
                context.startService(new Intent(context, MundoService.Companion.STUB.class));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        \u6bb5\u4f4d \u6bb5\u4f4d3 = \u6bb5\u4f4d2 = \u6bb5\u4f4d.\u6293\u624b;
        synchronized (\u6bb5\u4f4d3) {
            \u6bb5\u4f4d.\u4f18\u5316.invoke();
        }
        Bundle bundle2 = new Bundle();
        bundle2.putBinder("user_handler", (IBinder)\u6bb5\u4f4d2);
        bundle2.putBoolean(\u6bb5\u4f4d2.getInterfaceDescriptor(), \u6c34\u4f4d.\u8d4b\u80fd);
        bundle2.putInt("user_pid", Process.myPid());
        return bundle2;
    }

    public final int delete(Uri uri, String string2, String[] arrstring) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                int n = ((ContentProvider)pair.getSecond()).delete((Uri)pair.getFirst(), string2, arrstring);
                return n;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return 0;
    }

    public final String[] getStreamTypes(Uri uri, String string2) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                String[] arrstring = ((ContentProvider)pair.getSecond()).getStreamTypes((Uri)pair.getFirst(), string2);
                return arrstring;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public final String getType(Uri uri) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                String string2 = ((ContentProvider)pair.getSecond()).getType((Uri)pair.getFirst());
                return string2;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                Uri uri2 = ((ContentProvider)pair.getSecond()).insert((Uri)pair.getFirst(), contentValues);
                return uri2;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public final boolean onCreate() {
        return true;
    }

    public final ParcelFileDescriptor openFile(Uri uri, String string2) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                ParcelFileDescriptor parcelFileDescriptor = ((ContentProvider)pair.getSecond()).openFile((Uri)pair.getFirst(), string2);
                return parcelFileDescriptor;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public final Cursor query(Uri uri, String[] arrstring, String string2, String[] arrstring2, String string3) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                Cursor cursor = ((ContentProvider)pair.getSecond()).query((Uri)pair.getFirst(), arrstring, string2, arrstring2, string3);
                return cursor;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return null;
    }

    public final boolean refresh(Uri uri, Bundle bundle, CancellationSignal cancellationSignal) {
        if (uri == null) {
            return false;
        }
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                boolean bl = ((ContentProvider)pair.getSecond()).refresh((Uri)pair.getFirst(), bundle, cancellationSignal);
                return bl;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return false;
    }

    public final int update(Uri uri, ContentValues contentValues, String string2, String[] arrstring) {
        Pair pair = \u7a7a\u767d.\u8d4b\u80fd(uri);
        if (pair != null) {
            try {
                int n = ((ContentProvider)pair.getSecond()).update((Uri)pair.getFirst(), contentValues, string2, arrstring);
                return n;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return 0;
    }
}

