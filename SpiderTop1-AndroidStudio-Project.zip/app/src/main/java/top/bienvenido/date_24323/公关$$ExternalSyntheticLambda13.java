/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda13
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ IBinder f$1;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda13(IBinder iBinder, IBinder iBinder2) {
        this.f$0 = iBinder;
        this.f$1 = iBinder2;
    }

    public final void run() {
        \u516c\u5173.\u6293\u624b((IBinder)this.f$0, (IBinder)this.f$1);
    }
}

