/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda7
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ ActivityInfo f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda7(String string2, ActivityInfo activityInfo, String string3) {
        this.f$0 = string2;
        this.f$1 = activityInfo;
        this.f$2 = string3;
    }

    public final void run() {
        \u516c\u5173.\u8d4b\u80fd((String)this.f$0, (ActivityInfo)this.f$1, (String)this.f$2);
    }
}

