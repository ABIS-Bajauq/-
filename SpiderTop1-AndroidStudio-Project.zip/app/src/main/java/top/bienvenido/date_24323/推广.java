/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Void
 *  java.lang.reflect.Array
 *  java.lang.reflect.Method
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u63a8\u5e7f
extends \u53d8\u8fc1 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Exception exception) {
            Class class_ = method.getReturnType();
            if (!class_.isPrimitive()) return null;
            if (Intrinsics.areEqual((Object)class_, (Object)Void.TYPE)) return null;
            Object object2 = \u89e6\u53d1.\u8d4b\u80fd.\u8d4b\u80fd(class_.hashCode());
            if (object2 != null) return object2;
            Class class_2 = class_.getComponentType();
            if (class_2 == null) return null;
            return Array.newInstance((Class)class_2, (int)0);
        }
    }
}

