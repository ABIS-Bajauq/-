/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.AdaptedFunctionReference
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.AdaptedFunctionReference;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;

public final class \u6536\u5272
extends AdaptedFunctionReference
implements Function0 {
    public static final \u6536\u5272 \u8d4b\u80fd = new \u6536\u5272();

    public \u6536\u5272() {
        super(0, \u6241\u5e73\u5316.class, "<init>", "<init>(I)V", 0);
    }

    public final Object invoke() {
        return new \u6241\u5e73\u5316(0);
    }
}

