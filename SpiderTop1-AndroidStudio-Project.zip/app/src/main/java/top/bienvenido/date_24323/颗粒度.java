/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import java.util.ArrayList;
import top.bienvenido.date_24323.\u611f\u77e5\u5ea6;
import top.bienvenido.date_24323.\u65b9\u6cd5\u8bba;

public final class \u9897\u7c92\u5ea6 {
    public final /* synthetic */ \u65b9\u6cd5\u8bba \u6293\u624b;
    public final ArrayList \u8d4b\u80fd = new ArrayList();

    public \u9897\u7c92\u5ea6(\u65b9\u6cd5\u8bba \u65b9\u6cd5\u8bba2) {
        this.\u6293\u624b = \u65b9\u6cd5\u8bba2;
    }

    public final void \u8d4b\u80fd() {
        for (\u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62 : this.\u8d4b\u80fd) {
            this.\u6293\u624b.remove((Object)\u611f\u77e5\u5ea62);
        }
    }
}

