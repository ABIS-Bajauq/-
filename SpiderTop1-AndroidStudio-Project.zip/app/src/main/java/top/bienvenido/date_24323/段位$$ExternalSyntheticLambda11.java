/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda11
implements Thread.UncaughtExceptionHandler {
    public final /* synthetic */ Thread.UncaughtExceptionHandler f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda11(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f$0 = uncaughtExceptionHandler;
    }

    public final void uncaughtException(Thread thread, Throwable throwable) {
        \u6bb5\u4f4d.\u8d4b\u80fd((Thread.UncaughtExceptionHandler)this.f$0, (Thread)thread, (Throwable)throwable);
    }
}

