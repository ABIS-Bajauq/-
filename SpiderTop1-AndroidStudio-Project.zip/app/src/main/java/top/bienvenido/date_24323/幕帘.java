/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5e55\u5e18$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5e55\u5e18
extends \u89e6\u53d1 {
    public static final int \u8d4b\u80fd(ComponentName componentName, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u8d4b\u80fd(componentName);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        ComponentName componentName = (ComponentName)arrobject[0];
        if (componentName == null) return super.\u8d4b\u80fd(object, method, arrobject);
        Integer n = (Integer)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u5e55\u5e18$$ExternalSyntheticLambda0(componentName));
        if (n == null) return super.\u8d4b\u80fd(object, method, arrobject);
        int n2 = n;
        if (n2 < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            return n2;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

