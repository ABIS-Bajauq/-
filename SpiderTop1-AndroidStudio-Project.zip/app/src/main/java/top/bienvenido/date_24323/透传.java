/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u534f\u540c
 *  top.bienvenido.date_24323.\u8054\u52a8
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u8054\u52a8;

public abstract class \u900f\u4f20 {
    public static final \u534f\u540c \u6293\u624b;
    public static final \u8054\u52a8 \u8d4b\u80fd;

    static {
        \u8d4b\u80fd = new \u8054\u52a8();
        \u6293\u624b = new \u534f\u540c();
    }
}

