/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u753b\u997c;

public final class \u6f14\u7ece {
    public int \u4e2d\u53f0;
    public int[] \u6293\u624b;
    public int[] \u8d4b\u80fd;

    public \u6f14\u7ece() {
        int[] arrn = \u4e0b\u6c89.\u8d4b\u80fd;
        this.\u8d4b\u80fd = arrn;
        this.\u6293\u624b = arrn;
        this.\u4e2d\u53f0 = 0;
    }

    public final void \u8d4b\u80fd(int n, int n2) {
        int[] arrn = this.\u8d4b\u80fd;
        int n3 = this.\u4e2d\u53f0;
        int n4 = \u753b\u997c.\u8d4b\u80fd(arrn, n3, n);
        if (n4 >= 0) {
            this.\u6293\u624b[n4] = n2;
            return;
        }
        int n5 = n4;
        int n6 = n3 + 1;
        if (n6 <= arrn.length) {
            System.arraycopy((Object)arrn, (int)n5, (Object)arrn, (int)(n5 + 1), (int)(n3 - n5));
            arrn[n5] = n;
        } else {
            int[] arrn2 = new int[(n3 | 1) << 1];
            System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)n5);
            arrn2[n5] = n;
            System.arraycopy((Object)arrn, (int)n5, (Object)arrn2, (int)(n5 + 1), (int)(arrn.length - n5));
            arrn = arrn2;
        }
        this.\u8d4b\u80fd = arrn;
        int[] arrn3 = this.\u6293\u624b;
        if (n6 <= arrn3.length) {
            System.arraycopy((Object)arrn3, (int)n5, (Object)arrn3, (int)(n5 + 1), (int)(n3 - n5));
            arrn3[n5] = n2;
        } else {
            int[] arrn4 = new int[(n3 | 1) << 1];
            System.arraycopy((Object)arrn3, (int)0, (Object)arrn4, (int)0, (int)n5);
            arrn4[n5] = n2;
            System.arraycopy((Object)arrn3, (int)n5, (Object)arrn4, (int)(n5 + 1), (int)(arrn3.length - n5));
            arrn3 = arrn4;
        }
        this.\u6293\u624b = arrn3;
        this.\u4e2d\u53f0 = n6;
    }
}

