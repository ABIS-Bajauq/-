/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Service
 *  android.os.ServiceManager
 *  android.os.ServiceWithMetadata
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.Map
 *  kotlin.TuplesKt
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5360\u573a\u666f
 *  top.bienvenido.date_24323.\u660e\u7ade\u4e89
 *  top.bienvenido.date_24323.\u6d1e\u81ea\u8eab$
 *  top.bienvenido.date_24323.\u6d1e\u81ea\u8eab$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u6d1e\u81ea\u8eab$$ExternalSyntheticLambda1
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 *  top.bienvenido.date_24323.\u89c2\u884c\u4e1a
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Service;
import android.os.ServiceManager;
import android.os.ServiceWithMetadata;
import java.lang.reflect.Method;
import java.util.Map;
import kotlin.TuplesKt;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5360\u573a\u666f;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u660e\u7ade\u4e89;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab$;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89c2\u884c\u4e1a;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8e1d\u90e8;

public final class \u6d1e\u81ea\u8eab {
    public static final Map \u6293\u624b;
    public static final \u6241\u5e73\u5316 \u8d4b\u80fd;

    static {
        Object object;
        \u8d4b\u80fd = new \u6241\u5e73\u5316(0);
        try {
            object = (Map)\u771f\u9999.\u4e2d\u53f0(ServiceManager.class, "sCache");
        }
        catch (Exception exception) {
            object = new \u515c\u5e95(0);
        }
        \u6293\u624b = object;
    }

    public static final Service \u6293\u624b(\u8e1d\u90e8 \u8e1d\u90e82) {
        return Service.binder((IBinder)\u8e1d\u90e82);
    }

    public static final Service \u8d4b\u80fd(\u8e1d\u90e8 \u8e1d\u90e82) {
        ServiceWithMetadata serviceWithMetadata = new ServiceWithMetadata();
        serviceWithMetadata.service = \u8e1d\u90e82;
        return Service.serviceWithMetadata((ServiceWithMetadata)serviceWithMetadata);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static \u51fa\u51fb \u8d4b\u80fd(String string2, \u89e6\u8fbe \u89e6\u8fbe2, IBinder iBinder, Object object) {
        Map map2;
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        "Working on " + string2 + " with invocation handler...";
        \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u89e6\u8fbe2);
        \u8e1d\u90e8 \u8e1d\u90e82 = new \u8e1d\u90e8(iBinder, (IInterface)\u51fa\u51fb2.\u95ed\u73af);
        \u6241\u5e73\u5316 \u6241\u5e73\u53163 = \u6241\u5e73\u53162 = \u8d4b\u80fd;
        synchronized (\u6241\u5e73\u53163) {
            \u6241\u5e73\u53162.\u8d4b\u80fd(string2.hashCode(), (Object)TuplesKt.to((Object)\u8e1d\u90e82, (Object)\u51fa\u51fb2));
        }
        Map map = map2 = \u6293\u624b;
        synchronized (map) {
            map2.put((Object)string2, (Object)\u8e1d\u90e82);
        }
        \u89c2\u884c\u4e1a \u89c2\u884c\u4e1a2 = new \u89c2\u884c\u4e1a(\u8e1d\u90e82, \u89e6\u8fbe2);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1772511108, (Object)\u89c2\u884c\u4e1a2);
        return \u51fa\u51fb2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static \u51fa\u51fb \u8d4b\u80fd(String var0, \u89e6\u8fbe var1_1, String var2_2) {
        var16_4 = var4_3 = \u6d1e\u81ea\u8eab.\u6293\u624b;
        // MONITORENTER : var16_4
        var6_5 = ServiceManager.getService((String)var0);
        if (var6_5 != null) ** GOTO lbl9
        // MONITOREXIT : var16_4
        return null;
lbl9: // 1 sources:
        // MONITOREXIT : var16_4
        if (var2_2 == null) {
            var7_6 = var6_5.getInterfaceDescriptor();
            if (var7_6 == null) return null;
            var2_2 = var7_6 + "$Stub";
            if (var2_2 == null) {
                return null;
            }
        }
        var8_7 = new Class[]{IBinder.class};
        var12_8 = Class.forName((String)var2_2);
        {
            catch (Exception var9_13) {
                try {
                    var10_10 = \u81ea\u6d3d.\u8d4b\u80fd;
lbl22: // 3 sources:
                    var11_14 = var10_10.\u8d4b\u80fd((Object)null, new Object[]{var6_5});
                    if (var11_14 != null) return \u6d1e\u81ea\u8eab.\u8d4b\u80fd(var0, var1_1, var6_5, var11_14);
                    return null;
                }
                catch (Exception var3_15) {
                    return null;
                }
            }
        }
        try {
            var15_9 = var12_8.getDeclaredMethod("asInterface", var8_7);
            var15_9.setAccessible(true);
            var10_10 = new \u76ae\u5b9e(var15_9);
            ** GOTO lbl22
        }
        catch (Exception var13_11) {
            var10_10 = var14_12 = \u81ea\u6d3d.\u8d4b\u80fd;
            ** GOTO lbl22
        }
    }

    public static void \u8d4b\u80fd() {
        \u89e6\u8fbe \u89e6\u8fbe2;
        \u81ea\u6d3d \u81ea\u6d3d2;
        Object object;
        block4 : {
            try {
                \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(ServiceManager.class, "sServiceManager");
                \u89e6\u8fbe2 = \u672c\u6211.\u8d4b\u80fd;
                object = \u81ea\u6d3d2.\u8d4b\u80fd(null);
                if (object != null) break block4;
                return;
            }
            catch (Throwable throwable) {
                return;
            }
        }
        \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u89e6\u8fbe2);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-1273953665, 1923498125}, (\u89e6\u8fbe)new \u5360\u573a\u666f((Function1)\u660e\u7ade\u4e89.\u8d4b\u80fd));
        if (\u62bd\u8c61.\u5bf9\u9f50) {
            Object object2 = \u62bd\u8c61.\u5bf9\u6807 ? new $ExternalSyntheticLambda0() : new $ExternalSyntheticLambda1();
            \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-837857901, -501100219}, (\u89e6\u8fbe)new \u5360\u573a\u666f((Function1)object2));
        }
        \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, \u51fa\u51fb2.\u95ed\u73af);
    }
}

