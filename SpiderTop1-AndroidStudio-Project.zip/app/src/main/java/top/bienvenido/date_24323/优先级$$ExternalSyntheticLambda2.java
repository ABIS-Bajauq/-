/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function3
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function3;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;

public final class \u4f18\u5148\u7ea7$$ExternalSyntheticLambda2
implements Function3 {
    public final Object invoke(Object object, Object object2, Object object3) {
        return \u4f18\u5148\u7ea7.\u6293\u624b(object, (Method)object2, (Object[])object3);
    }
}

