/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8fdb\u519b;

public final class \u8d77\u98de
extends \u81ea\u6d3d {
    public \u81ea\u6d3d \u6293\u624b;

    public \u8d77\u98de(String string) {
        this.\u6293\u624b = new \u8fdb\u519b(string, this);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object) {
        return this.\u6293\u624b.\u8d4b\u80fd(object);
    }

    @Override
    public final void \u8d4b\u80fd(Object object, Object object2) {
        this.\u6293\u624b.\u8d4b\u80fd(object, object2);
    }
}

