/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u80cc\u9505;

public final class \u80cc\u9505$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u80cc\u9505.\u8d4b\u80fd((\u7b14\u82af)object);
    }
}

