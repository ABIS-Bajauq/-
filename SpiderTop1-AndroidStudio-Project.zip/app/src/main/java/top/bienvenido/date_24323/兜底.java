/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 *  java.util.AbstractMap
 *  java.util.Set
 *  top.bienvenido.date_24323.\u5f00\u62d3
 */
package top.bienvenido.date_24323;

import java.util.AbstractMap;
import java.util.Set;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u5f00\u62d3;
import top.bienvenido.date_24323.\u7075\u6d3b;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u7cbe\u51c6;

public final class \u515c\u5e95
extends AbstractMap {
    public int \u4e2d\u53f0;
    public Object[] \u6293\u624b = \u4e0b\u6c89.\u4e2d\u53f0;
    public int[] \u8d4b\u80fd = \u4e0b\u6c89.\u8d4b\u80fd;
    public final \u5f00\u62d3 \u95ed\u73af = new \u5f00\u62d3(this);

    public \u515c\u5e95(int n) {
    }

    public final void clear() {
        this.\u8d4b\u80fd = \u4e0b\u6c89.\u8d4b\u80fd;
        this.\u6293\u624b = \u4e0b\u6c89.\u4e2d\u53f0;
        this.\u4e2d\u53f0 = 0;
    }

    public final boolean containsKey(Object object) {
        int n = object != null ? object.hashCode() : 0;
        return \u753b\u997c.\u8d4b\u80fd(this.\u8d4b\u80fd, this.\u4e2d\u53f0, n) >= 0;
    }

    public final Set entrySet() {
        return this.\u95ed\u73af.\u8d4b\u80fd;
    }

    public final Object get(Object object) {
        int n = object != null ? object.hashCode() : 0;
        int n2 = \u753b\u997c.\u8d4b\u80fd(this.\u8d4b\u80fd, this.\u4e2d\u53f0, n);
        if (n2 >= 0) {
            return this.\u6293\u624b[1 | n2 << 1];
        }
        return null;
    }

    public final Object put(Object object, Object object2) {
        int n = object != null ? object.hashCode() : 0;
        int n2 = \u753b\u997c.\u8d4b\u80fd(this.\u8d4b\u80fd, this.\u4e2d\u53f0, n);
        if (n2 >= 0) {
            int n3 = 1 | n2 << 1;
            Object[] arrobject = this.\u6293\u624b;
            Object object3 = arrobject[n3];
            arrobject[n3] = object2;
            return object3;
        }
        int n4 = this.\u4e2d\u53f0;
        int[] arrn = this.\u8d4b\u80fd;
        if (n4 >= arrn.length) {
            Object[] arrobject = this.\u6293\u624b;
            int n5 = n4 | 1;
            int[] arrn2 = new int[n5 << 1];
            this.\u8d4b\u80fd = arrn2;
            this.\u6293\u624b = new Object[n5 << 2];
            System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)arrn.length);
            System.arraycopy((Object)arrobject, (int)0, (Object)this.\u6293\u624b, (int)0, (int)arrobject.length);
        }
        Object[] arrobject = this.\u6293\u624b;
        int[] arrn3 = this.\u8d4b\u80fd;
        int n6 = n2;
        int n7 = n6 << 1;
        if (n6 < n4) {
            int n8 = n6 + 1;
            int n9 = n4 - n6;
            System.arraycopy((Object)arrn3, (int)n6, (Object)arrn3, (int)n8, (int)n9);
            System.arraycopy((Object)arrobject, (int)n7, (Object)arrobject, (int)(n8 << 1), (int)(n9 << 1));
        }
        arrn3[n6] = n;
        arrobject[n7] = object;
        arrobject[n7 | 1] = object2;
        this.\u4e2d\u53f0 = n4 + 1;
        return null;
    }

    public final Object remove(Object object) {
        int n = object != null ? object.hashCode() : 0;
        int n2 = \u753b\u997c.\u8d4b\u80fd(this.\u8d4b\u80fd, this.\u4e2d\u53f0, n);
        if (n2 >= 0) {
            Object[] arrobject = this.\u6293\u624b;
            int n3 = n2 << 1;
            Object object2 = arrobject[n3 | 1];
            int n4 = this.\u4e2d\u53f0;
            if (n4 <= 1) {
                this.clear();
                return object2;
            }
            int n5 = n4 - 1;
            int[] arrn = this.\u8d4b\u80fd;
            if (n5 < arrn.length >> 2) {
                int[] arrn2 = new int[n5];
                this.\u8d4b\u80fd = arrn2;
                this.\u6293\u624b = new Object[n5 << 1];
                if (n2 > 0) {
                    System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)n2);
                    System.arraycopy((Object)arrobject, (int)0, (Object)this.\u6293\u624b, (int)0, (int)n3);
                }
                if (n2 < n5) {
                    int n6 = n2 + 1;
                    int[] arrn3 = this.\u8d4b\u80fd;
                    int n7 = n5 - n2;
                    System.arraycopy((Object)arrn, (int)n6, (Object)arrn3, (int)n2, (int)n7);
                    System.arraycopy((Object)arrobject, (int)(n6 << 1), (Object)this.\u6293\u624b, (int)n3, (int)(n7 << 1));
                }
            } else {
                if (n2 < n5) {
                    int n8 = n2 + 1;
                    int n9 = n5 - n2;
                    System.arraycopy((Object)arrn, (int)n8, (Object)arrn, (int)n2, (int)n9);
                    System.arraycopy((Object)arrobject, (int)(n8 << 1), (Object)arrobject, (int)n3, (int)(n9 << 1));
                }
                int n10 = n5 << 1;
                arrobject[n10] = null;
                arrobject[n10 | 1] = null;
            }
            this.\u4e2d\u53f0 = n5;
            return object2;
        }
        return null;
    }

    public final int size() {
        return this.\u4e2d\u53f0;
    }
}

