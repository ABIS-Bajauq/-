/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import java.util.Collections;
import java.util.List;
import top.bienvenido.date_24323.\u6d41\u5931;

public final class \u8ba4\u8bc1
implements \u6d41\u5931 {
    @Override
    public final List \u4e2d\u53f0(Intent intent, String string, int n) {
        return Collections.EMPTY_LIST;
    }

    @Override
    public final List \u6293\u624b(Intent intent, String string, int n) {
        return Collections.EMPTY_LIST;
    }

    @Override
    public final List \u8d4b\u80fd(Intent intent, String string, int n) {
        return Collections.EMPTY_LIST;
    }

    @Override
    public final List \u95ed\u73af(Intent intent, String string, int n) {
        return Collections.EMPTY_LIST;
    }
}

