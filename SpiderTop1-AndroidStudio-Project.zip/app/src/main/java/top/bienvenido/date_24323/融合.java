/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u878d\u5408
extends \u89e6\u8fbe {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        block3 : {
            try {
                if (!\u6c34\u4f4d.\u8d4b\u80fd || !\u6c34\u4f4d.\u6f0f\u6597) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        Object object2 = method.invoke(object, arrobject);
        return object2;
    }
}

