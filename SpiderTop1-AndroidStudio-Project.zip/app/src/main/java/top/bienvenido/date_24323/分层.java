/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.text.StringsKt
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8fc1\u79fb;

public final class \u5206\u5c42
extends \u89e6\u53d1 {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        String string;
        int n;
        block3 : {
            block2 : {
                n = 1;
                try {
                    string = String.valueOf((Object)arrobject[n]);
                    \u5e73\u53f0\u5316 \u5e73\u53f0\u53162 = \u8fc1\u79fb.\u6293\u624b;
                    int n2 = string.hashCode();
                    if (\u753b\u997c.\u8d4b\u80fd(\u5e73\u53f0\u53162.\u8d4b\u80fd, \u5e73\u53f0\u53162.\u6293\u624b, n2) < 0 && !StringsKt.startsWith$default((String)string, (String)"com.google.android.", (boolean)false, (int)2, null)) break block2;
                    break block3;
                }
                catch (Exception exception) {
                    // empty catch block
                    return super.\u8d4b\u80fd(object, method, arrobject);
                }
            }
            n = 0;
        }
        if (n == 0) return super.\u8d4b\u80fd(object, method, arrobject);
        "Assume application obtained permission state -> " + string;
        return 0;
    }
}

