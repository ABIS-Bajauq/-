/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  top.bienvenido.date_24323.\u5bfc\u6d41
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.Bundle;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u5bfc\u6d41;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u9020\u52bf;

public final class \u6295\u653e
extends \u89e6\u8fbe {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Bundle bundle = (Bundle)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Bundle.class);
            if (bundle == null) return \u5bfc\u6d41.\u5e73\u53f0.\u8d4b\u80fd(object, method, arrobject);
            \u9020\u52bf.\u6293\u624b(bundle);
            Uri uri = (Uri)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Uri.class);
            if (uri != null) {
                \u9020\u52bf.\u8d4b\u80fd(uri, bundle);
            }
            \u9020\u52bf.\u8d4b\u80fd(bundle);
            return \u5bfc\u6d41.\u5e73\u53f0.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return \u5bfc\u6d41.\u5e73\u53f0.\u8d4b\u80fd(object, method, arrobject);
    }
}

